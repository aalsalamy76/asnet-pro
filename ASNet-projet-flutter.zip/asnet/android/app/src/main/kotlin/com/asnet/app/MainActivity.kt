package com.asnet.app

// Décision : un seul MethodChannel natif ("com.asnet.app/wifi") pour ce qu'aucun plugin Flutter
// n'expose : type de sécurité Wi-Fi, scan des réseaux voisins, infos du lien radio, verrou multicast
// (nécessaire pour recevoir les réponses mDNS/Bonjour sur Android).

import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val channelName = "com.asnet.app/wifi"
    private var multicastLock: WifiManager.MulticastLock? = null

    private fun wifiManager(): WifiManager? =
        applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "getSecurityType" -> result.success(readSecurityType())
                        "getLinkInfo" -> result.success(readLinkInfo())
                        "scanWifi" -> result.success(scanWifi())
                        "acquireMulticastLock" -> result.success(acquireMulticastLock())
                        "releaseMulticastLock" -> {
                            releaseMulticastLock()
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("NATIVE_ERROR", e.message, null)
                }
            }
    }

    override fun onDestroy() {
        releaseMulticastLock()
        super.onDestroy()
    }

    // ───────────────────────── Sécurité du Wi-Fi courant ─────────────────────────

    @Suppress("DEPRECATION")
    private fun readSecurityType(): String {
        val wm = wifiManager() ?: return "UNKNOWN"
        if (!wm.isWifiEnabled) return "UNKNOWN"
        val info = wm.connectionInfo ?: return "UNKNOWN"
        if (info.networkId == -1) return "UNKNOWN"

        // Android 12+ (API 31) : valeur fournie directement par le système.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return when (info.currentSecurityType) {
                0 -> "OPEN"            // SECURITY_TYPE_OPEN
                1 -> "WEP"             // SECURITY_TYPE_WEP
                2 -> "WPA2"            // SECURITY_TYPE_PSK
                3 -> "WPA2_ENTERPRISE" // SECURITY_TYPE_EAP
                4 -> "WPA3"            // SECURITY_TYPE_SAE
                5 -> "WPA3_ENTERPRISE" // SECURITY_TYPE_EAP_WPA3_ENTERPRISE_192_BIT
                6 -> "OWE"             // SECURITY_TYPE_OWE
                7, 8 -> "WAPI"         // SECURITY_TYPE_WAPI_PSK / WAPI_CERT
                9 -> "WPA3_ENTERPRISE" // SECURITY_TYPE_EAP_WPA3_ENTERPRISE
                11, 12 -> "WPA2_ENTERPRISE" // PASSPOINT
                else -> "UNKNOWN"
            }
        }

        // Android 6 à 11 : on retrouve le point d'accès courant dans le dernier scan.
        val bssid = info.bssid ?: return "UNKNOWN"
        if (bssid == "02:00:00:00:00:00") return "UNKNOWN" // localisation refusée
        val current = readScanResults().firstOrNull { it.BSSID.equals(bssid, ignoreCase = true) }
            ?: return "UNKNOWN"
        return securityFromCapabilities(current.capabilities ?: "")
    }

    private fun securityFromCapabilities(caps: String): String {
        return when {
            caps.contains("SAE") && caps.contains("EAP") -> "WPA3_ENTERPRISE"
            caps.contains("SAE") -> "WPA3"
            caps.contains("OWE") -> "OWE"
            caps.contains("EAP") -> "WPA2_ENTERPRISE"
            caps.contains("RSN") || caps.contains("WPA2") -> "WPA2"
            caps.contains("WPA") -> "WPA"
            caps.contains("WEP") -> "WEP"
            else -> "OPEN"
        }
    }

    // ───────────────────────── Lien radio (RSSI, débit, norme) ─────────────────────────

    @Suppress("DEPRECATION")
    private fun readLinkInfo(): Map<String, Any?> {
        val map = HashMap<String, Any?>()
        val wm = wifiManager() ?: return map
        val info = wm.connectionInfo ?: return map
        if (info.networkId == -1 && info.rssi <= -127) return map
        map["rssi"] = info.rssi
        map["linkSpeed"] = info.linkSpeed
        map["frequency"] = info.frequency
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            map["txLinkSpeed"] = info.txLinkSpeedMbps
            map["rxLinkSpeed"] = info.rxLinkSpeedMbps
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            map["wifiStandard"] = info.wifiStandard
        }
        return map
    }

    // ───────────────────────── Réseaux Wi-Fi voisins ─────────────────────────

    private fun readScanResults(): List<ScanResult> {
        val wm = wifiManager() ?: return emptyList()
        return try {
            wm.scanResults ?: emptyList()
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    @Suppress("DEPRECATION")
    private fun scanWifi(): List<Map<String, Any?>> {
        val wm = wifiManager() ?: return emptyList()
        try {
            // Android limite à 4 scans / 2 min : sinon on obtient le dernier résultat en cache.
            wm.startScan()
        } catch (e: Exception) {
        }
        val list = ArrayList<Map<String, Any?>>()
        for (r in readScanResults()) {
            val m = HashMap<String, Any?>()
            m["ssid"] = r.SSID ?: ""
            m["bssid"] = r.BSSID ?: ""
            m["level"] = r.level
            m["frequency"] = r.frequency
            m["capabilities"] = r.capabilities ?: ""
            m["security"] = securityFromCapabilities(r.capabilities ?: "")
            m["channelWidth"] = r.channelWidth
            list.add(m)
        }
        return list
    }

    // ───────────────────────── Verrou multicast (mDNS) ─────────────────────────

    private fun acquireMulticastLock(): Boolean {
        val wm = wifiManager() ?: return false
        var lock = multicastLock
        if (lock == null) {
            lock = wm.createMulticastLock("asnet-discovery")
            lock.setReferenceCounted(false)
            multicastLock = lock
        }
        if (!lock.isHeld) lock.acquire()
        return lock.isHeld
    }

    private fun releaseMulticastLock() {
        try {
            val lock = multicastLock
            if (lock != null && lock.isHeld) lock.release()
        } catch (e: Exception) {
        }
    }
}
