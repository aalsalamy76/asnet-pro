# Utilisé uniquement si vous activez minifyEnabled = true dans app/build.gradle.
-keep class io.flutter.** { *; }
-keep class com.asnet.app.** { *; }
-dontwarn com.google.android.play.core.**
-dontwarn io.flutter.embedding.**
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
