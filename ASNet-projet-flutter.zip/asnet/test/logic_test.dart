import 'dart:typed_data';

import 'package:asnet/core/network/dns_codec.dart';
import 'package:asnet/core/network/ports_catalog.dart';
import 'package:asnet/features/scan/models/network_info.dart';
import 'package:asnet/features/scan/services/network_scanner.dart';
import 'package:asnet/features/scan/services/oui_lookup.dart';
import 'package:asnet/features/share/wifi_qr.dart';
import 'package:asnet/features/tools/services/lan_tools.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Calcul du sous-réseau', () {
    test('/24 -> 254 hôtes', () {
      final r = NetworkScanner.computeRange('192.168.1.42', '255.255.255.0');
      expect(r.hosts.length, 254);
      expect(r.hosts.first, '192.168.1.1');
      expect(r.hosts.last, '192.168.1.254');
      expect(r.cidr, '192.168.1.0/24');
    });

    test('/16 plafonné au /24 de l\'appareil', () {
      final r = NetworkScanner.computeRange('10.0.5.9', '255.255.0.0');
      expect(r.prefix, 24);
      expect(r.hosts.first, '10.0.5.1');
      expect(r.hosts.length, 254);
    });

    test('/28 -> 14 hôtes', () {
      final r = NetworkScanner.computeRange('192.168.1.20', '255.255.255.240');
      expect(r.hosts.length, 14);
      expect(r.hosts.first, '192.168.1.17');
      expect(r.hosts.last, '192.168.1.30');
    });

    test('masque absent -> /24', () {
      final r = NetworkScanner.computeRange('172.16.3.200', null);
      expect(r.prefix, 24);
    });
  });

  group('QR Wi-Fi', () {
    test('aller-retour avec caractères spéciaux', () {
      const original = WifiCredentials(
        ssid: 'Box;Maison:5G',
        password: r'p@ss\word,"x"',
        auth: WifiAuth.wpa,
        hidden: true,
      );
      final parsed = WifiCredentials.parse(original.toQrPayload());
      expect(parsed, isNotNull);
      expect(parsed!.ssid, original.ssid);
      expect(parsed.password, original.password);
      expect(parsed.auth, WifiAuth.wpa);
      expect(parsed.hidden, isTrue);
    });

    test('réseau ouvert', () {
      const open = WifiCredentials(ssid: 'Cafe', auth: WifiAuth.open);
      expect(open.toQrPayload(), 'WIFI:T:nopass;S:Cafe;;');
      expect(WifiCredentials.parse(open.toQrPayload())!.auth, WifiAuth.open);
    });

    test('contenu non Wi-Fi', () {
      expect(WifiCredentials.parse('https://example.com'), isNull);
    });

    test('validation WPA (8 à 63 caractères)', () {
      expect(const WifiCredentials(ssid: 'A', password: '1234567').isValid, isFalse);
      expect(const WifiCredentials(ssid: 'A', password: '12345678').isValid, isTrue);
    });
  });

  group('OUI', () {
    test('normalisation', () {
      expect(OuiLookup.normalizeMac('b8-27-eb-12-34-56'), 'B8:27:EB:12:34:56');
      expect(OuiLookup.normalizeMac('02:00:00:00:00:00'), isNull);
    });

    test('fabricant', () {
      expect(const OuiLookup().vendorOf('B8:27:EB:00:00:01'), 'Raspberry Pi');
    });

    test('MAC aléatoire', () {
      expect(OuiLookup.isRandomized('DA:A1:19:00:00:01'), isTrue);
      expect(OuiLookup.isRandomized('B8:27:EB:00:00:01'), isFalse);
    });
  });

  group('Sécurité', () {
    test('score WPA3 > WPA2 > ouvert', () {
      NetworkDetails make(WifiSecurity s) =>
          NetworkDetails(kind: ConnectionKind.wifi, fetchedAt: DateTime(2026), security: s);
      expect(make(WifiSecurity.wpa3).securityScore! > make(WifiSecurity.wpa2).securityScore!, isTrue);
      expect(make(WifiSecurity.open).health, NetworkHealth.poor);
      expect(make(WifiSecurity.wpa3).health, NetworkHealth.excellent);
    });
  });

  group('Outils v0.2', () {
    test('liste de ports', () {
      expect(PortsCatalog.parse('22, 80,8000-8002'), [22, 80, 8000, 8001, 8002]);
      expect(PortsCatalog.parse('70000'), isNull);
    });

    test('calculateur /26', () {
      final info = const SubnetCalculator().calculate('192.168.1.70/26')!;
      expect(info.network, '192.168.1.64');
      expect(info.broadcast, '192.168.1.127');
      expect(info.hostCount, 62);
      expect(info.isPrivate, isTrue);
    });

    test('DNS : requête puis réponse A', () {
      final query = DnsCodec.buildQuery(0x1234, [const DnsQuestion('example.com', DnsCodec.typeA)]);
      // Réponse = requête + bit QR + 1 réponse A (nom compressé vers l'offset 12).
      final response = Uint8List.fromList([
        ...query.sublist(0, 2), 0x81, 0x80, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00,
        ...query.sublist(12),
        0xC0, 0x0C, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x0E, 0x10, 0x00, 0x04, 93, 184, 216, 34,
      ]);
      final message = DnsCodec.parse(response)!;
      expect(message.id, 0x1234);
      expect(message.rcodeName, 'NOERROR');
      expect(message.answers.single.data, '93.184.216.34');
      expect(message.answers.single.name, 'example.com');
      expect(message.answers.single.ttl, 3600);
    });
  });
}
