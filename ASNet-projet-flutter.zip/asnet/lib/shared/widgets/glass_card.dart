// Décision : `blur` désactivable — BackdropFilter coûte cher dans les longues listes (scan),
// on le garde pour les cartes du dashboard et on le coupe pour les lignes d'appareils.
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_motion.dart';
import '../../core/theme/app_spacing.dart';

class GlassCard extends StatefulWidget {
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(AppSpacing.lg),
    this.radius = AppSpacing.radiusMd,
    this.onTap,
    this.semanticLabel,
    this.accent,
    this.blur = true,
    this.height,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  final VoidCallback? onTap;
  final String? semanticLabel;

  /// Teinte légère de la carte (ex. cyan pour le réseau, violet pour le partage).
  final Color? accent;
  final bool blur;
  final double? height;

  @override
  State<GlassCard> createState() => _GlassCardState();
}

class _GlassCardState extends State<GlassCard> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (widget.onTap == null || _pressed == value) return;
    setState(() => _pressed = value);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final borderRadius = BorderRadius.circular(widget.radius);
    final accent = widget.accent;

    final decoration = BoxDecoration(
      borderRadius: borderRadius,
      border: Border.all(
        color: accent != null ? accent.faded(0.28) : p.glassBorder,
      ),
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          accent != null ? Color.alphaBlend(accent.faded(0.12), p.glass) : p.glass,
          p.glass,
        ],
      ),
    );

    Widget content = Container(
      height: widget.height,
      padding: widget.padding,
      decoration: decoration,
      child: widget.child,
    );

    if (widget.blur) {
      content = BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: content,
      );
    }
    content = ClipRRect(borderRadius: borderRadius, child: content);

    if (widget.onTap != null) {
      return Semantics(
        button: true,
        label: widget.semanticLabel,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapDown: (_) => _setPressed(true),
          onTapUp: (_) => _setPressed(false),
          onTapCancel: () => _setPressed(false),
          onTap: () {
            AppMotion.tap();
            widget.onTap?.call();
          },
          child: AnimatedScale(
            scale: _pressed ? 0.97 : 1.0,
            duration: AppMotion.fast,
            curve: AppMotion.ease,
            child: content,
          ),
        ),
      );
    }
    if (widget.semanticLabel != null) {
      return Semantics(label: widget.semanticLabel, child: content);
    }
    return content;
  }
}

/// Fond d'écran "liquide" : halos flous cyan/violet derrière les surfaces glass.
class LiquidBackground extends StatelessWidget {
  const LiquidBackground({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final dark = context.isDark;
    return DecoratedBox(
      decoration: BoxDecoration(color: p.background),
      child: Stack(
        children: [
          Positioned(
            top: -120,
            left: -80,
            child: _Halo(color: p.network.faded(dark ? 0.22 : 0.16), size: 340),
          ),
          Positioned(
            top: 220,
            right: -140,
            child: _Halo(color: p.share.faded(dark ? 0.20 : 0.12), size: 380),
          ),
          Positioned.fill(child: child),
        ],
      ),
    );
  }
}

class _Halo extends StatelessWidget {
  const _Halo({required this.color, required this.size});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, color.faded(0)]),
        ),
      ),
    );
  }
}
