// Décision : chaque appareil trouvé devient un "blip" positionné de façon stable
// (hash de l'IP), qui s'illumine au passage du faisceau puis s'estompe.
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

class ScanRadar extends StatefulWidget {
  const ScanRadar({
    super.key,
    required this.active,
    required this.color,
    this.blips = const [],
    this.size = 240,
    this.child,
    this.semanticLabel,
  });

  final bool active;
  final Color color;

  /// Identifiants stables (ex. adresses IP) des appareils trouvés.
  final List<String> blips;
  final double size;

  /// Contenu affiché au centre (ex. pourcentage).
  final Widget? child;
  final String? semanticLabel;

  @override
  State<ScanRadar> createState() => _ScanRadarState();
}

class _ScanRadarState extends State<ScanRadar> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2400),
  );

  @override
  void initState() {
    super.initState();
    _sync();
  }

  @override
  void didUpdateWidget(covariant ScanRadar oldWidget) {
    super.didUpdateWidget(oldWidget);
    _sync();
  }

  void _sync() {
    if (widget.active && !_controller.isAnimating) {
      _controller.repeat();
    } else if (!widget.active && _controller.isAnimating) {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final seeds = widget.blips.map(_seedOf).toList(growable: false);
    return Semantics(
      label: widget.semanticLabel,
      liveRegion: widget.active,
      child: RepaintBoundary(
        child: SizedBox.square(
          dimension: widget.size,
          child: CustomPaint(
            painter: _RadarPainter(
              animation: _controller,
              color: widget.color,
              seeds: seeds,
              active: widget.active,
              gridColor: context.palette.text,
            ),
            child: widget.child == null ? null : Center(child: widget.child),
          ),
        ),
      ),
    );
  }

  /// Hash FNV-1a 32 bits -> [0, 1).
  static double _seedOf(String id) {
    var h = 0x811C9DC5;
    for (final unit in id.codeUnits) {
      h ^= unit;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h / 0x100000000;
  }
}

class _RadarPainter extends CustomPainter {
  _RadarPainter({
    required this.animation,
    required this.color,
    required this.seeds,
    required this.active,
    required this.gridColor,
  }) : super(repaint: animation);

  final Animation<double> animation;
  final Color color;
  final List<double> seeds;
  final bool active;
  final Color gridColor;

  static const double _tau = math.pi * 2;

  @override
  void paint(Canvas canvas, Size size) {
    final t = animation.value;
    final c = size.center(Offset.zero);
    final radius = size.shortestSide / 2 - 2;
    final rect = Rect.fromCircle(center: c, radius: radius);

    // Disque de fond.
    canvas.drawCircle(
      c,
      radius,
      Paint()
        ..shader = RadialGradient(
          colors: [color.faded(0.16), color.faded(0.03)],
        ).createShader(rect),
    );

    // Anneaux "liquides" qui ondulent légèrement.
    final ringPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = color.faded(0.28);
    for (var i = 1; i <= 4; i++) {
      final base = radius * i / 4;
      final path = Path();
      const steps = 90;
      for (var s = 0; s <= steps; s++) {
        final a = s / steps * _tau;
        final wobble = active ? math.sin(a * 6 + t * _tau * 2 + i) * radius * 0.010 : 0.0;
        final p = Offset(c.dx + math.cos(a) * (base + wobble), c.dy + math.sin(a) * (base + wobble));
        if (s == 0) {
          path.moveTo(p.dx, p.dy);
        } else {
          path.lineTo(p.dx, p.dy);
        }
      }
      path.close();
      canvas.drawPath(path, ringPaint);
    }

    // Croix.
    final cross = Paint()
      ..strokeWidth = 1
      ..color = gridColor.faded(0.06);
    canvas.drawLine(Offset(c.dx - radius, c.dy), Offset(c.dx + radius, c.dy), cross);
    canvas.drawLine(Offset(c.dx, c.dy - radius), Offset(c.dx, c.dy + radius), cross);

    final sweepAngle = t * _tau;

    // Faisceau balayant.
    if (active) {
      const span = math.pi / 2.2;
      canvas.drawArc(
        rect,
        sweepAngle - span,
        span,
        true,
        Paint()
          ..shader = SweepGradient(
            startAngle: 0,
            endAngle: span,
            colors: [color.faded(0), color.faded(0.55)],
            transform: GradientRotation(sweepAngle - span),
          ).createShader(rect),
      );
      canvas.drawLine(
        c,
        Offset(c.dx + math.cos(sweepAngle) * radius, c.dy + math.sin(sweepAngle) * radius),
        Paint()
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round
          ..color = color.faded(0.9),
      );
    }

    // Blips (appareils trouvés).
    for (final seed in seeds) {
      final angle = seed * _tau;
      final dist = radius * (0.22 + 0.70 * ((seed * 7.31) % 1.0));
      final pos = Offset(c.dx + math.cos(angle) * dist, c.dy + math.sin(angle) * dist);
      double glow = 0.55;
      if (active) {
        final diff = ((sweepAngle - angle) % _tau + _tau) % _tau;
        final fade = 1 - diff / _tau;
        glow = 0.30 + 0.70 * fade * fade;
      }
      canvas.drawCircle(pos, 9, Paint()..color = color.faded(0.22 * glow));
      canvas.drawCircle(pos, 4, Paint()..color = color.faded(glow));
    }

    // Centre.
    canvas.drawCircle(c, 3, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _RadarPainter old) =>
      old.color != color || old.active != active || old.seeds.length != seeds.length || old.gridColor != gridColor;
}
