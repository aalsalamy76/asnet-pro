// Décision : grille bento à 2 colonnes, tuiles de largeur 1 ou 2, hauteur fixe par tuile
// (deux tuiles côte à côte prennent la plus grande des deux hauteurs).
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/theme/app_motion.dart';
import '../../core/theme/app_spacing.dart';

class BentoTile {
  const BentoTile({required this.child, this.span = 1, this.height = 150});

  final Widget child;

  /// 1 = demi-largeur, 2 = pleine largeur.
  final int span;
  final double height;
}

class BentoGrid extends StatelessWidget {
  const BentoGrid({
    super.key,
    required this.tiles,
    this.gap = AppSpacing.md,
    this.animate = true,
  });

  final List<BentoTile> tiles;
  final double gap;
  final bool animate;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final full = constraints.maxWidth;
        final half = (full - gap) / 2;
        final rows = <Widget>[];
        var index = 0;
        BentoTile? pending;

        Widget cell(BentoTile tile, double width, double height) {
          final i = index++;
          Widget w = SizedBox(width: width, height: height, child: tile.child);
          if (animate) {
            w = w
                .animate(delay: Duration(milliseconds: 50 * i))
                .fadeIn(duration: AppMotion.slow, curve: AppMotion.ease)
                .slideY(begin: 0.06, end: 0, duration: AppMotion.slow, curve: AppMotion.ease);
          }
          return w;
        }

        for (final tile in tiles) {
          if (tile.span >= 2) {
            final waiting = pending;
            if (waiting != null) {
              rows.add(Row(children: [cell(waiting, half, waiting.height)]));
              pending = null;
            }
            rows.add(cell(tile, full, tile.height));
          } else {
            final waiting = pending;
            if (waiting == null) {
              pending = tile;
            } else {
              final h = math.max(waiting.height, tile.height);
              rows.add(Row(children: [
                cell(waiting, half, h),
                SizedBox(width: gap),
                cell(tile, half, h),
              ]));
              pending = null;
            }
          }
        }
        final last = pending;
        if (last != null) {
          rows.add(Row(children: [cell(last, half, last.height)]));
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var i = 0; i < rows.length; i++) ...[
              if (i > 0) SizedBox(height: gap),
              rows[i],
            ],
          ],
        );
      },
    );
  }
}
