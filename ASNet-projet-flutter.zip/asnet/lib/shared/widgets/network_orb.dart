// Décision : l'orbe se repeint via `repaint: animation` (aucun setState par frame),
// les satellites représentent les appareils détectés (max 12 affichés).
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

class NetworkOrb extends StatefulWidget {
  const NetworkOrb({
    super.key,
    required this.color,
    this.deviceCount = 0,
    this.size = 200,
    this.active = true,
    this.semanticLabel,
  });

  /// Couleur = santé du réseau.
  final Color color;
  final int deviceCount;
  final double size;

  /// false -> animation figée (réseau hors-ligne).
  final bool active;
  final String? semanticLabel;

  @override
  State<NetworkOrb> createState() => _NetworkOrbState();
}

class _NetworkOrbState extends State<NetworkOrb> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 6),
  );

  @override
  void initState() {
    super.initState();
    if (widget.active) _controller.repeat();
  }

  @override
  void didUpdateWidget(covariant NetworkOrb oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.active && !_controller.isAnimating) {
      _controller.repeat();
    } else if (!widget.active && _controller.isAnimating) {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (reduceMotion && _controller.isAnimating) _controller.stop();
    return Semantics(
      label: widget.semanticLabel,
      image: true,
      child: RepaintBoundary(
        child: SizedBox.square(
          dimension: widget.size,
          child: CustomPaint(
            painter: _OrbPainter(
              animation: _controller,
              color: widget.color,
              devices: math.min(widget.deviceCount, 12),
              background: context.palette.background,
            ),
          ),
        ),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  _OrbPainter({
    required this.animation,
    required this.color,
    required this.devices,
    required this.background,
  }) : super(repaint: animation);

  final Animation<double> animation;
  final Color color;
  final int devices;
  final Color background;

  static const double _tau = math.pi * 2;

  @override
  void paint(Canvas canvas, Size size) {
    final t = animation.value;
    final c = size.center(Offset.zero);
    final r = size.shortestSide * 0.28;

    // 1. Ondes de pulsation (3 anneaux décalés).
    for (var i = 0; i < 3; i++) {
      final phase = (t * 3 + i / 3) % 1.0;
      final ring = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = color.faded((1 - phase) * 0.45);
      canvas.drawCircle(c, r * (1.0 + phase * 0.75), ring);
    }

    // 2. Halo.
    final glowRect = Rect.fromCircle(center: c, radius: r * 1.9);
    canvas.drawCircle(
      c,
      r * 1.9,
      Paint()
        ..shader = RadialGradient(
          colors: [color.faded(0.35), color.faded(0)],
        ).createShader(glowRect),
    );

    // 3. Satellites (appareils) en orbite elliptique inclinée.
    final orbitW = r * 1.55;
    final orbitH = r * 0.55;
    const tilt = -0.35;
    final back = <Offset>[];
    final front = <Offset>[];
    for (var i = 0; i < devices; i++) {
      final a = t * _tau + i * _tau / devices;
      final x = math.cos(a) * orbitW;
      final y = math.sin(a) * orbitH;
      final rx = x * math.cos(tilt) - y * math.sin(tilt);
      final ry = x * math.sin(tilt) + y * math.cos(tilt);
      final pos = Offset(c.dx + rx, c.dy + ry);
      (math.sin(a) < 0 ? back : front).add(pos);
    }

    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.rotate(tilt);
    canvas.drawOval(
      Rect.fromCenter(center: Offset.zero, width: orbitW * 2, height: orbitH * 2),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = color.faded(0.30),
    );
    canvas.restore();

    for (final pos in back) {
      canvas.drawCircle(pos, 2.6, Paint()..color = color.faded(0.45));
    }

    // 4. Sphère (respiration légère).
    final breathe = 1 + 0.035 * math.sin(t * _tau * 2);
    final rr = r * breathe;
    final sphereRect = Rect.fromCircle(center: c, radius: rr);
    canvas.drawCircle(
      c,
      rr,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.35, -0.45),
          radius: 1.05,
          colors: [
            Color.lerp(color, Colors.white, 0.55)!,
            color,
            Color.lerp(color, background, 0.70)!,
          ],
          stops: const [0.0, 0.45, 1.0],
        ).createShader(sphereRect),
    );

    // 5. Liquide intérieur : deux vagues sinusoïdales clippées dans la sphère.
    canvas.save();
    canvas.clipPath(Path()..addOval(sphereRect));
    for (var layer = 0; layer < 2; layer++) {
      final baseY = c.dy + rr * (0.18 + layer * 0.14);
      final amp = rr * (0.07 - layer * 0.02);
      final speed = layer == 0 ? 1.0 : -1.5;
      final wave = Path()..moveTo(c.dx - rr, c.dy + rr);
      for (double x = -rr; x <= rr; x += 3) {
        final y = baseY + math.sin(x / rr * math.pi * 1.6 + t * _tau * 2 * speed) * amp;
        wave.lineTo(c.dx + x, y);
      }
      wave
        ..lineTo(c.dx + rr, c.dy + rr)
        ..close();
      canvas.drawPath(wave, Paint()..color = Colors.white.faded(layer == 0 ? 0.10 : 0.07));
    }
    canvas.restore();

    // 6. Reflet spéculaire + liseré.
    canvas.drawOval(
      Rect.fromCenter(
        center: c.translate(-rr * 0.30, -rr * 0.42),
        width: rr * 0.75,
        height: rr * 0.38,
      ),
      Paint()
        ..color = Colors.white.faded(0.28)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
    canvas.drawCircle(
      c,
      rr,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.2
        ..color = Colors.white.faded(0.18),
    );

    for (final pos in front) {
      canvas.drawCircle(pos, 6, Paint()..color = color.faded(0.25));
      canvas.drawCircle(pos, 3.2, Paint()..color = Colors.white.faded(0.95));
    }
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) =>
      old.color != color || old.devices != devices || old.background != background;
}
