import '../../core/l10n/app_localizations.dart';

/// "à l'instant", "il y a 5 min", "il y a 2 h", "il y a 3 j".
String relativeTime(AppLocalizations l, DateTime? date) {
  if (date == null) return l.t('never');
  final diff = DateTime.now().difference(date);
  if (diff.inSeconds < 60) return l.t('just_now');
  if (diff.inMinutes < 60) return l.t('minutes_ago', {'n': diff.inMinutes});
  if (diff.inHours < 24) return l.t('hours_ago', {'n': diff.inHours});
  return l.t('days_ago', {'n': diff.inDays});
}

/// Horodatage compact pour les noms de fichiers : 20261030_1435.
String fileStamp(DateTime d) {
  String two(int v) => v.toString().padLeft(2, '0');
  return '${d.year}${two(d.month)}${two(d.day)}_${two(d.hour)}${two(d.minute)}';
}

/// Durée "12,4 s".
String shortDuration(Duration d) {
  final seconds = d.inMilliseconds / 1000;
  return '${seconds.toStringAsFixed(1)} s';
}
