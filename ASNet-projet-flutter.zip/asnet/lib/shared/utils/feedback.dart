import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';

enum FeedbackKind { info, success, error }

/// SnackBar uniforme (flottante, icône + texte). Ne lève jamais d'exception.
void showAppSnack(BuildContext context, String message, {FeedbackKind kind = FeedbackKind.info}) {
  final messenger = ScaffoldMessenger.maybeOf(context);
  if (messenger == null) return;
  final palette = context.palette;
  final color = switch (kind) {
    FeedbackKind.success => palette.success,
    FeedbackKind.error => palette.danger,
    FeedbackKind.info => palette.network,
  };
  final icon = switch (kind) {
    FeedbackKind.success => Icons.check_circle_rounded,
    FeedbackKind.error => Icons.error_rounded,
    FeedbackKind.info => Icons.info_rounded,
  };
  messenger
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text(message)),
          ],
        ),
        duration: const Duration(seconds: 3),
      ),
    );
}
