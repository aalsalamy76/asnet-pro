// Décision : demande système d'abord ; si refus (ou refus définitif), dialogue maison qui explique
// pourquoi la permission sert et propose d'ouvrir les paramètres Android.
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../l10n/app_localizations.dart';
import '../theme/app_colors.dart';
import '../theme/app_spacing.dart';

enum AppPermission { location, camera }

class PermissionService {
  const PermissionService();

  Permission _native(AppPermission p) {
    switch (p) {
      case AppPermission.location:
        return Permission.locationWhenInUse;
      case AppPermission.camera:
        return Permission.camera;
    }
  }

  Future<bool> isGranted(AppPermission p) async {
    try {
      final status = await _native(p).status;
      return status.isGranted || status.isLimited;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isLocationServiceEnabled() async {
    try {
      return (await Permission.locationWhenInUse.serviceStatus).isEnabled;
    } catch (_) {
      return true;
    }
  }

  /// Demande brute, sans interface (onboarding).
  Future<bool> request(AppPermission p) async {
    try {
      final status = await _native(p).request();
      return status.isGranted || status.isLimited;
    } catch (_) {
      return false;
    }
  }

  Future<bool> openSettings() async {
    try {
      return await openAppSettings();
    } catch (_) {
      return false;
    }
  }

  /// Demande + dialogue explicatif si refus. Renvoie true si la permission est accordée.
  Future<bool> ensure(BuildContext context, AppPermission p) async {
    final permission = _native(p);
    try {
      var status = await permission.status;
      if (status.isGranted || status.isLimited) return true;
      if (!status.isPermanentlyDenied) {
        status = await permission.request();
        if (status.isGranted || status.isLimited) return true;
      }
      if (!context.mounted) return false;
      final openSettingsChoice = await showPermissionRationale(context, p);
      if (openSettingsChoice == true) await openSettings();
    } catch (_) {
      // Plugin indisponible : on considère la permission comme refusée.
    }
    return false;
  }

  static Future<bool?> showPermissionRationale(BuildContext context, AppPermission p) {
    final l = context.l10n;
    final palette = context.palette;
    final isLocation = p == AppPermission.location;
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: palette.surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSpacing.radiusLg),
          side: BorderSide(color: palette.glassBorder),
        ),
        icon: Icon(
          isLocation ? Icons.location_on_rounded : Icons.photo_camera_rounded,
          color: isLocation ? palette.network : palette.share,
          size: 32,
        ),
        title: Text(l.t(isLocation ? 'perm_location_title' : 'perm_camera_title')),
        content: Text(
          l.t(isLocation ? 'perm_location_rationale' : 'perm_camera_rationale'),
          style: TextStyle(color: palette.muted, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(l.t('later')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(l.t('open_settings')),
          ),
        ],
      ),
    );
  }
}
