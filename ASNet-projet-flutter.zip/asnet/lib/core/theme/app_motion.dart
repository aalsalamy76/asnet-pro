// Décision : une seule courbe de marque (cubic-bezier(0.32, 0.72, 0, 1)) et 3 durées 240/280/320 ms.
import 'package:flutter/animation.dart';
import 'package:flutter/services.dart';

class AppMotion {
  AppMotion._();

  static const Duration fast = Duration(milliseconds: 240);
  static const Duration base = Duration(milliseconds: 280);
  static const Duration slow = Duration(milliseconds: 320);

  static const Curve ease = Cubic(0.32, 0.72, 0, 1);

  /// Retour haptique léger au tap (silencieux si l'appareil ne le gère pas).
  static Future<void> tap() async {
    try {
      await HapticFeedback.lightImpact();
    } catch (_) {}
  }

  static Future<void> confirm() async {
    try {
      await HapticFeedback.mediumImpact();
    } catch (_) {}
  }
}
