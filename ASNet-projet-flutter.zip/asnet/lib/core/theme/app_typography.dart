// Décision : Inter pour l'UI, JetBrains Mono pour IP/MAC, chiffres tabulaires partout où des nombres changent.
// google_fonts télécharge la police au premier lancement puis la met en cache ; hors-ligne -> police système.
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_colors.dart';

class AppTypography {
  AppTypography._();

  static const List<FontFeature> tabular = [FontFeature.tabularFigures()];

  static TextTheme textTheme(Brightness brightness, AppPalette palette) {
    final base = brightness == Brightness.dark
        ? Typography.material2021(platform: TargetPlatform.android).white
        : Typography.material2021(platform: TargetPlatform.android).black;
    final inter = GoogleFonts.interTextTheme(base).apply(
      bodyColor: palette.text,
      displayColor: palette.text,
    );
    return inter.copyWith(
      displaySmall: inter.displaySmall?.copyWith(
        fontWeight: FontWeight.w800,
        letterSpacing: -1.0,
        fontFeatures: tabular,
      ),
      headlineMedium: inter.headlineMedium?.copyWith(
        fontWeight: FontWeight.w800,
        letterSpacing: -0.6,
      ),
      headlineSmall: inter.headlineSmall?.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: -0.4,
      ),
      titleLarge: inter.titleLarge?.copyWith(fontWeight: FontWeight.w700),
      titleMedium: inter.titleMedium?.copyWith(fontWeight: FontWeight.w600),
      labelLarge: inter.labelLarge?.copyWith(fontWeight: FontWeight.w700),
      bodySmall: inter.bodySmall?.copyWith(color: palette.muted),
    );
  }

  /// Style monospace pour les adresses IP / MAC.
  static TextStyle mono({
    double size = 14,
    FontWeight weight = FontWeight.w500,
    Color? color,
  }) {
    return GoogleFonts.jetBrainsMono(
      fontSize: size,
      fontWeight: weight,
      color: color,
      fontFeatures: tabular,
      letterSpacing: 0,
    );
  }
}
