import 'package:flutter/material.dart';

import 'app_colors.dart';
import 'app_motion.dart';
import 'app_typography.dart';

class AppTheme {
  AppTheme._();

  // Construits une seule fois (google_fonts + ColorScheme.fromSeed coûtent un peu).
  static final ThemeData _dark = _build(Brightness.dark, AppPalette.dark);
  static final ThemeData _light = _build(Brightness.light, AppPalette.light);

  static ThemeData dark() => _dark;
  static ThemeData light() => _light;

  static ThemeData _build(Brightness brightness, AppPalette p) {
    final scheme = ColorScheme.fromSeed(
      seedColor: AppColors.cyan,
      brightness: brightness,
    ).copyWith(
      primary: p.network,
      onPrimary: p.onAccent,
      secondary: p.share,
      onSecondary: Colors.white,
      error: p.danger,
      onError: Colors.white,
      surface: p.surface,
      onSurface: p.text,
      outline: p.glassBorder,
    );
    final text = AppTypography.textTheme(brightness, p);
    final radius16 = BorderRadius.circular(16);

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: p.background,
      canvasColor: p.background,
      textTheme: text,
      extensions: <ThemeExtension<dynamic>>[p],
      iconTheme: IconThemeData(color: p.text),
      dividerTheme: DividerThemeData(color: p.glassBorder, thickness: 1, space: 1),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        foregroundColor: p.text,
        centerTitle: false,
        titleTextStyle: text.titleLarge,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: p.surface,
        contentTextStyle: text.bodyMedium?.copyWith(color: p.text),
        actionTextColor: p.network,
        shape: RoundedRectangleBorder(
          borderRadius: radius16,
          side: BorderSide(color: p.glassBorder),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        height: 68,
        indicatorColor: p.network.faded(0.16),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return text.labelSmall?.copyWith(
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected ? p.text : p.muted,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return IconThemeData(color: selected ? p.network : p.muted, size: 24);
        }),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: p.surface.faded(brightness == Brightness.dark ? 0.55 : 0.9),
        labelStyle: TextStyle(color: p.muted),
        hintStyle: TextStyle(color: p.muted),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(borderRadius: radius16, borderSide: BorderSide(color: p.glassBorder)),
        enabledBorder: OutlineInputBorder(borderRadius: radius16, borderSide: BorderSide(color: p.glassBorder)),
        focusedBorder: OutlineInputBorder(
          borderRadius: radius16,
          borderSide: BorderSide(color: p.network, width: 1.6),
        ),
        errorBorder: OutlineInputBorder(borderRadius: radius16, borderSide: BorderSide(color: p.danger)),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: radius16,
          borderSide: BorderSide(color: p.danger, width: 1.6),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: p.network,
          foregroundColor: p.onAccent,
          minimumSize: const Size(48, 52),
          shape: RoundedRectangleBorder(borderRadius: radius16),
          textStyle: text.labelLarge,
          animationDuration: AppMotion.fast,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: p.text,
          minimumSize: const Size(48, 52),
          side: BorderSide(color: p.glassBorder.faded(0.25)),
          shape: RoundedRectangleBorder(borderRadius: radius16),
          textStyle: text.labelLarge,
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: p.network,
          minimumSize: const Size(48, 48),
          textStyle: text.labelLarge,
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: p.surface,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        dragHandleColor: p.muted,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
      ),
      listTileTheme: ListTileThemeData(
        iconColor: p.muted,
        textColor: p.text,
        minVerticalPadding: 12,
        shape: RoundedRectangleBorder(borderRadius: radius16),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: p.network,
        linearTrackColor: p.glassBorder,
        circularTrackColor: p.glassBorder,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected) ? p.onAccent : p.muted,
        ),
        trackColor: WidgetStateProperty.resolveWith(
          (states) => states.contains(WidgetState.selected) ? p.network : p.glassBorder,
        ),
      ),
    );
  }
}
