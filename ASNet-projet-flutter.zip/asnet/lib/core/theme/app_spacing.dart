import 'package:flutter/widgets.dart';

class AppSpacing {
  AppSpacing._();

  static const double xxs = 2;
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 20;
  static const double xxl = 24;
  static const double xxxl = 32;

  static const double radiusSm = 12;
  static const double radiusMd = 20;
  static const double radiusLg = 28;
  static const double radiusXl = 36;

  /// Marge d'écran : laisse la place à la barre de navigation flottante en bas.
  static const EdgeInsets screen = EdgeInsets.fromLTRB(16, 8, 16, 120);

  /// Taille minimale des zones tactiles (Material / WCAG).
  static const double minTouch = 48;
}
