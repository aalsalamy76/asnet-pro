// Décision : couleurs brutes dans AppColors + couleurs sémantiques dans une ThemeExtension
// (AppPalette) pour basculer dark/light sans dupliquer un seul widget.
import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Identité "Liquid Glass 2.0" (dark-first)
  static const Color bg = Color(0xFF0A0E1A);
  static const Color surfaceDark = Color(0xFF131A2B);
  static const Color cyan = Color(0xFF00E5FF); // réseau
  static const Color violet = Color(0xFF7C3AED); // partage
  static const Color success = Color(0xFF10B981);
  static const Color warning = Color(0xFFF59E0B);
  static const Color danger = Color(0xFFEF4444);
  static const Color text = Color(0xFFF8FAFC);
  static const Color muted = Color(0xFF94A3B8);

  // Variantes du thème clair (contraste AA >= 4.5:1 sur fond clair)
  static const Color bgLight = Color(0xFFF1F5F9);
  static const Color surfaceLight = Color(0xFFFFFFFF);
  static const Color textLight = Color(0xFF0F172A);
  static const Color mutedLight = Color(0xFF475569);
  static const Color cyanDeep = Color(0xFF0E7490);
  static const Color violetDeep = Color(0xFF6D28D9);
  static const Color successDeep = Color(0xFF047857);
  static const Color warningDeep = Color(0xFFB45309);
  static const Color dangerDeep = Color(0xFFB91C1C);
}

/// Opacité portable (évite withOpacity/withValues qui diffèrent selon la version de Flutter).
extension ColorAlpha on Color {
  Color faded(double opacity) {
    final o = opacity < 0 ? 0.0 : (opacity > 1 ? 1.0 : opacity);
    return withAlpha((o * 255).round());
  }
}

@immutable
class AppPalette extends ThemeExtension<AppPalette> {
  const AppPalette({
    required this.background,
    required this.surface,
    required this.glass,
    required this.glassBorder,
    required this.text,
    required this.muted,
    required this.network,
    required this.share,
    required this.success,
    required this.warning,
    required this.danger,
    required this.onAccent,
  });

  final Color background;
  final Color surface;
  final Color glass;
  final Color glassBorder;
  final Color text;
  final Color muted;
  final Color network;
  final Color share;
  final Color success;
  final Color warning;
  final Color danger;
  final Color onAccent;

  static const AppPalette dark = AppPalette(
    background: AppColors.bg,
    surface: AppColors.surfaceDark,
    glass: Color(0x99161E31), // opacité 0.6
    glassBorder: Color(0x1AFFFFFF), // blanc 10 %
    text: AppColors.text,
    muted: AppColors.muted,
    network: AppColors.cyan,
    share: AppColors.violet,
    success: AppColors.success,
    warning: AppColors.warning,
    danger: AppColors.danger,
    onAccent: AppColors.bg,
  );

  static const AppPalette light = AppPalette(
    background: AppColors.bgLight,
    surface: AppColors.surfaceLight,
    glass: Color(0x99FFFFFF),
    glassBorder: Color(0x1A0F172A),
    text: AppColors.textLight,
    muted: AppColors.mutedLight,
    network: AppColors.cyanDeep,
    share: AppColors.violetDeep,
    success: AppColors.successDeep,
    warning: AppColors.warningDeep,
    danger: AppColors.dangerDeep,
    onAccent: Colors.white,
  );

  @override
  AppPalette copyWith({
    Color? background,
    Color? surface,
    Color? glass,
    Color? glassBorder,
    Color? text,
    Color? muted,
    Color? network,
    Color? share,
    Color? success,
    Color? warning,
    Color? danger,
    Color? onAccent,
  }) {
    return AppPalette(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      glass: glass ?? this.glass,
      glassBorder: glassBorder ?? this.glassBorder,
      text: text ?? this.text,
      muted: muted ?? this.muted,
      network: network ?? this.network,
      share: share ?? this.share,
      success: success ?? this.success,
      warning: warning ?? this.warning,
      danger: danger ?? this.danger,
      onAccent: onAccent ?? this.onAccent,
    );
  }

  @override
  AppPalette lerp(ThemeExtension<AppPalette>? other, double t) {
    if (other is! AppPalette) return this;
    return AppPalette(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      glass: Color.lerp(glass, other.glass, t)!,
      glassBorder: Color.lerp(glassBorder, other.glassBorder, t)!,
      text: Color.lerp(text, other.text, t)!,
      muted: Color.lerp(muted, other.muted, t)!,
      network: Color.lerp(network, other.network, t)!,
      share: Color.lerp(share, other.share, t)!,
      success: Color.lerp(success, other.success, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      danger: Color.lerp(danger, other.danger, t)!,
      onAccent: Color.lerp(onAccent, other.onAccent, t)!,
    );
  }
}

extension AppPaletteContext on BuildContext {
  AppPalette get palette => Theme.of(this).extension<AppPalette>() ?? AppPalette.dark;
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
}
