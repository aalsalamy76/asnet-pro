// Décision : StatefulShellRoute.indexedStack -> chaque onglet garde son état et son scroll ;
// l'onboarding est hors du shell (pas de barre de navigation).
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/dashboard/dashboard_screen.dart';
import '../../features/onboarding/onboarding_screen.dart';
import '../../features/scan/scan_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/share/share_screen.dart';
import '../../features/tools/tools_screen.dart';
import '../../shared/widgets/glass_card.dart';
import '../l10n/app_localizations.dart';
import '../providers/app_providers.dart';
import '../theme/app_colors.dart';
import '../theme/app_motion.dart';

class AppRoutes {
  AppRoutes._();

  static const String onboarding = '/onboarding';
  static const String dashboard = '/dashboard';
  static const String scan = '/scan';
  static const String tools = '/tools';
  static const String share = '/share';
  static const String settings = '/settings';
}

final routerProvider = Provider<GoRouter>((ref) {
  final prefs = ref.watch(sharedPreferencesProvider);
  final onboardingDone = prefs.getBool(onboardingDoneKey) ?? false;

  final router = GoRouter(
    initialLocation: onboardingDone ? AppRoutes.dashboard : AppRoutes.onboarding,
    routes: [
      GoRoute(
        path: '/',
        redirect: (context, state) => AppRoutes.dashboard,
      ),
      GoRoute(
        path: AppRoutes.onboarding,
        builder: (context, state) => const OnboardingScreen(),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) => AppShell(navigationShell: navigationShell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.dashboard,
              builder: (context, state) => const DashboardScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.scan,
              builder: (context, state) => const ScanScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.tools,
              builder: (context, state) => const ToolsScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.share,
              builder: (context, state) => const ShareScreen(),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: AppRoutes.settings,
              builder: (context, state) => const SettingsScreen(),
            ),
          ]),
        ],
      ),
    ],
    errorBuilder: (context, state) => const _RouteNotFound(),
  );
  ref.onDispose(router.dispose);
  return router;
});

/// Coque commune aux 4 onglets : fond liquide + barre de navigation en verre flottante.
class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.navigationShell});

  final StatefulNavigationShell navigationShell;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    return Scaffold(
      extendBody: true,
      backgroundColor: p.background,
      body: LiquidBackground(child: navigationShell),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
            child: DecoratedBox(
              decoration: BoxDecoration(
                color: p.glass,
                borderRadius: BorderRadius.circular(28),
                border: Border.all(color: p.glassBorder),
              ),
              child: NavigationBar(
                selectedIndex: navigationShell.currentIndex,
                labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
                animationDuration: AppMotion.slow,
                onDestinationSelected: (index) {
                  AppMotion.tap();
                  navigationShell.goBranch(
                    index,
                    initialLocation: index == navigationShell.currentIndex,
                  );
                },
                destinations: [
                  NavigationDestination(
                    icon: const Icon(Icons.dashboard_outlined),
                    selectedIcon: const Icon(Icons.dashboard_rounded),
                    label: l.t('nav_dashboard'),
                    tooltip: l.t('nav_dashboard'),
                  ),
                  NavigationDestination(
                    icon: const Icon(Icons.track_changes_outlined),
                    selectedIcon: const Icon(Icons.track_changes_rounded),
                    label: l.t('nav_scan'),
                    tooltip: l.t('nav_scan'),
                  ),
                  NavigationDestination(
                    icon: const Icon(Icons.build_outlined),
                    selectedIcon: const Icon(Icons.build_rounded),
                    label: l.t('nav_tools'),
                    tooltip: l.t('nav_tools'),
                  ),
                  NavigationDestination(
                    icon: const Icon(Icons.qr_code_outlined),
                    selectedIcon: const Icon(Icons.qr_code_rounded),
                    label: l.t('nav_share'),
                    tooltip: l.t('nav_share'),
                  ),
                  NavigationDestination(
                    icon: const Icon(Icons.tune_outlined),
                    selectedIcon: const Icon(Icons.tune_rounded),
                    label: l.t('nav_settings'),
                    tooltip: l.t('nav_settings'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _RouteNotFound extends StatelessWidget {
  const _RouteNotFound();

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.explore_off_rounded, size: 48, color: context.palette.muted),
            const SizedBox(height: 12),
            Text(l.t('route_not_found')),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () => GoRouter.of(context).go(AppRoutes.dashboard),
              child: Text(l.t('back_home')),
            ),
          ],
        ),
      ),
    );
  }
}
