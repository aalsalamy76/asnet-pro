// Décision : catalogue embarqué des ports courants (nom du service) + liste des ports à risque
// utilisée par l'audit de sécurité.
class PortsCatalog {
  PortsCatalog._();

  static const Map<int, String> services = {
    20: 'FTP-data', 21: 'FTP', 22: 'SSH', 23: 'Telnet', 25: 'SMTP', 53: 'DNS', 67: 'DHCP',
    69: 'TFTP', 80: 'HTTP', 81: 'HTTP-alt', 88: 'Kerberos', 110: 'POP3', 111: 'RPCbind',
    119: 'NNTP', 123: 'NTP', 135: 'MS-RPC', 137: 'NetBIOS-NS', 139: 'NetBIOS-SSN', 143: 'IMAP',
    161: 'SNMP', 389: 'LDAP', 443: 'HTTPS', 445: 'SMB', 465: 'SMTPS', 514: 'Syslog', 515: 'LPD',
    548: 'AFP', 554: 'RTSP', 587: 'SMTP-sub', 631: 'IPP', 636: 'LDAPS', 853: 'DNS-over-TLS',
    873: 'rsync', 993: 'IMAPS', 995: 'POP3S', 1080: 'SOCKS', 1194: 'OpenVPN', 1433: 'MSSQL',
    1521: 'Oracle', 1723: 'PPTP', 1883: 'MQTT', 1900: 'UPnP', 2049: 'NFS', 2375: 'Docker',
    2376: 'Docker-TLS', 3000: 'HTTP-dev', 3128: 'Proxy', 3306: 'MySQL', 3389: 'RDP', 3689: 'DAAP',
    4433: 'HTTPS-alt', 5000: 'UPnP / Synology', 5001: 'Synology HTTPS', 5060: 'SIP', 5222: 'XMPP',
    5353: 'mDNS', 5357: 'WSD', 5432: 'PostgreSQL', 5555: 'ADB', 5900: 'VNC', 5985: 'WinRM',
    6379: 'Redis', 6443: 'Kubernetes', 6667: 'IRC', 7000: 'AirPlay', 7547: 'TR-069',
    8000: 'HTTP-alt', 8008: 'Chromecast', 8009: 'Chromecast', 8080: 'HTTP-proxy', 8081: 'HTTP-alt',
    8088: 'HTTP-alt', 8123: 'Home Assistant', 8291: 'MikroTik Winbox', 8443: 'HTTPS-alt',
    8554: 'RTSP-alt', 8883: 'MQTT-TLS', 8888: 'HTTP-alt', 9000: 'HTTP-alt', 9090: 'Web admin',
    9100: 'JetDirect (imprimante)', 9200: 'Elasticsearch', 10000: 'Webmin', 11211: 'Memcached',
    27017: 'MongoDB', 32400: 'Plex', 49152: 'UPnP', 62078: 'iPhone sync',
  };

  /// Ports "courants" (catalogue complet, trié).
  static List<int> get common => services.keys.toList()..sort();

  /// Ports rapides pour la fiche appareil.
  static const List<int> quick = [
    21, 22, 23, 53, 80, 139, 443, 445, 554, 631, 1883, 3389, 5000, 5555, 5900, 7000, 8008, 8080,
    8443, 9100, 32400, 62078,
  ];

  /// Ports vérifiés sur la passerelle par l'audit.
  static const List<int> gatewayAudit = [21, 22, 23, 80, 443, 445, 2375, 3389, 5000, 5900, 7547, 8080, 8291, 8443];

  /// Ports dangereux s'ils sont ouverts sur un appareil du réseau local.
  static const List<int> riskyDevice = [21, 23, 445, 1883, 2375, 3389, 5555, 5900, 6379, 9200, 11211, 27017, 554];

  static String nameOf(int port) => services[port] ?? '—';

  static bool isHttp(int port) => const {80, 81, 3000, 5000, 8000, 8008, 8080, 8081, 8088, 8123, 8888, 9000, 9090}.contains(port);

  static bool isHttps(int port) => const {443, 4433, 5001, 8443}.contains(port);

  /// "22,80,8000-8100" -> liste triée sans doublons (1..65535). null si invalide.
  static List<int>? parse(String text) {
    final result = <int>{};
    for (final raw in text.split(RegExp(r'[,\s;]+'))) {
      final part = raw.trim();
      if (part.isEmpty) continue;
      final range = part.split('-');
      if (range.length == 1) {
        final p = int.tryParse(range[0]);
        if (p == null || p < 1 || p > 65535) return null;
        result.add(p);
      } else if (range.length == 2) {
        final a = int.tryParse(range[0]);
        final b = int.tryParse(range[1]);
        if (a == null || b == null || a < 1 || b > 65535 || a > b) return null;
        for (var p = a; p <= b; p++) {
          result.add(p);
        }
      } else {
        return null;
      }
    }
    if (result.isEmpty) return null;
    return result.toList()..sort();
  }
}
