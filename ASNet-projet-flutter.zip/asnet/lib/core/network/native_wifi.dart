// Décision : pont unique vers le code natif (MainActivity.kt) ; chaque appel est protégé
// (try/catch + timeout) et renvoie une valeur neutre en cas d'échec.
import 'dart:async';

import 'package:flutter/services.dart';

class WifiLinkInfo {
  const WifiLinkInfo({
    required this.rssi,
    required this.linkSpeed,
    required this.frequency,
    this.txLinkSpeed,
    this.rxLinkSpeed,
    this.wifiStandard,
  });

  final int rssi;
  final int linkSpeed;
  final int frequency;
  final int? txLinkSpeed;
  final int? rxLinkSpeed;
  final int? wifiStandard;

  int get channel => WifiBands.channelOf(frequency);
  String get band => WifiBands.bandOf(frequency);
  int get quality => WifiBands.qualityOf(rssi);

  String get standardLabel {
    switch (wifiStandard) {
      case 1:
        return '802.11a/b/g';
      case 4:
        return 'Wi-Fi 4 (802.11n)';
      case 5:
        return 'Wi-Fi 5 (802.11ac)';
      case 6:
        return 'Wi-Fi 6 (802.11ax)';
      case 7:
        return '802.11ad';
      case 8:
        return 'Wi-Fi 7 (802.11be)';
      default:
        return '—';
    }
  }
}

class WifiAccessPoint {
  const WifiAccessPoint({
    required this.ssid,
    required this.bssid,
    required this.level,
    required this.frequency,
    required this.capabilities,
    required this.security,
    required this.channelWidth,
  });

  final String ssid;
  final String bssid;
  final int level;
  final int frequency;
  final String capabilities;
  final String security;
  final int channelWidth;

  int get channel => WifiBands.channelOf(frequency);
  String get band => WifiBands.bandOf(frequency);
  int get quality => WifiBands.qualityOf(level);
  bool get isHidden => ssid.trim().isEmpty;

  int get widthMhz {
    switch (channelWidth) {
      case 1:
        return 40;
      case 2:
        return 80;
      case 3:
      case 4:
        return 160;
      case 5:
        return 320;
      default:
        return 20;
    }
  }
}

class WifiBands {
  WifiBands._();

  static int channelOf(int frequency) {
    if (frequency == 2484) return 14;
    if (frequency >= 2412 && frequency <= 2472) return (frequency - 2407) ~/ 5;
    if (frequency >= 5925 && frequency <= 7125) return (frequency - 5950) ~/ 5;
    if (frequency >= 5000 && frequency < 5925) return (frequency - 5000) ~/ 5;
    return 0;
  }

  static String bandOf(int frequency) {
    if (frequency >= 2400 && frequency < 2500) return '2.4 GHz';
    if (frequency >= 5925) return '6 GHz';
    if (frequency >= 4900) return '5 GHz';
    return '—';
  }

  /// dBm -> qualité 0..100 (-100 dBm = 0 %, -50 dBm = 100 %).
  static int qualityOf(int dbm) {
    final q = 2 * (dbm + 100);
    if (q < 0) return 0;
    if (q > 100) return 100;
    return q;
  }
}

class NativeWifi {
  NativeWifi._();

  static const MethodChannel _channel = MethodChannel('com.asnet.app/wifi');
  static const Duration _timeout = Duration(seconds: 5);

  static Future<String?> securityType() async {
    try {
      return await _channel.invokeMethod<String>('getSecurityType').timeout(_timeout);
    } catch (_) {
      return null;
    }
  }

  static Future<WifiLinkInfo?> linkInfo() async {
    try {
      final raw = await _channel.invokeMethod<Map<dynamic, dynamic>>('getLinkInfo').timeout(_timeout);
      if (raw == null || raw['rssi'] == null) return null;
      int? asInt(Object? v) => v is int ? v : (v is num ? v.toInt() : null);
      return WifiLinkInfo(
        rssi: asInt(raw['rssi']) ?? -127,
        linkSpeed: asInt(raw['linkSpeed']) ?? 0,
        frequency: asInt(raw['frequency']) ?? 0,
        txLinkSpeed: asInt(raw['txLinkSpeed']),
        rxLinkSpeed: asInt(raw['rxLinkSpeed']),
        wifiStandard: asInt(raw['wifiStandard']),
      );
    } catch (_) {
      return null;
    }
  }

  /// Lance un scan puis relit les résultats après [settle] (le scan Android est asynchrone).
  static Future<List<WifiAccessPoint>> scan({Duration settle = const Duration(milliseconds: 2500)}) async {
    try {
      await _channel.invokeMethod<List<dynamic>>('scanWifi').timeout(_timeout);
      await Future<void>.delayed(settle);
      final raw = await _channel.invokeMethod<List<dynamic>>('scanWifi').timeout(_timeout);
      if (raw == null) return const [];
      final list = <WifiAccessPoint>[];
      for (final item in raw) {
        if (item is! Map) continue;
        int asInt(Object? v) => v is int ? v : (v is num ? v.toInt() : 0);
        list.add(WifiAccessPoint(
          ssid: '${item['ssid'] ?? ''}',
          bssid: '${item['bssid'] ?? ''}'.toUpperCase(),
          level: asInt(item['level']),
          frequency: asInt(item['frequency']),
          capabilities: '${item['capabilities'] ?? ''}',
          security: '${item['security'] ?? ''}',
          channelWidth: asInt(item['channelWidth']),
        ));
      }
      list.sort((a, b) => b.level.compareTo(a.level));
      return list;
    } catch (_) {
      return const [];
    }
  }

  static Future<bool> acquireMulticast() async {
    try {
      return await _channel.invokeMethod<bool>('acquireMulticastLock').timeout(_timeout) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> releaseMulticast() async {
    try {
      await _channel.invokeMethod<bool>('releaseMulticastLock').timeout(_timeout);
    } catch (_) {}
  }
}
