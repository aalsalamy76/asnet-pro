// Décision : encodeur/décodeur DNS minimal maison (RFC 1035 + compression de noms) partagé par
// l'outil DNS (requêtes unicast UDP/53) et la découverte mDNS/Bonjour (multicast UDP/5353).
import 'dart:convert';
import 'dart:typed_data';

class DnsQuestion {
  const DnsQuestion(this.name, this.type, {this.unicastResponse = false});

  final String name;
  final int type;

  /// Bit QU (mDNS) : demande une réponse unicast.
  final bool unicastResponse;
}

class DnsRecord {
  const DnsRecord({
    required this.name,
    required this.type,
    required this.ttl,
    required this.data,
    this.priority,
    this.port,
    this.texts = const [],
  });

  final String name;
  final int type;
  final int ttl;

  /// Valeur lisible (IP, nom cible, texte…).
  final String data;

  /// MX : préférence ; SRV : priorité.
  final int? priority;

  /// SRV : port du service.
  final int? port;

  /// TXT : chaînes individuelles.
  final List<String> texts;

  String get typeName => DnsCodec.typeName(type);
}

class DnsMessage {
  const DnsMessage({
    required this.id,
    required this.flags,
    required this.questions,
    required this.answers,
    required this.authorities,
    required this.additionals,
  });

  final int id;
  final int flags;
  final List<String> questions;
  final List<DnsRecord> answers;
  final List<DnsRecord> authorities;
  final List<DnsRecord> additionals;

  bool get isResponse => (flags & 0x8000) != 0;
  int get rcode => flags & 0x000F;
  bool get truncated => (flags & 0x0200) != 0;

  List<DnsRecord> get allRecords => [...answers, ...authorities, ...additionals];

  String get rcodeName {
    switch (rcode) {
      case 0:
        return 'NOERROR';
      case 1:
        return 'FORMERR';
      case 2:
        return 'SERVFAIL';
      case 3:
        return 'NXDOMAIN';
      case 4:
        return 'NOTIMP';
      case 5:
        return 'REFUSED';
      default:
        return 'RCODE $rcode';
    }
  }
}

class _NameRead {
  const _NameRead(this.name, this.next);

  final String name;
  final int next;
}

class DnsCodec {
  DnsCodec._();

  static const int typeA = 1;
  static const int typeNS = 2;
  static const int typeCNAME = 5;
  static const int typeSOA = 6;
  static const int typePTR = 12;
  static const int typeMX = 15;
  static const int typeTXT = 16;
  static const int typeAAAA = 28;
  static const int typeSRV = 33;
  static const int typeANY = 255;

  static const Map<String, int> types = {
    'A': typeA,
    'AAAA': typeAAAA,
    'CNAME': typeCNAME,
    'MX': typeMX,
    'TXT': typeTXT,
    'NS': typeNS,
    'SOA': typeSOA,
    'PTR': typePTR,
    'SRV': typeSRV,
  };

  static String typeName(int type) {
    for (final entry in types.entries) {
      if (entry.value == type) return entry.key;
    }
    if (type == typeANY) return 'ANY';
    return 'TYPE$type';
  }

  /// "192.168.1.10" -> "10.1.168.192.in-addr.arpa".
  static String reverseName(String ipv4) {
    final parts = ipv4.split('.');
    if (parts.length != 4) return ipv4;
    return '${parts.reversed.join('.')}.in-addr.arpa';
  }

  static Uint8List buildQuery(int id, List<DnsQuestion> questions, {bool recursionDesired = true}) {
    final b = <int>[];
    void u16(int v) {
      b.add((v >> 8) & 0xFF);
      b.add(v & 0xFF);
    }

    u16(id & 0xFFFF);
    u16(recursionDesired ? 0x0100 : 0x0000);
    u16(questions.length);
    u16(0);
    u16(0);
    u16(0);
    for (final q in questions) {
      for (final label in q.name.split('.')) {
        if (label.isEmpty) continue;
        final bytes = utf8.encode(label);
        final length = bytes.length > 63 ? 63 : bytes.length;
        b.add(length);
        b.addAll(bytes.take(length));
      }
      b.add(0);
      u16(q.type);
      u16(q.unicastResponse ? 0x8001 : 0x0001);
    }
    return Uint8List.fromList(b);
  }

  static DnsMessage? parse(Uint8List data) {
    if (data.length < 12) return null;
    try {
      int u16(int o) => (data[o] << 8) | data[o + 1];
      int u32(int o) => (u16(o) << 16) | u16(o + 2);

      final id = u16(0);
      final flags = u16(2);
      final qd = u16(4);
      final an = u16(6);
      final ns = u16(8);
      final ar = u16(10);
      var offset = 12;

      final questions = <String>[];
      for (var i = 0; i < qd; i++) {
        final n = _readName(data, offset);
        questions.add(n.name);
        offset = n.next + 4;
      }

      List<DnsRecord> readRecords(int count) {
        final records = <DnsRecord>[];
        for (var i = 0; i < count; i++) {
          if (offset + 10 > data.length) break;
          final n = _readName(data, offset);
          offset = n.next;
          if (offset + 10 > data.length) break;
          final type = u16(offset);
          final ttl = u32(offset + 4);
          final rdLength = u16(offset + 8);
          final rdStart = offset + 10;
          final rdEnd = rdStart + rdLength;
          if (rdEnd > data.length) break;
          final record = _decodeRecord(data, n.name, type, ttl, rdStart, rdEnd);
          if (record != null) records.add(record);
          offset = rdEnd;
        }
        return records;
      }

      final answers = readRecords(an);
      final authorities = readRecords(ns);
      final additionals = readRecords(ar);
      return DnsMessage(
        id: id,
        flags: flags,
        questions: questions,
        answers: answers,
        authorities: authorities,
        additionals: additionals,
      );
    } catch (_) {
      return null;
    }
  }

  static DnsRecord? _decodeRecord(Uint8List data, String name, int type, int ttl, int start, int end) {
    int u16(int o) => (data[o] << 8) | data[o + 1];
    int u32(int o) => (u16(o) << 16) | u16(o + 2);

    switch (type) {
      case typeA:
        if (end - start != 4) return null;
        return DnsRecord(
          name: name,
          type: type,
          ttl: ttl,
          data: '${data[start]}.${data[start + 1]}.${data[start + 2]}.${data[start + 3]}',
        );
      case typeAAAA:
        if (end - start != 16) return null;
        final groups = <String>[
          for (var i = start; i < end; i += 2) u16(i).toRadixString(16),
        ];
        return DnsRecord(name: name, type: type, ttl: ttl, data: _compressIpv6(groups));
      case typeNS:
      case typeCNAME:
      case typePTR:
        return DnsRecord(name: name, type: type, ttl: ttl, data: _readName(data, start).name);
      case typeMX:
        final preference = u16(start);
        return DnsRecord(
          name: name,
          type: type,
          ttl: ttl,
          priority: preference,
          data: _readName(data, start + 2).name,
        );
      case typeSRV:
        final priority = u16(start);
        final port = u16(start + 4);
        final target = _readName(data, start + 6).name;
        return DnsRecord(
          name: name,
          type: type,
          ttl: ttl,
          priority: priority,
          port: port,
          data: '$target:$port',
        );
      case typeTXT:
        final texts = <String>[];
        var pos = start;
        while (pos < end) {
          final len = data[pos];
          final s = pos + 1;
          final e = s + len;
          if (e > end) break;
          texts.add(utf8.decode(data.sublist(s, e), allowMalformed: true));
          pos = e;
        }
        return DnsRecord(name: name, type: type, ttl: ttl, data: texts.join(' '), texts: texts);
      case typeSOA:
        final mname = _readName(data, start);
        final rname = _readName(data, mname.next);
        final p = rname.next;
        if (p + 20 > end) {
          return DnsRecord(name: name, type: type, ttl: ttl, data: '${mname.name} ${rname.name}');
        }
        return DnsRecord(
          name: name,
          type: type,
          ttl: ttl,
          data: '${mname.name} ${rname.name} serial=${u32(p)} refresh=${u32(p + 4)} '
              'retry=${u32(p + 8)} expire=${u32(p + 12)} min=${u32(p + 16)}',
        );
      default:
        return DnsRecord(name: name, type: type, ttl: ttl, data: '(${end - start} octets)');
    }
  }

  static _NameRead _readName(Uint8List data, int offset) {
    final labels = <String>[];
    var pos = offset;
    var next = -1;
    var guard = 0;
    while (pos < data.length && guard < 128) {
      guard++;
      final len = data[pos];
      if (len == 0) {
        if (next < 0) next = pos + 1;
        break;
      }
      if ((len & 0xC0) == 0xC0) {
        if (pos + 1 >= data.length) break;
        final pointer = ((len & 0x3F) << 8) | data[pos + 1];
        if (next < 0) next = pos + 2;
        pos = pointer;
        continue;
      }
      final start = pos + 1;
      final stop = start + len;
      if (stop > data.length) break;
      labels.add(utf8.decode(data.sublist(start, stop), allowMalformed: true));
      pos = stop;
    }
    if (next < 0) next = pos + 1;
    return _NameRead(labels.join('.'), next);
  }

  static String _compressIpv6(List<String> groups) {
    var bestStart = -1;
    var bestLen = 0;
    var i = 0;
    while (i < groups.length) {
      if (groups[i] == '0') {
        var j = i;
        while (j < groups.length && groups[j] == '0') {
          j++;
        }
        if (j - i > bestLen && j - i > 1) {
          bestStart = i;
          bestLen = j - i;
        }
        i = j;
      } else {
        i++;
      }
    }
    if (bestStart < 0) return groups.join(':');
    final head = groups.sublist(0, bestStart).join(':');
    final tail = groups.sublist(bestStart + bestLen).join(':');
    return '$head::$tail';
  }
}
