// Décision : localisation maison (Map clé -> texte) plutôt que gen-l10n/ARB :
// aucun fichier généré, compile tel quel. Arabe = RTL automatique via GlobalWidgetsLocalizations.
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import 'app_strings.dart';

class AppLocalizations {
  const AppLocalizations(this.locale);

  final Locale locale;

  static const List<Locale> supportedLocales = [
    Locale('fr'),
    Locale('en'),
    Locale('ar'),
    Locale('es'),
  ];

  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations) ??
        const AppLocalizations(Locale('fr'));
  }

  String get languageCode =>
      appStrings.containsKey(locale.languageCode) ? locale.languageCode : 'fr';

  bool get isRtl => languageCode == 'ar';

  /// Traduit [key] ; remplace les jetons `{nom}` par les valeurs de [args].
  String t(String key, [Map<String, Object?> args = const {}]) {
    var value = appStrings[languageCode]?[key] ?? appStrings['fr']?[key] ?? key;
    if (args.isNotEmpty) {
      args.forEach((name, v) {
        value = value.replaceAll('{$name}', '${v ?? ''}');
      });
    }
    return value;
  }
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => appStrings.containsKey(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) =>
      SynchronousFuture<AppLocalizations>(AppLocalizations(locale));

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

extension AppLocalizationsContext on BuildContext {
  AppLocalizations get l10n => AppLocalizations.of(this);
}
