// Décision : métadonnées "À propos" en constantes (pas de plugin package_info supplémentaire) ;
// à garder synchronisées avec `version:` dans pubspec.yaml.
class AppInfo {
  AppInfo._();

  static const String name = 'A.SNet';
  static const String version = '0.2.0';
  static const int build = 2;
  static const String developer = 'Abdullah AL-SALAMY';
  static const String linkedIn = 'https://www.linkedin.com/in/abdullah-a-2982451a6';
  static const String packageName = 'com.asnet.app';
}
