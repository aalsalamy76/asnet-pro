// Décision : services exposés en Provider simples (injectables/mockables) ; SharedPreferences
// est chargé une fois dans main() puis injecté via override -> lecture synchrone partout.
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../features/scan/models/network_info.dart';
import '../../features/scan/services/device_labels_repository.dart';
import '../../features/scan/services/network_info_service.dart';
import '../../features/scan/services/network_scanner.dart';
import '../../features/scan/services/scan_history_repository.dart';
import '../services/permission_service.dart';

final sharedPreferencesProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('sharedPreferencesProvider doit être surchargé dans main()'),
);

final secureStorageProvider = Provider<FlutterSecureStorage>(
  (ref) => const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  ),
);

final permissionServiceProvider = Provider<PermissionService>((ref) => const PermissionService());

final networkInfoServiceProvider = Provider<NetworkInfoService>((ref) => NetworkInfoService());

final networkScannerProvider = Provider<NetworkScanner>((ref) => NetworkScanner());

final scanHistoryRepositoryProvider = Provider<ScanHistoryRepository>(
  (ref) => ScanHistoryRepository(ref.watch(sharedPreferencesProvider)),
);

final deviceLabelsRepositoryProvider = Provider<DeviceLabelsRepository>(
  (ref) => DeviceLabelsRepository(ref.watch(sharedPreferencesProvider)),
);

/// Flux des changements de connectivité (Wi-Fi <-> données mobiles <-> hors-ligne).
final connectivityProvider = StreamProvider<List<ConnectivityResult>>(
  (ref) => Connectivity().onConnectivityChanged,
);

/// Infos du réseau courant ; recalculées à chaque changement de connectivité.
final networkDetailsProvider = FutureProvider<NetworkDetails>((ref) async {
  ref.watch(connectivityProvider);
  try {
    return await ref.watch(networkInfoServiceProvider).load();
  } catch (_) {
    return NetworkDetails.offline();
  }
});

/// Clé SharedPreferences de fin d'onboarding.
const String onboardingDoneKey = 'asnet.onboarding_done';
