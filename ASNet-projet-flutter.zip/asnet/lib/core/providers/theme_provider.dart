// Décision : Notifier Riverpod (API moderne) ; dark par défaut (identité dark-first), persistance immédiate.
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app_providers.dart';

final themeModeProvider = NotifierProvider<ThemeModeController, ThemeMode>(ThemeModeController.new);

class ThemeModeController extends Notifier<ThemeMode> {
  static const String storageKey = 'asnet.theme_mode';

  @override
  ThemeMode build() {
    final raw = ref.watch(sharedPreferencesProvider).getString(storageKey);
    switch (raw) {
      case 'light':
        return ThemeMode.light;
      case 'system':
        return ThemeMode.system;
      default:
        return ThemeMode.dark;
    }
  }

  Future<void> setMode(ThemeMode mode) async {
    state = mode;
    try {
      await ref.read(sharedPreferencesProvider).setString(storageKey, mode.name);
    } catch (_) {}
  }
}

/// Langue choisie : null = langue du système.
final localeProvider = NotifierProvider<LocaleController, Locale?>(LocaleController.new);

class LocaleController extends Notifier<Locale?> {
  static const String storageKey = 'asnet.locale';
  static const List<String> supported = ['fr', 'en', 'ar', 'es'];

  @override
  Locale? build() {
    final raw = ref.watch(sharedPreferencesProvider).getString(storageKey);
    if (raw == null || !supported.contains(raw)) return null;
    return Locale(raw);
  }

  Future<void> setLanguage(String? code) async {
    final prefs = ref.read(sharedPreferencesProvider);
    if (code == null || !supported.contains(code)) {
      state = null;
      try {
        await prefs.remove(storageKey);
      } catch (_) {}
      return;
    }
    state = Locale(code);
    try {
      await prefs.setString(storageKey, code);
    } catch (_) {}
  }
}
