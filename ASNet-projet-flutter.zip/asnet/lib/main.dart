// Décision : SharedPreferences chargé avant runApp puis injecté dans Riverpod (lecture synchrone),
// et toutes les erreurs non gérées sont journalisées sans faire planter l'app.
import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'core/providers/app_providers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  FlutterError.onError = (details) {
    FlutterError.presentError(details);
  };
  PlatformDispatcher.instance.onError = (error, stack) {
    debugPrint('A.SNet — erreur non gérée : $error');
    return true;
  };

  // Polices : téléchargées une fois puis mises en cache ; hors-ligne -> police système.
  GoogleFonts.config.allowRuntimeFetching = true;

  try {
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  } catch (_) {}

  final prefs = await SharedPreferences.getInstance();

  runApp(
    ProviderScope(
      overrides: [sharedPreferencesProvider.overrideWithValue(prefs)],
      child: const AsnetApp(),
    ),
  );
}
