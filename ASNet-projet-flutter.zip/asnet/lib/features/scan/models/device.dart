import 'package:flutter/foundation.dart';

enum DeviceKind { router, phone, computer, tv, speaker, console, printer, camera, nas, iot, unknown }

@immutable
class Device {
  const Device({
    required this.ip,
    required this.lastSeen,
    this.mac,
    this.hostname,
    this.vendor,
    this.isGateway = false,
    this.isSelf = false,
    this.isNew = false,
    this.isRandomizedMac = false,
    this.label,
    this.trusted = false,
    this.netbiosName,
    this.mdnsName,
    this.model,
    this.upnpName,
    this.services = const [],
    this.latencyMs,
  });

  final String ip;

  /// Adresse MAC normalisée "AA:BB:CC:DD:EE:FF" (null si illisible sur cet Android).
  final String? mac;

  /// Nom DNS inverse.
  final String? hostname;
  final String? vendor;
  final bool isGateway;
  final bool isSelf;
  final bool isNew;
  final bool isRandomizedMac;
  final DateTime lastSeen;

  /// Nom personnalisé donné par l'utilisateur.
  final String? label;

  /// Marqué "de confiance" par l'utilisateur.
  final bool trusted;

  /// Nom Windows (NetBIOS).
  final String? netbiosName;

  /// Nom Bonjour/mDNS (sans ".local").
  final String? mdnsName;

  /// Modèle (TXT mDNS "model=" ou description UPnP).
  final String? model;

  /// Nom UPnP ("friendlyName").
  final String? upnpName;

  /// Services annoncés (mDNS "_airplay._tcp", UPnP "MediaRenderer"...).
  final List<String> services;
  final double? latencyMs;

  /// Valeur numérique de l'IP (tri naturel 192.168.1.2 < 192.168.1.10).
  int get ipValue {
    final parts = ip.split('.');
    if (parts.length != 4) return 0;
    var value = 0;
    for (final p in parts) {
      value = (value << 8) | (int.tryParse(p) ?? 0);
    }
    return value;
  }

  /// Meilleur nom disponible : nom perso > UPnP > mDNS > NetBIOS > DNS > fabricant > IP.
  String get displayName {
    for (final candidate in [label, upnpName, mdnsName, netbiosName, hostname, model, vendor]) {
      if (candidate != null && candidate.trim().isNotEmpty) return candidate.trim();
    }
    return ip;
  }

  DeviceKind get kind {
    if (isGateway) return DeviceKind.router;
    if (isSelf) return DeviceKind.phone;
    final h = [hostname, mdnsName, netbiosName, upnpName, model].whereType<String>().join(' ').toLowerCase();
    final v = (vendor ?? '').toLowerCase();
    final s = services.join(' ').toLowerCase();
    bool any(String text, List<String> needles) => needles.any(text.contains);

    // 1. Services annoncés (le plus fiable).
    if (any(s, ['internetgatewaydevice', 'wanipconnection'])) return DeviceKind.router;
    if (any(s, ['_ipp', '_printer', '_pdl-datastream', 'printer', '_scanner'])) return DeviceKind.printer;
    if (any(s, ['_googlecast', 'mediarenderer', '_androidtvremote', '_amzn-wplay', 'dial'])) {
      return any(h, ['speaker', 'nest', 'home', 'echo', 'sonos']) ? DeviceKind.speaker : DeviceKind.tv;
    }
    if (any(s, ['_sonos', '_spotify-connect', '_raop'])) {
      return any(h, ['appletv', 'apple tv']) ? DeviceKind.tv : DeviceKind.speaker;
    }
    if (any(s, ['_airplay'])) return any(h, ['mac', 'book']) ? DeviceKind.computer : DeviceKind.tv;
    if (any(s, ['_rtsp', 'networkcamera', '_onvif'])) return DeviceKind.camera;
    if (any(s, ['_hap', '_homekit', '_matter', '_hue', '_esphomelib'])) return DeviceKind.iot;
    if (any(s, ['_afpovertcp', '_nfs', 'mediaserver'])) return DeviceKind.nas;
    if (any(s, ['_companion-link', '_apple-mobdev'])) return DeviceKind.phone;
    if (any(s, ['_smb', '_workstation', '_rdp', '_ssh', '_sftp'])) return DeviceKind.computer;

    // 2. Noms.
    if (any(h, ['iphone', 'ipad', 'android', 'galaxy', 'pixel', 'redmi', 'oneplus', 'huawei-', 'phone'])) {
      return DeviceKind.phone;
    }
    if (any(h, ['macbook', 'imac', 'mac-mini', 'desktop', 'laptop', 'thinkpad', '-pc', 'pc-', 'workstation'])) {
      return DeviceKind.computer;
    }
    if (any(h, ['tv', 'chromecast', 'bravia', 'firetv', 'roku', 'appletv', 'shield'])) return DeviceKind.tv;
    if (any(h, ['echo', 'sonos', 'homepod', 'speaker', 'nest-mini', 'google-home'])) return DeviceKind.speaker;
    if (any(h, ['playstation', 'ps4', 'ps5', 'xbox', 'switch', 'nintendo'])) return DeviceKind.console;
    if (any(h, ['printer', 'epson', 'brother', 'canon', 'officejet', 'laserjet', 'deskjet'])) {
      return DeviceKind.printer;
    }
    if (any(h, ['cam', 'ipc', 'doorbell'])) return DeviceKind.camera;
    if (any(h, ['nas', 'diskstation', 'synology', 'qnap'])) return DeviceKind.nas;

    // 3. Fabricant.
    if (any(v, ['sonos'])) return DeviceKind.speaker;
    if (any(v, ['roku'])) return DeviceKind.tv;
    if (any(v, ['nintendo', 'sony interactive'])) return DeviceKind.console;
    if (any(v, ['espressif', 'tuya', 'signify', 'philips', 'raspberry', 'shelly'])) return DeviceKind.iot;
    if (any(v, ['tp-link', 'netgear', 'ubiquiti', 'd-link', 'linksys', 'freebox', 'sagemcom', 'arcadyan', 'cisco', 'avm'])) {
      return DeviceKind.router;
    }
    if (any(v, ['apple', 'samsung', 'xiaomi', 'huawei', 'oneplus', 'oppo', 'motorola', 'google'])) {
      return DeviceKind.phone;
    }
    if (any(v, ['intel', 'dell', 'lenovo', 'hp', 'microsoft', 'asustek'])) return DeviceKind.computer;
    if (netbiosName != null) return DeviceKind.computer;
    return DeviceKind.unknown;
  }

  /// Clé stable pour l'historique et les noms personnalisés.
  String get storageKey {
    final m = mac;
    if (m != null && !isRandomizedMac) return 'mac:$m';
    return 'ip:$ip';
  }

  Device copyWith({
    String? mac,
    String? hostname,
    String? vendor,
    bool? isGateway,
    bool? isSelf,
    bool? isNew,
    DateTime? lastSeen,
    bool? trusted,
    List<String>? services,
  }) {
    return Device(
      ip: ip,
      mac: mac ?? this.mac,
      hostname: hostname ?? this.hostname,
      vendor: vendor ?? this.vendor,
      isGateway: isGateway ?? this.isGateway,
      isSelf: isSelf ?? this.isSelf,
      isNew: isNew ?? this.isNew,
      isRandomizedMac: isRandomizedMac,
      lastSeen: lastSeen ?? this.lastSeen,
      label: label,
      trusted: trusted ?? this.trusted,
      netbiosName: netbiosName,
      mdnsName: mdnsName,
      model: model,
      upnpName: upnpName,
      services: services ?? this.services,
      latencyMs: latencyMs,
    );
  }

  /// Applique (ou retire, si null) le nom personnalisé.
  Device withLabel(String? newLabel, {bool? trusted}) {
    return Device(
      ip: ip,
      mac: mac,
      hostname: hostname,
      vendor: vendor,
      isGateway: isGateway,
      isSelf: isSelf,
      isNew: isNew,
      isRandomizedMac: isRandomizedMac,
      lastSeen: lastSeen,
      label: (newLabel == null || newLabel.trim().isEmpty) ? null : newLabel.trim(),
      trusted: trusted ?? this.trusted,
      netbiosName: netbiosName,
      mdnsName: mdnsName,
      model: model,
      upnpName: upnpName,
      services: services,
      latencyMs: latencyMs,
    );
  }

  Map<String, dynamic> toJson() => {
        'ip': ip,
        'mac': mac,
        'hostname': hostname,
        'vendor': vendor,
        'kind': kind.name,
        'isGateway': isGateway,
        'isSelf': isSelf,
        'isNew': isNew,
        'isRandomizedMac': isRandomizedMac,
        'label': label,
        'trusted': trusted,
        'netbiosName': netbiosName,
        'mdnsName': mdnsName,
        'model': model,
        'upnpName': upnpName,
        'services': services,
        'latencyMs': latencyMs,
        'lastSeen': lastSeen.toIso8601String(),
      };

  factory Device.fromJson(Map<String, dynamic> json) {
    final rawServices = json['services'];
    final rawLatency = json['latencyMs'];
    return Device(
      ip: (json['ip'] as String?) ?? '0.0.0.0',
      mac: json['mac'] as String?,
      hostname: json['hostname'] as String?,
      vendor: json['vendor'] as String?,
      isGateway: (json['isGateway'] as bool?) ?? false,
      isSelf: (json['isSelf'] as bool?) ?? false,
      isNew: (json['isNew'] as bool?) ?? false,
      isRandomizedMac: (json['isRandomizedMac'] as bool?) ?? false,
      label: json['label'] as String?,
      trusted: (json['trusted'] as bool?) ?? false,
      netbiosName: json['netbiosName'] as String?,
      mdnsName: json['mdnsName'] as String?,
      model: json['model'] as String?,
      upnpName: json['upnpName'] as String?,
      services: rawServices is List ? rawServices.map((e) => '$e').toList() : const <String>[],
      latencyMs: rawLatency is num ? rawLatency.toDouble() : null,
      lastSeen: DateTime.tryParse((json['lastSeen'] as String?) ?? '') ?? DateTime.now(),
    );
  }

  @override
  bool operator ==(Object other) =>
      other is Device &&
      other.ip == ip &&
      other.mac == mac &&
      other.isNew == isNew &&
      other.label == label &&
      other.trusted == trusted;

  @override
  int get hashCode => Object.hash(ip, mac, isNew, label, trusted);
}

/// Résultat complet d'un scan (persisté pour l'export JSON et le dashboard).
@immutable
class ScanReport {
  const ScanReport({
    required this.startedAt,
    required this.finishedAt,
    required this.subnet,
    required this.network,
    required this.devices,
    this.cancelled = false,
  });

  final DateTime startedAt;
  final DateTime finishedAt;
  final String subnet;
  final Map<String, dynamic> network;
  final List<Device> devices;
  final bool cancelled;

  Duration get duration => finishedAt.difference(startedAt);

  Map<String, dynamic> toJson() => {
        'app': 'A.SNet',
        'schema': 2,
        'startedAt': startedAt.toIso8601String(),
        'finishedAt': finishedAt.toIso8601String(),
        'durationMs': duration.inMilliseconds,
        'subnet': subnet,
        'cancelled': cancelled,
        'network': network,
        'deviceCount': devices.length,
        'devices': devices.map((d) => d.toJson()).toList(),
      };

  factory ScanReport.fromJson(Map<String, dynamic> json) {
    final rawDevices = json['devices'];
    final rawNetwork = json['network'];
    return ScanReport(
      startedAt: DateTime.tryParse((json['startedAt'] as String?) ?? '') ?? DateTime.now(),
      finishedAt: DateTime.tryParse((json['finishedAt'] as String?) ?? '') ?? DateTime.now(),
      subnet: (json['subnet'] as String?) ?? '',
      cancelled: (json['cancelled'] as bool?) ?? false,
      network: rawNetwork is Map ? Map<String, dynamic>.from(rawNetwork) : <String, dynamic>{},
      devices: rawDevices is List
          ? rawDevices
              .whereType<Map<dynamic, dynamic>>()
              .map((m) => Device.fromJson(Map<String, dynamic>.from(m)))
              .toList()
          : const <Device>[],
    );
  }
}
