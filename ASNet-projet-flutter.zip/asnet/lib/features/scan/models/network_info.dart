// Décision : score de sécurité volontairement simple, basé uniquement sur le protocole Wi-Fi
// (WPA3 > WPA2 > WPA > WEP > ouvert), lu nativement via le canal "com.asnet.app/wifi".
import 'package:flutter/foundation.dart';

enum ConnectionKind { wifi, ethernet, mobile, vpn, other, none }

enum WifiSecurity { wpa3Enterprise, wpa3, wpa2Enterprise, wpa2, owe, wpa, wapi, wep, open, unknown }

enum NetworkHealth { excellent, good, fair, poor, offline }

@immutable
class NetworkDetails {
  const NetworkDetails({
    required this.kind,
    required this.fetchedAt,
    this.ssid,
    this.bssid,
    this.ip,
    this.gateway,
    this.subnetMask,
    this.security = WifiSecurity.unknown,
    this.locationGranted = false,
    this.locationServiceEnabled = true,
    this.deviceModel,
    this.deviceManufacturer,
    this.androidVersion,
  });

  factory NetworkDetails.offline() =>
      NetworkDetails(kind: ConnectionKind.none, fetchedAt: DateTime.now());

  final ConnectionKind kind;
  final String? ssid;
  final String? bssid;
  final String? ip;
  final String? gateway;
  final String? subnetMask;
  final WifiSecurity security;
  final bool locationGranted;
  final bool locationServiceEnabled;
  final String? deviceModel;
  final String? deviceManufacturer;
  final String? androidVersion;
  final DateTime fetchedAt;

  bool get isOnline => kind != ConnectionKind.none;
  bool get isWifi => kind == ConnectionKind.wifi;

  /// Le scan LAN n'a de sens que sur un réseau local (Wi-Fi ou Ethernet) avec une IPv4.
  bool get canScan => (kind == ConnectionKind.wifi || kind == ConnectionKind.ethernet) && ip != null;

  /// SSID masqué par Android tant que la localisation n'est pas accordée/activée.
  bool get ssidHidden => isWifi && ssid == null;

  int? get securityScore {
    switch (security) {
      case WifiSecurity.wpa3Enterprise:
        return 98;
      case WifiSecurity.wpa3:
        return 95;
      case WifiSecurity.wpa2Enterprise:
        return 90;
      case WifiSecurity.wpa2:
        return 75;
      case WifiSecurity.owe:
        return 60;
      case WifiSecurity.wapi:
        return 55;
      case WifiSecurity.wpa:
        return 40;
      case WifiSecurity.wep:
        return 15;
      case WifiSecurity.open:
        return 5;
      case WifiSecurity.unknown:
        return null;
    }
  }

  String get securityLabel {
    switch (security) {
      case WifiSecurity.wpa3Enterprise:
        return 'WPA3-Enterprise';
      case WifiSecurity.wpa3:
        return 'WPA3';
      case WifiSecurity.wpa2Enterprise:
        return 'WPA2-Enterprise';
      case WifiSecurity.wpa2:
        return 'WPA2';
      case WifiSecurity.owe:
        return 'OWE';
      case WifiSecurity.wapi:
        return 'WAPI';
      case WifiSecurity.wpa:
        return 'WPA';
      case WifiSecurity.wep:
        return 'WEP';
      case WifiSecurity.open:
        return 'Open';
      case WifiSecurity.unknown:
        return '—';
    }
  }

  NetworkHealth get health {
    if (!isOnline) return NetworkHealth.offline;
    if (!isWifi) return NetworkHealth.good;
    final score = securityScore;
    if (score == null) return NetworkHealth.good;
    if (score >= 90) return NetworkHealth.excellent;
    if (score >= 70) return NetworkHealth.good;
    if (score >= 40) return NetworkHealth.fair;
    return NetworkHealth.poor;
  }

  static WifiSecurity parseSecurity(String? raw) {
    switch (raw) {
      case 'WPA3_ENTERPRISE':
        return WifiSecurity.wpa3Enterprise;
      case 'WPA3':
        return WifiSecurity.wpa3;
      case 'WPA2_ENTERPRISE':
        return WifiSecurity.wpa2Enterprise;
      case 'WPA2':
        return WifiSecurity.wpa2;
      case 'OWE':
        return WifiSecurity.owe;
      case 'WAPI':
        return WifiSecurity.wapi;
      case 'WPA':
        return WifiSecurity.wpa;
      case 'WEP':
        return WifiSecurity.wep;
      case 'OPEN':
        return WifiSecurity.open;
      default:
        return WifiSecurity.unknown;
    }
  }

  Map<String, dynamic> toJson() => {
        'connection': kind.name,
        'ssid': ssid,
        'bssid': bssid,
        'ip': ip,
        'gateway': gateway,
        'subnetMask': subnetMask,
        'security': securityLabel,
        'securityScore': securityScore,
        'device': deviceModel,
        'manufacturer': deviceManufacturer,
        'android': androidVersion,
        'fetchedAt': fetchedAt.toIso8601String(),
      };
}
