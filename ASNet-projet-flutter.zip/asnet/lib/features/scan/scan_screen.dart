// Décision : pull-to-refresh relance le scan sans bloquer l'indicateur (la progression est sur le radar).
// Décision : lignes d'appareils sans blur (performances), détails dans une bottom sheet.
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_motion.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../shared/utils/feedback.dart';
import '../../shared/utils/time_format.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/scan_radar.dart';
import '../../shared/widgets/ui_parts.dart';
import 'device_detail_screen.dart';
import 'models/device.dart';
import 'scan_controller.dart';

IconData deviceIcon(DeviceKind kind) {
  switch (kind) {
    case DeviceKind.router:
      return Icons.router_rounded;
    case DeviceKind.phone:
      return Icons.smartphone_rounded;
    case DeviceKind.computer:
      return Icons.laptop_mac_rounded;
    case DeviceKind.tv:
      return Icons.tv_rounded;
    case DeviceKind.speaker:
      return Icons.speaker_rounded;
    case DeviceKind.console:
      return Icons.sports_esports_rounded;
    case DeviceKind.printer:
      return Icons.print_rounded;
    case DeviceKind.camera:
      return Icons.videocam_rounded;
    case DeviceKind.nas:
      return Icons.storage_rounded;
    case DeviceKind.iot:
      return Icons.memory_rounded;
    case DeviceKind.unknown:
      return Icons.devices_other_rounded;
  }
}

String deviceKindKey(DeviceKind kind) => 'kind_${kind.name}';

class ScanScreen extends ConsumerStatefulWidget {
  const ScanScreen({super.key});

  @override
  ConsumerState<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends ConsumerState<ScanScreen> {
  bool _onlyNew = false;

  void _start() {
    ref.read(scanControllerProvider.notifier).start();
  }

  void _showDetails(Device device) {
    AppMotion.tap();
    openDeviceDetail(context, device);
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final scan = ref.watch(scanControllerProvider);
    final topInset = MediaQuery.paddingOf(context).top;

    ref.listen<ScanState>(scanControllerProvider, (previous, next) {
      final wasScanning = previous?.status == ScanStatus.scanning;
      if (wasScanning && next.status == ScanStatus.done) {
        AppMotion.confirm();
        showAppSnack(
          context,
          next.cancelled
              ? l.t('scan_cancelled', {'count': next.devices.length})
              : l.t('scan_done', {'count': next.devices.length}),
          kind: FeedbackKind.success,
        );
      } else if (wasScanning && next.status == ScanStatus.error) {
        showAppSnack(context, l.t(next.errorKey ?? 'error_scan_failed'), kind: FeedbackKind.error);
      }
    });

    final devices = _onlyNew ? scan.devices.where((d) => d.isNew).toList() : scan.devices;
    final percent = (scan.progress * 100).round();

    return RefreshIndicator(
      color: p.network,
      edgeOffset: topInset,
      onRefresh: () async => _start(),
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverPadding(
            padding: EdgeInsets.fromLTRB(16, topInset + AppSpacing.lg, 16, 0),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Semantics(header: true, child: Text(l.t('scan_title'), style: text.headlineMedium)),
                  const SizedBox(height: AppSpacing.xs),
                  Text(
                    scan.subnetLabel == null
                        ? l.t('scan_subtitle')
                        : l.t('scan_subnet', {'subnet': scan.subnetLabel}),
                    style: text.bodyMedium?.copyWith(color: p.muted),
                  ),
                  const SizedBox(height: AppSpacing.lg),
                  GlassCard(
                    accent: p.network,
                    child: Column(
                      children: [
                        ScanRadar(
                          active: scan.isScanning,
                          color: p.network,
                          size: 230,
                          blips: [for (final d in scan.devices) d.ip],
                          semanticLabel: scan.isScanning
                              ? l.t('scan_progress_semantic', {'percent': percent, 'count': scan.devices.length})
                              : l.t('radar_idle_semantic'),
                          child: _RadarCenter(scan: scan, percent: percent),
                        ),
                        const SizedBox(height: AppSpacing.lg),
                        if (scan.isScanning) ...[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: LinearProgressIndicator(
                              value: scan.identifying ? null : scan.progress,
                              minHeight: 6,
                            ),
                          ),
                          const SizedBox(height: AppSpacing.sm),
                          Text(
                            scan.identifying
                                ? l.t('scan_identifying')
                                : l.t('hosts_checked', {'done': scan.scanned, 'total': scan.total}),
                            style: AppTypography.mono(size: 12, color: p.muted),
                          ),
                          const SizedBox(height: AppSpacing.md),
                          OutlinedButton.icon(
                            onPressed: () {
                              AppMotion.tap();
                              ref.read(scanControllerProvider.notifier).cancel();
                            },
                            icon: const Icon(Icons.stop_rounded),
                            label: Text(l.t('cancel')),
                          ),
                        ] else
                          GradientButton(
                            label: scan.status == ScanStatus.idle ? l.t('scan_start') : l.t('scan_again'),
                            icon: Icons.track_changes_rounded,
                            onPressed: _start,
                          ),
                        if (!scan.isScanning && scan.finishedAt != null) ...[
                          const SizedBox(height: AppSpacing.sm),
                          Text(
                            '${l.t('last_scan')} : ${relativeTime(l, scan.finishedAt)}'
                            '${scan.startedAt != null ? ' · ${shortDuration(scan.finishedAt!.difference(scan.startedAt!))}' : ''}',
                            style: text.bodySmall,
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (scan.status == ScanStatus.error) ...[
                    const SizedBox(height: AppSpacing.md),
                    GlassCard(
                      accent: p.danger,
                      blur: false,
                      child: Row(
                        children: [
                          Icon(Icons.error_outline_rounded, color: p.danger),
                          const SizedBox(width: AppSpacing.md),
                          Expanded(child: Text(l.t(scan.errorKey ?? 'error_scan_failed'))),
                        ],
                      ),
                    ),
                  ],
                  if (scan.baseline && scan.status == ScanStatus.done) ...[
                    const SizedBox(height: AppSpacing.md),
                    GlassCard(
                      accent: p.share,
                      blur: false,
                      child: Row(
                        children: [
                          Icon(Icons.bookmark_rounded, color: p.share),
                          const SizedBox(width: AppSpacing.md),
                          Expanded(child: Text(l.t('baseline_info'), style: text.bodyMedium)),
                        ],
                      ),
                    ),
                  ],
                  SectionTitle(
                    l.t('devices_section', {'count': scan.devices.length}),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ChoiceChip(
                          label: Text(l.t('filter_all')),
                          selected: !_onlyNew,
                          onSelected: (_) => setState(() => _onlyNew = false),
                        ),
                        const SizedBox(width: AppSpacing.xs),
                        ChoiceChip(
                          label: Text(l.t('filter_new', {'count': scan.newCount})),
                          selected: _onlyNew,
                          onSelected: (_) => setState(() => _onlyNew = true),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (devices.isEmpty && !scan.isScanning)
            SliverToBoxAdapter(
              child: EmptyState(
                icon: _onlyNew ? Icons.verified_rounded : Icons.search_rounded,
                title: l.t(_onlyNew ? 'no_new_title' : 'no_devices_title'),
                message: l.t(_onlyNew ? 'no_new_body' : 'no_devices_body'),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final device = devices[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
                      child: _DeviceTile(device: device, onTap: () => _showDetails(device))
                          .animate()
                          .fadeIn(duration: AppMotion.fast, curve: AppMotion.ease),
                    );
                  },
                  childCount: devices.length,
                ),
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }
}

class _RadarCenter extends StatelessWidget {
  const _RadarCenter({required this.scan, required this.percent});

  final ScanState scan;
  final int percent;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final l = context.l10n;
    if (!scan.isScanning) {
      return Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            scan.status == ScanStatus.idle ? '—' : '${scan.devices.length}',
            style: AppTypography.mono(size: 34, weight: FontWeight.w800, color: p.text),
          ),
          Text(l.t('devices_short'), style: Theme.of(context).textTheme.labelSmall?.copyWith(color: p.muted)),
        ],
      );
    }
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('$percent%', style: AppTypography.mono(size: 30, weight: FontWeight.w800, color: p.text)),
        Text(
          l.t('found_count', {'count': scan.devices.length}),
          style: Theme.of(context).textTheme.labelSmall?.copyWith(color: p.muted),
        ),
      ],
    );
  }
}

class _DeviceTile extends StatelessWidget {
  const _DeviceTile({required this.device, required this.onTap});

  final Device device;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final accent = device.isGateway ? p.network : (device.isNew ? p.share : p.muted);
    final secondary = <String>[
      if (device.vendor != null) device.vendor!,
      if (device.mac != null) device.mac!,
      if (device.latencyMs != null) '${device.latencyMs!.toStringAsFixed(0)} ms',
    ].join(' · ');

    return GlassCard(
      blur: false,
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md, vertical: AppSpacing.md),
      onTap: onTap,
      semanticLabel: l.t('device_semantic', {
        'name': device.displayName,
        'ip': device.ip,
        'kind': l.t(deviceKindKey(device.kind)),
      }),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: accent.faded(0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(deviceIcon(device.kind), color: device.isGateway || device.isNew ? accent : p.text),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  device.displayName,
                  style: text.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(device.ip, style: AppTypography.mono(size: 13, color: p.network)),
                if (secondary.isNotEmpty)
                  Text(
                    secondary,
                    style: AppTypography.mono(size: 11, color: p.muted),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (device.isNew) StatusPill(label: l.t('badge_new'), color: p.share),
              if (device.isGateway) StatusPill(label: l.t('badge_router'), color: p.network),
              if (device.isSelf) StatusPill(label: l.t('badge_you'), color: p.success),
            ],
          ),
          Icon(Icons.chevron_right_rounded, color: p.muted),
        ],
      ),
    );
  }
}
