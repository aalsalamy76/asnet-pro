// Décision : un Notifier global (non autoDispose) -> le scan continue si l'on change d'onglet,
// et le dashboard affiche le nombre d'appareils en direct.
// Décision : le tout premier scan sert de référence : aucun appareil n'y est marqué "nouveau".
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers/app_providers.dart';
import 'models/device.dart';
import 'services/device_labels_repository.dart';
import 'services/network_scanner.dart';

enum ScanStatus { idle, scanning, done, error }

@immutable
class ScanState {
  const ScanState({
    this.status = ScanStatus.idle,
    this.devices = const [],
    this.scanned = 0,
    this.total = 0,
    this.subnetLabel,
    this.startedAt,
    this.finishedAt,
    this.errorKey,
    this.baseline = false,
    this.cancelled = false,
    this.identifying = false,
  });

  final ScanStatus status;
  final List<Device> devices;
  final int scanned;
  final int total;
  final String? subnetLabel;
  final DateTime? startedAt;
  final DateTime? finishedAt;

  /// Clé de traduction de l'erreur (ex. 'error_not_wifi').
  final String? errorKey;

  /// Vrai quand ce scan a servi de référence (premier scan).
  final bool baseline;
  final bool cancelled;

  /// Phase 2 du scan : identification (mDNS, UPnP, NetBIOS, DNS inverse).
  final bool identifying;

  bool get isScanning => status == ScanStatus.scanning;
  double get progress {
    if (total <= 0) return 0;
    final value = scanned / total;
    return value < 0 ? 0 : (value > 1 ? 1 : value);
  }
  int get newCount => devices.where((d) => d.isNew).length;

  ScanState copyWith({
    ScanStatus? status,
    List<Device>? devices,
    int? scanned,
    int? total,
    String? subnetLabel,
    DateTime? startedAt,
    DateTime? finishedAt,
    String? errorKey,
    bool? baseline,
    bool? cancelled,
    bool? identifying,
  }) {
    return ScanState(
      status: status ?? this.status,
      devices: devices ?? this.devices,
      scanned: scanned ?? this.scanned,
      total: total ?? this.total,
      subnetLabel: subnetLabel ?? this.subnetLabel,
      startedAt: startedAt ?? this.startedAt,
      finishedAt: finishedAt ?? this.finishedAt,
      errorKey: errorKey ?? this.errorKey,
      baseline: baseline ?? this.baseline,
      cancelled: cancelled ?? this.cancelled,
      identifying: identifying ?? this.identifying,
    );
  }
}

final scanControllerProvider = NotifierProvider<ScanController, ScanState>(ScanController.new);

class ScanController extends Notifier<ScanState> {
  bool _cancelRequested = false;

  @override
  ScanState build() {
    final report = ref.read(scanHistoryRepositoryProvider).loadReport();
    if (report == null) return const ScanState();
    return ScanState(
      status: ScanStatus.done,
      devices: ref.read(deviceLabelsRepositoryProvider).apply(report.devices),
      scanned: report.devices.length,
      total: report.devices.length,
      subnetLabel: report.subnet,
      startedAt: report.startedAt,
      finishedAt: report.finishedAt,
      cancelled: report.cancelled,
    );
  }

  void cancel() {
    if (state.isScanning) _cancelRequested = true;
  }

  /// Lance un scan réel du sous-réseau courant. Ne lève jamais d'exception.
  Future<void> start() async {
    if (state.isScanning) return;
    _cancelRequested = false;
    final startedAt = DateTime.now();
    // On garde le résultat précédent tant que le nouveau balayage n'a pas réellement commencé.
    final previous = state;
    ScanState failed(String key) => ScanState(
          status: ScanStatus.error,
          errorKey: key,
          devices: previous.devices,
          subnetLabel: previous.subnetLabel,
          startedAt: previous.startedAt,
          finishedAt: previous.finishedAt,
        );
    state = ScanState(
      status: ScanStatus.scanning,
      startedAt: startedAt,
      devices: previous.devices,
      subnetLabel: previous.subnetLabel,
      finishedAt: previous.finishedAt,
    );

    try {
      final details = await ref.read(networkInfoServiceProvider).load();
      final selfIp = details.ip;
      if (!details.canScan || selfIp == null) {
        state = failed(details.isOnline ? 'error_not_wifi' : 'error_offline');
        return;
      }

      final range = NetworkScanner.computeRange(selfIp, details.subnetMask);
      state = ScanState(
        status: ScanStatus.scanning,
        startedAt: startedAt,
        subnetLabel: range.cidr,
        total: range.hosts.length,
      );

      final history = ref.read(scanHistoryRepositoryProvider);
      final known = history.snapshot();
      final baseline = known.isEmpty;
      final live = <Device>[];
      var lastEmit = DateTime.fromMillisecondsSinceEpoch(0);

      final devices = await ref.read(networkScannerProvider).scan(
            selfIp: selfIp,
            gatewayIp: details.gateway,
            subnetMask: details.subnetMask,
            selfName: details.deviceModel,
            selfVendor: details.deviceManufacturer,
            isCancelled: () => _cancelRequested,
            onIdentifying: () => state = state.copyWith(identifying: true, scanned: state.total),
            onFound: (device) {
              live
                ..add(device)
                ..sort((a, b) => a.ipValue.compareTo(b.ipValue));
              state = state.copyWith(devices: List<Device>.unmodifiable(live));
            },
            onProgress: (done, total) {
              // Limite les reconstructions à ~20 par seconde.
              final now = DateTime.now();
              if (done == total || now.difference(lastEmit).inMilliseconds > 50) {
                lastEmit = now;
                state = state.copyWith(scanned: done, total: total);
              }
            },
          );

      final labelled = ref.read(deviceLabelsRepositoryProvider).apply(devices);
      final marked = [
        for (final d in labelled) d.copyWith(isNew: !baseline && !d.trusted && !known.contains(d)),
      ];
      final finishedAt = DateTime.now();

      try {
        await history.remember(marked);
        await history.saveReport(ScanReport(
          startedAt: startedAt,
          finishedAt: finishedAt,
          subnet: range.cidr,
          network: details.toJson(),
          devices: marked,
          cancelled: _cancelRequested,
        ));
      } catch (_) {
        // Échec de persistance : le résultat reste affiché.
      }

      state = state.copyWith(
        status: ScanStatus.done,
        devices: List<Device>.unmodifiable(marked),
        scanned: state.total,
        finishedAt: finishedAt,
        baseline: baseline,
        cancelled: _cancelRequested,
        identifying: false,
      );
    } catch (_) {
      state = failed('error_scan_failed');
    } finally {
      _cancelRequested = false;
    }
  }

  /// Renomme / annote / approuve un appareil et met à jour la liste affichée.
  Future<void> updateLabel(Device device, DeviceLabel label) async {
    try {
      await ref.read(deviceLabelsRepositoryProvider).save(device, label);
    } catch (_) {}
    state = state.copyWith(
      devices: List<Device>.unmodifiable([
        for (final d in state.devices)
          if (d.ip == device.ip)
            d.withLabel(label.name, trusted: label.trusted).copyWith(isNew: label.trusted ? false : d.isNew)
          else
            d,
      ]),
    );
  }

  Device? byIp(String ip) {
    for (final d in state.devices) {
      if (d.ip == ip) return d;
    }
    return null;
  }

  /// Après effacement de l'historique.
  void reset() {
    _cancelRequested = false;
    state = const ScanState();
  }
}
