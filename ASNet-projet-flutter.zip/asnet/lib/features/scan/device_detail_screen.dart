// Décision : fiche appareil plein écran ; scan rapide des ports courants lancé à l'ouverture,
// raccourcis vers les outils (ping, ports, traceroute, Wake-on-LAN, interface web).
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/network/ports_catalog.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../shared/utils/feedback.dart';
import '../../shared/utils/time_format.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/ui_parts.dart';
import '../tools/services/port_scanner.dart';
import '../tools/tools_screen.dart';
import '../tools/widgets/tool_widgets.dart';
import 'models/device.dart';
import 'scan_controller.dart';
import 'scan_screen.dart';
import 'services/device_labels_repository.dart';
import 'services/discovery_services.dart';

Future<void> openDeviceDetail(BuildContext context, Device device) {
  return Navigator.of(context, rootNavigator: true).push<void>(
    MaterialPageRoute<void>(builder: (_) => DeviceDetailScreen(ip: device.ip)),
  );
}

class DeviceDetailScreen extends ConsumerStatefulWidget {
  const DeviceDetailScreen({super.key, required this.ip});

  final String ip;

  @override
  ConsumerState<DeviceDetailScreen> createState() => _DeviceDetailScreenState();
}

class _DeviceDetailScreenState extends ConsumerState<DeviceDetailScreen> {
  List<int>? _ports;
  bool _scanningPorts = false;

  @override
  void initState() {
    super.initState();
    _scanPorts();
  }

  Future<void> _scanPorts() async {
    setState(() => _scanningPorts = true);
    try {
      final open = await const PortScanner().quickOpenPorts(widget.ip, PortsCatalog.quick);
      if (mounted) setState(() => _ports = open);
    } catch (_) {
      if (mounted) setState(() => _ports = const []);
    } finally {
      if (mounted) setState(() => _scanningPorts = false);
    }
  }

  Future<void> _edit(Device device) async {
    final l = context.l10n;
    final existing = ref.read(deviceLabelsRepositoryProvider).labelFor(device);
    final name = TextEditingController(text: device.label ?? '');
    final notes = TextEditingController(text: existing?.notes ?? '');
    var trusted = device.trusted;
    final result = await showDialog<DeviceLabel>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: Text(l.t('edit_device')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: InputDecoration(labelText: l.t('custom_name'), hintText: device.displayName),
                ),
                const SizedBox(height: AppSpacing.md),
                TextField(
                  controller: notes,
                  maxLines: 3,
                  decoration: InputDecoration(labelText: l.t('notes')),
                ),
                const SizedBox(height: AppSpacing.sm),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(l.t('trusted_device')),
                  value: trusted,
                  onChanged: (v) => setLocal(() => trusted = v),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(ctx).pop(), child: Text(l.t('cancel'))),
            FilledButton(
              onPressed: () => Navigator.of(ctx).pop(
                DeviceLabel(name: name.text.trim(), notes: notes.text.trim(), trusted: trusted),
              ),
              child: Text(l.t('save')),
            ),
          ],
        ),
      ),
    );
    // Les contrôleurs ne sont pas libérés ici : le dialogue peut encore s'animer en fermeture.
    if (result == null || !mounted) return;
    await ref.read(scanControllerProvider.notifier).updateLabel(device, result);
    if (mounted) showAppSnack(context, l.t('saved'), kind: FeedbackKind.success);
  }

  Future<void> _openWeb(int port) async {
    final scheme = PortsCatalog.isHttps(port) ? 'https' : 'http';
    final suffix = (port == 80 || port == 443) ? '' : ':$port';
    try {
      await launchUrl(Uri.parse('$scheme://${widget.ip}$suffix'), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) showAppSnack(context, context.l10n.t('open_failed'), kind: FeedbackKind.error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final device = ref.watch(scanControllerProvider.select((s) => s.devices.where((d) => d.ip == widget.ip).firstOrNull));
    if (device == null) {
      return Scaffold(
        appBar: AppBar(),
        body: Center(child: Text(l.t('device_gone'))),
      );
    }
    final label = ref.watch(deviceLabelsRepositoryProvider).labelFor(device);
    final webPorts = (_ports ?? const <int>[]).where((port) => PortsCatalog.isHttp(port) || PortsCatalog.isHttps(port)).toList();
    final mac = device.mac;

    return Scaffold(
      backgroundColor: p.background,
      appBar: AppBar(
        backgroundColor: p.background,
        title: Text(l.t('device_details')),
        actions: [
          IconButton(
            tooltip: l.t('edit_device'),
            icon: const Icon(Icons.edit_rounded),
            onPressed: () => _edit(device),
          ),
        ],
      ),
      body: LiquidBackground(
        child: SafeArea(
          top: false,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            children: [
              GlassCard(
                accent: device.isGateway ? p.network : (device.isNew ? p.share : null),
                child: Column(
                  children: [
                    Container(
                      width: 72,
                      height: 72,
                      decoration: BoxDecoration(color: p.network.faded(0.14), borderRadius: BorderRadius.circular(22)),
                      child: Icon(deviceIcon(device.kind), size: 38, color: p.network),
                    ),
                    const SizedBox(height: AppSpacing.md),
                    Text(device.displayName, style: text.headlineSmall, textAlign: TextAlign.center),
                    const SizedBox(height: AppSpacing.xs),
                    Text(device.ip, style: AppTypography.mono(size: 16, color: p.network)),
                    const SizedBox(height: AppSpacing.sm),
                    Wrap(
                      spacing: AppSpacing.xs,
                      runSpacing: AppSpacing.xs,
                      alignment: WrapAlignment.center,
                      children: [
                        StatusPill(label: l.t(deviceKindKey(device.kind)), color: p.muted),
                        if (device.isGateway) StatusPill(label: l.t('badge_router'), color: p.network),
                        if (device.isSelf) StatusPill(label: l.t('badge_you'), color: p.success),
                        if (device.isNew) StatusPill(label: l.t('badge_new'), color: p.share),
                        if (device.trusted) StatusPill(label: l.t('badge_trusted'), color: p.success, icon: Icons.verified_rounded),
                        if (device.latencyMs != null) StatusPill(label: '${fmtNum(device.latencyMs)} ms', color: p.network),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.md),
              Wrap(
                spacing: AppSpacing.sm,
                runSpacing: AppSpacing.sm,
                children: [
                  _ActionChip(icon: Icons.wifi_tethering_rounded, label: l.t('tool_ping'), onTap: () => openTool(context, ToolId.ping, host: device.ip)),
                  _ActionChip(icon: Icons.settings_input_component_rounded, label: l.t('tool_ports'), onTap: () => openTool(context, ToolId.ports, host: device.ip)),
                  _ActionChip(icon: Icons.timeline_rounded, label: l.t('tool_traceroute'), onTap: () => openTool(context, ToolId.traceroute, host: device.ip)),
                  if (mac != null && !device.isSelf)
                    _ActionChip(icon: Icons.power_settings_new_rounded, label: l.t('tool_wol'), onTap: () => openTool(context, ToolId.wol, host: mac)),
                  for (final port in webPorts)
                    _ActionChip(icon: Icons.open_in_browser_rounded, label: '${l.t('open_web')} :$port', onTap: () => _openWeb(port)),
                  _ActionChip(
                    icon: Icons.content_copy_rounded,
                    label: l.t('copy_ip'),
                    onTap: () async {
                      await Clipboard.setData(ClipboardData(text: device.ip));
                      if (context.mounted) showAppSnack(context, l.t('copied'), kind: FeedbackKind.success);
                    },
                  ),
                ],
              ),
              ResultCard(
                title: l.t('identity'),
                child: Column(
                  children: [
                    KeyValueRow(l.t('ip_address'), device.ip),
                    KeyValueRow(
                      l.t('mac_address'),
                      mac ?? (device.isSelf ? l.t('mac_hidden_self') : l.t('mac_unavailable')),
                    ),
                    KeyValueRow(
                      l.t('vendor'),
                      device.vendor ?? (device.isRandomizedMac ? l.t('mac_private') : l.t('unknown')),
                      mono: false,
                    ),
                    if (device.model != null) KeyValueRow(l.t('model'), device.model!, mono: false),
                    KeyValueRow(l.t('hostname'), device.hostname ?? '—'),
                    if (device.netbiosName != null) KeyValueRow('NetBIOS', device.netbiosName!),
                    if (device.mdnsName != null) KeyValueRow('Bonjour', device.mdnsName!),
                    if (device.upnpName != null) KeyValueRow('UPnP', device.upnpName!, mono: false),
                    KeyValueRow(l.t('last_seen'), relativeTime(l, device.lastSeen), mono: false),
                    if (label?.notes != null && label!.notes!.isNotEmpty) KeyValueRow(l.t('notes'), label.notes!, mono: false),
                  ],
                ),
              ),
              if (device.services.isNotEmpty)
                ResultCard(
                  title: l.t('services_announced', {'count': device.services.length}),
                  child: Wrap(
                    spacing: AppSpacing.xs,
                    runSpacing: AppSpacing.xs,
                    children: [
                      for (final s in device.services)
                        Chip(
                          label: Text(s.startsWith('_') ? MdnsDiscovery.friendly(s) : s),
                          visualDensity: VisualDensity.compact,
                        ),
                    ],
                  ),
                ),
              ResultCard(
                title: l.t('open_ports', {'count': _ports?.length ?? 0}),
                trailing: _scanningPorts
                    ? const SizedBox.square(dimension: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : IconButton(
                        tooltip: l.t('refresh'),
                        icon: const Icon(Icons.refresh_rounded),
                        onPressed: _scanPorts,
                      ),
                child: _ports == null
                    ? Text(l.t('scanning_ports'), style: text.bodyMedium?.copyWith(color: p.muted))
                    : _ports!.isEmpty
                        ? Text(l.t('no_open_ports_quick'), style: text.bodyMedium?.copyWith(color: p.muted))
                        : Wrap(
                            spacing: AppSpacing.xs,
                            runSpacing: AppSpacing.xs,
                            children: [
                              for (final port in _ports!)
                                StatusPill(
                                  label: '$port · ${PortsCatalog.nameOf(port)}',
                                  color: PortsCatalog.riskyDevice.contains(port) ? p.warning : p.success,
                                ),
                            ],
                          ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.md),
                child: Text(l.t('quick_ports_note'), style: text.bodySmall),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionChip extends StatelessWidget {
  const _ActionChip({required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return ActionChip(
      avatar: Icon(icon, size: 18, color: p.network),
      label: Text(label),
      onPressed: onTap,
    );
  }
}
