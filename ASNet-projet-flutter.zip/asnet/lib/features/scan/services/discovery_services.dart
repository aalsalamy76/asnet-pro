// Décision : trois protocoles de découverte "passifs" lancés en parallèle après le balayage :
// mDNS/Bonjour (noms + services Apple/Google/imprimantes), SSDP/UPnP (box, TV, NAS) et NetBIOS
// (noms Windows + MAC, utile car Android 10+ masque la table ARP). Aucun ne nécessite root.
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import '../../../core/network/dns_codec.dart';

// ───────────────────────────── mDNS / Bonjour ─────────────────────────────

class MdnsHostInfo {
  String? name;
  String? model;
  final Set<String> services = <String>{};
  final Set<String> instances = <String>{};

  bool get isEmpty => name == null && services.isEmpty && instances.isEmpty;
}

class MdnsDiscovery {
  const MdnsDiscovery();

  static const String _metaQuery = '_services._dns-sd._udp.local';

  static const List<String> commonTypes = [
    '_http._tcp.local', '_ipp._tcp.local', '_printer._tcp.local', '_pdl-datastream._tcp.local',
    '_googlecast._tcp.local', '_airplay._tcp.local', '_raop._tcp.local', '_spotify-connect._tcp.local',
    '_smb._tcp.local', '_afpovertcp._tcp.local', '_ssh._tcp.local', '_hap._tcp.local',
    '_companion-link._tcp.local', '_sonos._tcp.local', '_workstation._tcp.local',
    '_device-info._tcp.local', '_amzn-wplay._tcp.local', '_androidtvremote2._tcp.local',
    '_matter._tcp.local', '_esphomelib._tcp.local', '_rtsp._tcp.local',
  ];

  /// IP -> infos annoncées. Ne lève jamais d'exception.
  Future<Map<String, MdnsHostInfo>> discover({Duration timeout = const Duration(seconds: 3)}) async {
    final result = <String, MdnsHostInfo>{};
    RawDatagramSocket? socket;
    try {
      socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      final target = InternetAddress('224.0.0.251');
      final asked = <String>{};
      final s = socket;

      void ask(List<String> names) {
        final questions = [
          for (final n in names) DnsQuestion(n, DnsCodec.typePTR, unicastResponse: true),
        ];
        try {
          s.send(DnsCodec.buildQuery(0, questions, recursionDesired: false), target, 5353);
        } catch (_) {}
      }

      s.listen((event) {
        if (event != RawSocketEvent.read) return;
        final datagram = s.receive();
        if (datagram == null) return;
        final message = DnsCodec.parse(datagram.data);
        if (message == null || !message.isResponse) return;
        final ip = datagram.address.address;
        final info = result.putIfAbsent(ip, () => MdnsHostInfo());
        final newTypes = <String>[];
        for (final r in message.allRecords) {
          switch (r.type) {
            case DnsCodec.typePTR:
              if (r.name.toLowerCase() == _metaQuery) {
                if (asked.add(r.data.toLowerCase())) newTypes.add(r.data);
              } else if (r.name.startsWith('_')) {
                info.services.add(_serviceType(r.name));
                final instance = _firstLabel(r.data);
                if (instance.isNotEmpty) info.instances.add(instance);
              }
              break;
            case DnsCodec.typeSRV:
              final type = _serviceType(r.name.substring(r.name.indexOf('.') + 1));
              if (type.startsWith('_')) info.services.add(type);
              break;
            case DnsCodec.typeA:
              if (r.data == ip) info.name ??= _stripLocal(r.name);
              break;
            case DnsCodec.typeTXT:
              for (final t in r.texts) {
                final lower = t.toLowerCase();
                if (lower.startsWith('model=') || lower.startsWith('md=')) {
                  info.model ??= t.substring(t.indexOf('=') + 1);
                } else if (lower.startsWith('fn=')) {
                  // Chromecast : nom convivial.
                  info.instances.add(t.substring(3));
                }
              }
              break;
            default:
              break;
          }
        }
        if (newTypes.isNotEmpty) ask(newTypes);
      });

      ask([_metaQuery]);
      // Requêtes directes : certains appareils ignorent la méta-requête.
      for (var i = 0; i < commonTypes.length; i += 6) {
        ask(commonTypes.sublist(i, math.min(i + 6, commonTypes.length)));
      }
      asked.addAll(commonTypes);
      await Future<void>.delayed(timeout ~/ 2);
      ask([_metaQuery]);
      await Future<void>.delayed(timeout ~/ 2);
    } catch (_) {
      // Réseau sans multicast : on renvoie ce qu'on a.
    } finally {
      socket?.close();
    }
    result.removeWhere((ip, info) => info.isEmpty);
    return result;
  }

  static String _stripLocal(String name) {
    var n = name;
    if (n.endsWith('.')) n = n.substring(0, n.length - 1);
    if (n.toLowerCase().endsWith('.local')) n = n.substring(0, n.length - 6);
    return n;
  }

  static String _serviceType(String name) {
    final n = _stripLocal(name);
    final parts = n.split('.');
    final idx = parts.indexWhere((p) => p == '_tcp' || p == '_udp');
    if (idx > 0) return '${parts[idx - 1]}.${parts[idx]}';
    return n;
  }

  static String _firstLabel(String name) {
    final i = name.indexOf('._');
    return i > 0 ? name.substring(0, i) : '';
  }

  /// Nom lisible d'un type de service.
  static String friendly(String type) {
    const names = {
      '_googlecast._tcp': 'Chromecast',
      '_airplay._tcp': 'AirPlay',
      '_raop._tcp': 'AirPlay audio',
      '_ipp._tcp': 'Imprimante IPP',
      '_printer._tcp': 'Imprimante LPD',
      '_pdl-datastream._tcp': 'Imprimante RAW',
      '_spotify-connect._tcp': 'Spotify Connect',
      '_smb._tcp': 'Partage SMB',
      '_afpovertcp._tcp': 'Partage AFP',
      '_ssh._tcp': 'SSH',
      '_sftp-ssh._tcp': 'SFTP',
      '_hap._tcp': 'HomeKit',
      '_companion-link._tcp': 'Apple (appareil)',
      '_sonos._tcp': 'Sonos',
      '_workstation._tcp': 'Poste de travail',
      '_http._tcp': 'Interface web',
      '_amzn-wplay._tcp': 'Amazon Fire TV',
      '_androidtvremote2._tcp': 'Android TV',
      '_matter._tcp': 'Matter',
      '_esphomelib._tcp': 'ESPHome',
      '_rtsp._tcp': 'Flux vidéo RTSP',
      '_device-info._tcp': 'Infos appareil',
    };
    return names[type] ?? type;
  }
}

// ───────────────────────────── SSDP / UPnP ─────────────────────────────

class UpnpInfo {
  String? location;
  String? server;
  String? friendlyName;
  String? manufacturer;
  String? modelName;
  final Set<String> types = <String>{};

  bool get isInternetGateway =>
      types.any((t) => t.contains('InternetGatewayDevice') || t.contains('WANIPConnection') || t.contains('WANPPPConnection'));
}

class SsdpDiscovery {
  const SsdpDiscovery();

  Future<Map<String, UpnpInfo>> discover({Duration timeout = const Duration(seconds: 3)}) async {
    final result = <String, UpnpInfo>{};
    RawDatagramSocket? socket;
    try {
      socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      final s = socket;
      final target = InternetAddress('239.255.255.250');
      final request = utf8.encode(
        'M-SEARCH * HTTP/1.1\r\n'
        'HOST: 239.255.255.250:1900\r\n'
        'MAN: "ssdp:discover"\r\n'
        'MX: 2\r\n'
        'ST: ssdp:all\r\n'
        'USER-AGENT: Android UPnP/1.1 A.SNet/0.2\r\n\r\n',
      );
      s.listen((event) {
        if (event != RawSocketEvent.read) return;
        final datagram = s.receive();
        if (datagram == null) return;
        final text = utf8.decode(datagram.data, allowMalformed: true);
        final info = result.putIfAbsent(datagram.address.address, () => UpnpInfo());
        for (final line in text.split('\r\n')) {
          final sep = line.indexOf(':');
          if (sep <= 0) continue;
          final key = line.substring(0, sep).trim().toLowerCase();
          final value = line.substring(sep + 1).trim();
          if (key == 'location') info.location ??= value;
          if (key == 'server') info.server ??= value;
          if (key == 'st' || key == 'nt') info.types.add(value);
        }
      });
      s.send(request, target, 1900);
      await Future<void>.delayed(const Duration(milliseconds: 400));
      s.send(request, target, 1900);
      await Future<void>.delayed(timeout);
    } catch (_) {
      // Pas de SSDP sur ce réseau.
    } finally {
      socket?.close();
    }

    // Description XML de chaque appareil (nom, fabricant, modèle).
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 2);
    try {
      await Future.wait(result.values.where((i) => i.location != null).take(24).map((info) async {
        try {
          final uri = Uri.parse(info.location!);
          final req = await client.getUrl(uri).timeout(const Duration(seconds: 2));
          final res = await req.close().timeout(const Duration(seconds: 3));
          final body = await res
              .transform(utf8.decoder)
              .fold<String>('', (prev, chunk) => prev.length > 65536 ? prev : prev + chunk)
              .timeout(const Duration(seconds: 3));
          String? tag(String name) {
            final m = RegExp('<$name>([^<]{1,200})</$name>', caseSensitive: false).firstMatch(body);
            return m == null ? null : _unescapeXml(m.group(1)!.trim());
          }

          info.friendlyName = tag('friendlyName');
          info.manufacturer = tag('manufacturer');
          info.modelName = tag('modelName');
          final deviceType = tag('deviceType');
          if (deviceType != null) info.types.add(deviceType);
        } catch (_) {}
      }));
    } finally {
      client.close(force: true);
    }
    return result;
  }

  static String _unescapeXml(String s) => s
      .replaceAll('&amp;', '&')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .replaceAll('&quot;', '"')
      .replaceAll('&apos;', "'");

  /// Type UPnP lisible : "urn:schemas-upnp-org:device:MediaRenderer:1" -> "MediaRenderer".
  static String shortType(String type) {
    final parts = type.split(':');
    if (parts.length >= 2 && type.startsWith('urn:')) return parts[parts.length - 2];
    return type;
  }
}

// ───────────────────────────── NetBIOS ─────────────────────────────

class NetbiosInfo {
  const NetbiosInfo({required this.name, this.group, this.mac});

  final String name;
  final String? group;
  final String? mac;
}

class NetbiosResolver {
  const NetbiosResolver();

  static Uint8List _statusQuery(int id) {
    final b = <int>[(id >> 8) & 0xFF, id & 0xFF, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00];
    b.add(0x20);
    // "*" + 15 octets nuls, encodage "first-level" (RFC 1001) : "CK" + 15 x "AA".
    b.addAll('CK${'AA' * 15}'.codeUnits);
    b.add(0x00);
    b.addAll(const [0x00, 0x21, 0x00, 0x01]); // NBSTAT, IN
    return Uint8List.fromList(b);
  }

  Future<Map<String, NetbiosInfo>> query(List<String> ips, {Duration timeout = const Duration(milliseconds: 1600)}) async {
    final result = <String, NetbiosInfo>{};
    if (ips.isEmpty) return result;
    RawDatagramSocket? socket;
    try {
      socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      final s = socket;
      s.listen((event) {
        if (event != RawSocketEvent.read) return;
        final datagram = s.receive();
        if (datagram == null) return;
        final info = _parse(datagram.data);
        if (info != null) result[datagram.address.address] = info;
      });
      final packet = _statusQuery(math.Random().nextInt(0xFFFF));
      for (final ip in ips) {
        final address = InternetAddress.tryParse(ip);
        if (address == null) continue;
        try {
          s.send(packet, address, 137);
        } catch (_) {}
      }
      await Future<void>.delayed(timeout);
    } catch (_) {
    } finally {
      socket?.close();
    }
    return result;
  }

  static NetbiosInfo? _parse(Uint8List d) {
    try {
      if (d.length < 57) return null;
      var o = 12;
      if ((d[o] & 0xC0) == 0xC0) {
        o += 2;
      } else {
        while (o < d.length && d[o] != 0) {
          o += d[o] + 1;
        }
        o += 1;
      }
      o += 10; // type, classe, TTL, longueur
      if (o >= d.length) return null;
      final count = d[o];
      o += 1;
      String? name;
      String? group;
      for (var i = 0; i < count; i++) {
        if (o + 18 > d.length) break;
        final raw = String.fromCharCodes(d.sublist(o, o + 15)).trim();
        final suffix = d[o + 15];
        final flags = (d[o + 16] << 8) | d[o + 17];
        final isGroup = (flags & 0x8000) != 0;
        if (suffix == 0x00 && !isGroup) name ??= raw;
        if (suffix == 0x00 && isGroup) group ??= raw;
        o += 18;
      }
      if (name == null || name.isEmpty) return null;
      String? mac;
      if (o + 6 <= d.length) {
        final bytes = d.sublist(o, o + 6);
        if (bytes.any((b) => b != 0)) {
          mac = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join(':').toUpperCase();
        }
      }
      return NetbiosInfo(name: name, group: group, mac: mac);
    } catch (_) {
      return null;
    }
  }
}
