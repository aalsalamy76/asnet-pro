// Décision : base OUI embarquée (préfixes des fabricants les plus répandus en Europe : smartphones,
// box FAI françaises, routeurs, IoT). Aucun accès réseau. Clé = 6 premiers hexadécimaux du MAC.
class OuiLookup {
  const OuiLookup();

  /// Normalise en "AA:BB:CC:DD:EE:FF" ; null si absent/invalide/masqué par Android.
  static String? normalizeMac(String? mac) {
    if (mac == null) return null;
    final hex = mac.replaceAll(RegExp(r'[^0-9A-Fa-f]'), '').toUpperCase();
    if (hex.length != 12) return null;
    if (hex == '000000000000' || hex == '020000000000' || hex == 'FFFFFFFFFFFF') return null;
    return [for (var i = 0; i < 12; i += 2) hex.substring(i, i + 2)].join(':');
  }

  /// Bit "localement administré" -> MAC aléatoire (confidentialité Android/iOS/Windows).
  static bool isRandomized(String? mac) {
    final normalized = normalizeMac(mac);
    if (normalized == null) return false;
    final first = int.tryParse(normalized.substring(0, 2), radix: 16) ?? 0;
    return (first & 0x02) != 0;
  }

  String? vendorOf(String? mac) {
    final normalized = normalizeMac(mac);
    if (normalized == null) return null;
    final prefix = normalized.substring(0, 8).replaceAll(':', '');
    return _vendors[prefix];
  }

  int get size => _vendors.length;

  static const Map<String, String> _vendors = {
    // Apple
    '000393': 'Apple', '000A95': 'Apple', '0017F2': 'Apple', '001B63': 'Apple',
    '001EC2': 'Apple', '002312': 'Apple', '002500': 'Apple', '0026BB': 'Apple',
    '28CFE9': 'Apple', '3C0754': 'Apple', '406C8F': 'Apple', '705681': 'Apple',
    '7CC3A1': 'Apple', '8866A5': 'Apple', 'A45E60': 'Apple', 'ACBC32': 'Apple',
    'BC52B7': 'Apple', 'D023DB': 'Apple', 'F01898': 'Apple', 'F45C89': 'Apple',
    'DCA904': 'Apple', 'F099BF': 'Apple', '3C22FB': 'Apple', '784F43': 'Apple',
    'A483E7': 'Apple', '8C8590': 'Apple', '147DDA': 'Apple', '60F81D': 'Apple',
    '70DEE2': 'Apple', '88E9FE': 'Apple', '9027E4': 'Apple', 'A860B6': 'Apple',
    'B8E856': 'Apple', 'C82A14': 'Apple', 'D0817A': 'Apple', 'E0B52D': 'Apple',
    'F0B479': 'Apple', '0C4DE9': 'Apple', '109ADD': 'Apple', '186590': 'Apple',
    '1C36BB': 'Apple', '2078F2': 'Apple', '24A074': 'Apple', '286AB8': 'Apple',
    '34363B': 'Apple', '38C986': 'Apple', '403004': 'Apple', '442A60': 'Apple',
    '48437C': 'Apple', '4C57CA': 'Apple', '54AE27': 'Apple', '5855CA': 'Apple',
    '5C969D': 'Apple', '609AC1': 'Apple', '64B9E8': 'Apple', '6C4008': 'Apple',
    '70CD60': 'Apple', '7831C1': 'Apple', '7C6D62': 'Apple', '80E650': 'Apple',
    '843835': 'Apple', '8C2DAA': 'Apple', '90B21F': 'Apple', '9801A7': 'Apple',
    '9C207B': 'Apple', 'A0999B': 'Apple', 'A4D18C': 'Apple', 'A82066': 'Apple',
    'AC87A3': 'Apple', 'B065BD': 'Apple', 'B4F0AB': 'Apple', 'B8C75D': 'Apple',
    'BC9FEF': 'Apple', 'C0CECD': 'Apple', 'C42C03': 'Apple', 'C8BCC8': 'Apple',
    'CC08E0': 'Apple', 'D0A637': 'Apple', 'D4F46F': 'Apple', 'D89E3F': 'Apple',
    'DC2B2A': 'Apple', 'E0ACCB': 'Apple', 'E425E7': 'Apple', 'E4CE8F': 'Apple',
    'E8802E': 'Apple', 'EC3586': 'Apple', 'F0DBE2': 'Apple', 'F40F24': 'Apple',
    'F82793': 'Apple', 'FC253F': 'Apple',

    // Samsung
    '0000F0': 'Samsung', '0007AB': 'Samsung', '001247': 'Samsung', '001599': 'Samsung',
    '001632': 'Samsung', '001D25': 'Samsung', '002119': 'Samsung', '002637': 'Samsung',
    '08D42B': 'Samsung', '101DC0': 'Samsung', '3423BA': 'Samsung', '38AA3C': 'Samsung',
    '5001BB': 'Samsung', '5C0A5B': 'Samsung', '78BDBC': 'Samsung', '8425DB': 'Samsung',
    '8C7712': 'Samsung', '94350A': 'Samsung', 'BC20A4': 'Samsung', 'C4576E': 'Samsung',
    'CC07AB': 'Samsung', 'E8508B': 'Samsung', 'F025B7': 'Samsung', 'FCA13E': 'Samsung',

    // Xiaomi
    '009EC8': 'Xiaomi', '0C1DAF': 'Xiaomi', '14F65A': 'Xiaomi', '185936': 'Xiaomi',
    '286C07': 'Xiaomi', '3480B3': 'Xiaomi', '38A4ED': 'Xiaomi', '508F4C': 'Xiaomi',
    '584498': 'Xiaomi', '640980': 'Xiaomi', '64B473': 'Xiaomi', '68DFDD': 'Xiaomi',
    '742344': 'Xiaomi', '7802F8': 'Xiaomi', '7C1DD9': 'Xiaomi', '8CBEBE': 'Xiaomi',
    '98FAE3': 'Xiaomi', '9C99A0': 'Xiaomi', 'ACF7F3': 'Xiaomi', 'F48B32': 'Xiaomi',
    'F8A45F': 'Xiaomi', 'FC64BA': 'Xiaomi',

    // Huawei / Honor
    '00E0FC': 'Huawei', '001882': 'Huawei', '001E10': 'Huawei', '002568': 'Huawei',
    '00464B': 'Huawei', '00664B': 'Huawei', '009ACD': 'Huawei', '04C06F': 'Huawei',
    '0819A6': 'Huawei', '104780': 'Huawei', '20F3A3': 'Huawei', '283152': 'Huawei',
    '346BD3': 'Huawei', '4846FB': 'Huawei', '4C5499': 'Huawei', '548998': 'Huawei',
    '5C7D5E': 'Huawei', '70723C': 'Huawei', '80B686': 'Huawei', '8853D4': 'Huawei',
    '9C28EF': 'Huawei', 'ACE215': 'Huawei', 'BC7670': 'Huawei', 'C8D15E': 'Huawei',
    'D46E5C': 'Huawei', 'E0247F': 'Huawei', 'F4C714': 'Huawei', 'F83DFF': 'Huawei',

    // Google / Nest
    '001A11': 'Google', '3C5AB4': 'Google', '546009': 'Google', '6CADF8': 'Google',
    '94EB2C': 'Google', 'A47733': 'Google', 'D86C63': 'Google', 'F4F5D8': 'Google',
    'F4F5E8': 'Google', '48D6D5': 'Google', '20DFB9': 'Google', '1CF29A': 'Google',
    '44070B': 'Google', '30FD38': 'Google', '3C286D': 'Google', '18D6C7': 'Google',

    // Amazon (Echo, Fire TV, Kindle, Ring)
    '00FC8B': 'Amazon', '0C47C9': 'Amazon', '18742E': 'Amazon', '34D270': 'Amazon',
    '38F73D': 'Amazon', '40B4CD': 'Amazon', '44650D': 'Amazon', '50DCE7': 'Amazon',
    '6837E9': 'Amazon', '6854FD': 'Amazon', '6C5697': 'Amazon', '74C246': 'Amazon',
    '84D6D0': 'Amazon', '8871E5': 'Amazon', 'A002DC': 'Amazon', 'AC63BE': 'Amazon',
    'B47C9C': 'Amazon', 'F0272D': 'Amazon', 'F0D2F1': 'Amazon', 'FC65DE': 'Amazon',
    '747548': 'Amazon', '40A2DB': 'Amazon',

    // OnePlus / OPPO / Motorola
    '94652D': 'OnePlus', 'C0EEFB': 'OnePlus', '64A2F9': 'OnePlus',
    'A43D78': 'OPPO', '2C5BB8': 'OPPO', 'E8BBA8': 'OPPO',
    '9068C3': 'Motorola', 'E89120': 'Motorola', '5C5188': 'Motorola',

    // Sony / PlayStation, Nintendo, Microsoft / Xbox
    '00014A': 'Sony', '0013A9': 'Sony', '001A80': 'Sony', '0024BE': 'Sony',
    '3017C8': 'Sony', '544249': 'Sony', '78843C': 'Sony', 'FCF152': 'Sony',
    '00041F': 'Sony Interactive', '00D9D1': 'Sony Interactive', '280DFC': 'Sony Interactive',
    '709E29': 'Sony Interactive', 'BC60A7': 'Sony Interactive',
    '0009BF': 'Nintendo', '0017AB': 'Nintendo', '00191D': 'Nintendo', '001AE9': 'Nintendo',
    '001BEA': 'Nintendo', '001F32': 'Nintendo', '00224C': 'Nintendo', '002444': 'Nintendo',
    '182A7B': 'Nintendo', '2C10C1': 'Nintendo', '34AF2C': 'Nintendo', '40F407': 'Nintendo',
    '58BDA3': 'Nintendo', '7CBB8A': 'Nintendo', '8C56C5': 'Nintendo', '98B6E9': 'Nintendo',
    '9CE635': 'Nintendo', 'A4C0E1': 'Nintendo', 'B8AE6E': 'Nintendo', 'CCFB65': 'Nintendo',
    'D86BF7': 'Nintendo', 'E00C7F': 'Nintendo', 'E84ECE': 'Nintendo', '0403D6': 'Nintendo',
    '0003FF': 'Microsoft', '000D3A': 'Microsoft', '00125A': 'Microsoft', '00155D': 'Microsoft (Hyper-V)',
    '0017FA': 'Microsoft', '0050F2': 'Microsoft', '281878': 'Microsoft', '7C1E52': 'Microsoft',
    '985FD3': 'Microsoft', 'C83F26': 'Microsoft', '6045BD': 'Microsoft',

    // LG
    '001C62': 'LG Electronics', '001E75': 'LG Electronics', '001F6B': 'LG Electronics',
    '0022A9': 'LG Electronics', '0026E2': 'LG Electronics', '10683F': 'LG Electronics',
    '344DF7': 'LG Electronics', '58A2B5': 'LG Electronics', '64995D': 'LG Electronics',
    '785DC8': 'LG Electronics', 'A816B2': 'LG Electronics', 'C4366C': 'LG Electronics',
    'CC2D8C': 'LG Electronics', '88C9D0': 'LG Electronics',

    // Box FAI françaises
    '0007CB': 'Freebox', '0024D4': 'Freebox', '140C76': 'Freebox', '342792': 'Freebox',
    '68A378': 'Freebox', '70FC8F': 'Freebox', '8C97EA': 'Freebox', 'E49E12': 'Freebox',
    'F4CAE5': 'Freebox',
    '001E74': 'Sagemcom (Livebox/SFR)', '002348': 'Sagemcom (Livebox/SFR)',
    '002691': 'Sagemcom (Livebox/SFR)', '18622C': 'Sagemcom (Livebox/SFR)',
    '3C81D8': 'Sagemcom (Livebox/SFR)', '44E9DD': 'Sagemcom (Livebox/SFR)',
    '681590': 'Sagemcom (Livebox/SFR)', '7C03D8': 'Sagemcom (Livebox/SFR)',
    '88A6C6': 'Sagemcom (Livebox/SFR)', 'A01B29': 'Sagemcom (Livebox/SFR)',
    'C0D044': 'Sagemcom (Livebox/SFR)', 'E8ADA6': 'Sagemcom (Livebox/SFR)',
    'F8084F': 'Sagemcom (Livebox/SFR)',
    '0012BF': 'Arcadyan (Livebox/Bbox)', '001A2A': 'Arcadyan (Livebox/Bbox)',
    '1CC63C': 'Arcadyan (Livebox/Bbox)', '4C09D4': 'Arcadyan (Livebox/Bbox)',
    '743170': 'Arcadyan (Livebox/Bbox)', '880355': 'Arcadyan (Livebox/Bbox)',

    // TP-Link
    '001D0F': 'TP-Link', '002719': 'TP-Link', '10FEED': 'TP-Link', '14CC20': 'TP-Link',
    '18A6F7': 'TP-Link', '1C3BF3': 'TP-Link', '30B5C2': 'TP-Link', '50C7BF': 'TP-Link',
    '50D4F7': 'TP-Link', '54C80F': 'TP-Link', '60E327': 'TP-Link', '647002': 'TP-Link',
    '74DA88': 'TP-Link', '98DED0': 'TP-Link', 'A0F3C1': 'TP-Link', 'AC84C6': 'TP-Link',
    'B04E26': 'TP-Link', 'C04A00': 'TP-Link', 'C46E1F': 'TP-Link', 'D807B6': 'TP-Link',
    'E894F6': 'TP-Link', 'EC086B': 'TP-Link', 'F4F26D': 'TP-Link', 'F81A67': 'TP-Link',

    // Netgear
    '00095B': 'Netgear', '000FB5': 'Netgear', '00146C': 'Netgear', '001B2F': 'Netgear',
    '001E2A': 'Netgear', '00223F': 'Netgear', '0024B2': 'Netgear', '0026F2': 'Netgear',
    '204E7F': 'Netgear', '28C68E': 'Netgear', '2CB05D': 'Netgear', '30469A': 'Netgear',
    '4494FC': 'Netgear', '4C60DE': 'Netgear', '6CB0CE': 'Netgear', '841B5E': 'Netgear',
    '9C3DCF': 'Netgear', 'A021B7': 'Netgear', 'A040A0': 'Netgear', 'C03F0E': 'Netgear',
    'C40415': 'Netgear', 'E0469A': 'Netgear', 'E091F5': 'Netgear',

    // ASUS
    '000C6E': 'ASUSTeK', '00112F': 'ASUSTeK', '0015F2': 'ASUSTeK', '001731': 'ASUSTeK',
    '001A92': 'ASUSTeK', '001D60': 'ASUSTeK', '001E8C': 'ASUSTeK', '002215': 'ASUSTeK',
    '00248C': 'ASUSTeK', '002618': 'ASUSTeK', '08606E': 'ASUSTeK', '10BF48': 'ASUSTeK',
    '14DAE9': 'ASUSTeK', '1C872C': 'ASUSTeK', '2C56DC': 'ASUSTeK', '305A3A': 'ASUSTeK',
    '382C4A': 'ASUSTeK', '40167E': 'ASUSTeK', '50465D': 'ASUSTeK', '5404A6': 'ASUSTeK',
    '60A44C': 'ASUSTeK', '74D02B': 'ASUSTeK', 'AC220B': 'ASUSTeK', 'BCEE7B': 'ASUSTeK',
    'D850E6': 'ASUSTeK', 'E03F49': 'ASUSTeK', 'F07959': 'ASUSTeK', 'F46D04': 'ASUSTeK',

    // D-Link / Linksys / Ubiquiti / Cisco / AVM
    '00055D': 'D-Link', '000D88': 'D-Link', '000F3D': 'D-Link', '001195': 'D-Link',
    '001346': 'D-Link', '0015E9': 'D-Link', '00179A': 'D-Link', '00195B': 'D-Link',
    '001B11': 'D-Link', '001CF0': 'D-Link', '001E58': 'D-Link', '002191': 'D-Link',
    '0022B0': 'D-Link', '002401': 'D-Link', '00265A': 'D-Link', '1C7EE5': 'D-Link',
    '28107B': 'D-Link', '340804': 'D-Link', '5CD998': 'D-Link', '78542E': 'D-Link',
    '84C9B2': 'D-Link', 'B8A386': 'D-Link', 'BCF685': 'D-Link', 'C0A0BB': 'D-Link',
    'C8BE19': 'D-Link', 'CCB255': 'D-Link', 'F07D68': 'D-Link', 'FC7516': 'D-Link',
    '000625': 'Linksys', '000C41': 'Linksys', '001217': 'Linksys', '0014BF': 'Linksys',
    '001839': 'Linksys', '001A70': 'Linksys', '001C10': 'Linksys', '001D7E': 'Linksys',
    '002129': 'Linksys', '00226B': 'Linksys', '002369': 'Linksys', '00259C': 'Linksys',
    '20AA4B': 'Linksys', '48F8B3': 'Linksys', '586D8F': 'Linksys', 'C0C1C0': 'Linksys',
    '00156D': 'Ubiquiti', '002722': 'Ubiquiti', '0418D6': 'Ubiquiti', '18E829': 'Ubiquiti',
    '24A43C': 'Ubiquiti', '44D9E7': 'Ubiquiti', '687251': 'Ubiquiti', '7483C2': 'Ubiquiti',
    '788A20': 'Ubiquiti', '802AA8': 'Ubiquiti', 'B4FBE4': 'Ubiquiti', 'DC9FDB': 'Ubiquiti',
    'E063DA': 'Ubiquiti', 'F09FC2': 'Ubiquiti', 'FCECDA': 'Ubiquiti', '245A4C': 'Ubiquiti',
    '00000C': 'Cisco', '000142': 'Cisco', '001B54': 'Cisco',
    '001A4F': 'AVM (Fritz!Box)', '001C4A': 'AVM (Fritz!Box)', '00040E': 'AVM (Fritz!Box)',
    '246511': 'AVM (Fritz!Box)', '3810D5': 'AVM (Fritz!Box)', '444E6D': 'AVM (Fritz!Box)',
    '7CFF4D': 'AVM (Fritz!Box)', 'BC0543': 'AVM (Fritz!Box)', 'C80E14': 'AVM (Fritz!Box)',
    'E0286D': 'AVM (Fritz!Box)',

    // Intel (cartes Wi-Fi PC)
    '0002B3': 'Intel', '000347': 'Intel', '001302': 'Intel', '0013E8': 'Intel',
    '001500': 'Intel', '00166F': 'Intel', '0016EA': 'Intel', '0019D1': 'Intel',
    '001B21': 'Intel', '001CC0': 'Intel', '001E64': 'Intel', '001F3B': 'Intel',
    '00215C': 'Intel', '00216A': 'Intel', '0022FA': 'Intel', '0024D7': 'Intel',
    '002710': 'Intel', '100BA9': 'Intel', '340286': 'Intel', '3CA9F4': 'Intel',
    '4851B7': 'Intel', '5C514F': 'Intel', '606720': 'Intel', '7C5CF8': 'Intel',
    '8086F2': 'Intel', '8CA982': 'Intel', '94659C': 'Intel', 'A44E31': 'Intel',
    'AC7BA1': 'Intel', 'B46BFC': 'Intel', 'DC5360': 'Intel', 'F81654': 'Intel',
    'F894C2': 'Intel',

    // Dell / HP / Lenovo
    '00065B': 'Dell', '000874': 'Dell', '000BDB': 'Dell', '000D56': 'Dell',
    '000F1F': 'Dell', '001143': 'Dell', '00123F': 'Dell', '001372': 'Dell',
    '001422': 'Dell', '0015C5': 'Dell', '00188B': 'Dell', '0019B9': 'Dell',
    '001AA0': 'Dell', '001C23': 'Dell', '001D09': 'Dell', '001E4F': 'Dell',
    '14FEB5': 'Dell', '180373': 'Dell', '18A99B': 'Dell', '24B6FD': 'Dell',
    '3417EB': 'Dell', '5C260A': 'Dell', '74867A': 'Dell', '848F69': 'Dell',
    'B083FE': 'Dell', 'B8AC6F': 'Dell', 'D4AE52': 'Dell', 'D4BED9': 'Dell',
    'F01FAF': 'Dell', 'F8B156': 'Dell', 'F8DB88': 'Dell',
    '0001E6': 'HP', '0002A5': 'HP', '000BCD': 'HP', '000D9D': 'HP',
    '000E7F': 'HP', '000F20': 'HP', '001083': 'HP', '00110A': 'HP',
    '001279': 'HP', '001321': 'HP', '001438': 'HP', '001560': 'HP',
    '001635': 'HP', '001708': 'HP', '0018FE': 'HP', '0019BB': 'HP',
    '001A4B': 'HP', '001B78': 'HP', '001CC4': 'HP', '001E0B': 'HP',
    '101F74': 'HP', '3CD92B': 'HP', '705A0F': 'HP', '9457A5': 'HP',
    '9C8E99': 'HP', 'A0D3C1': 'HP', 'B499BA': 'HP', 'ECB1D7': 'HP',
    '00061B': 'Lenovo', '20768F': 'Lenovo', '6C0B84': 'Lenovo', '8C1645': 'Lenovo',
    '98FA9B': 'Lenovo', 'E8B1FC': 'Lenovo',

    // IoT, multimédia, Raspberry Pi
    'B827EB': 'Raspberry Pi', 'DCA632': 'Raspberry Pi', 'E45F01': 'Raspberry Pi',
    '28CDC1': 'Raspberry Pi', 'D83ADD': 'Raspberry Pi',
    '240AC4': 'Espressif (IoT)', '2462AB': 'Espressif (IoT)', '30AEA4': 'Espressif (IoT)',
    '3C71BF': 'Espressif (IoT)', '5CCF7F': 'Espressif (IoT)', '600194': 'Espressif (IoT)',
    '840D8E': 'Espressif (IoT)', '84CCA8': 'Espressif (IoT)', '84F3EB': 'Espressif (IoT)',
    'A4CF12': 'Espressif (IoT)', 'AC67B2': 'Espressif (IoT)', 'BCDDC2': 'Espressif (IoT)',
    'C82B96': 'Espressif (IoT)', 'CC50E3': 'Espressif (IoT)', 'DC4F22': 'Espressif (IoT)',
    'ECFABC': 'Espressif (IoT)', '18FE34': 'Espressif (IoT)', '246F28': 'Espressif (IoT)',
    '308398': 'Espressif (IoT)', '483FDA': 'Espressif (IoT)', '7C9EBD': 'Espressif (IoT)',
    '8CAAB5': 'Espressif (IoT)', '98F4AB': 'Espressif (IoT)', 'A47B9D': 'Espressif (IoT)',
    'B4E62D': 'Espressif (IoT)', 'C44F33': 'Espressif (IoT)', 'E868E7': 'Espressif (IoT)',
    '001788': 'Philips Hue (Signify)', 'ECB5FA': 'Philips Hue (Signify)',
    '000E58': 'Sonos', '5CAAFD': 'Sonos', '7828CA': 'Sonos', '949F3E': 'Sonos',
    'B8E937': 'Sonos', '48A6B8': 'Sonos', '347E5C': 'Sonos',
    '000D4B': 'Roku', 'B0A737': 'Roku', 'B83E59': 'Roku', 'C83A6B': 'Roku',
    'D04D2C': 'Roku', 'DC3A5E': 'Roku', '080581': 'Roku',
  };
}
