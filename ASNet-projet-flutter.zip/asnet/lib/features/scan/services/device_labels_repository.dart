// Décision : noms personnalisés / notes / "de confiance" stockés à part (SharedPreferences, JSON),
// indexés par MAC quand elle est fiable, sinon par IP, et réappliqués à chaque scan.
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/device.dart';

class DeviceLabel {
  const DeviceLabel({this.name, this.notes, this.trusted = false});

  final String? name;
  final String? notes;
  final bool trusted;

  bool get isEmpty => (name == null || name!.isEmpty) && (notes == null || notes!.isEmpty) && !trusted;

  Map<String, dynamic> toJson() => {'name': name, 'notes': notes, 'trusted': trusted};

  factory DeviceLabel.fromJson(Map<String, dynamic> json) => DeviceLabel(
        name: json['name'] as String?,
        notes: json['notes'] as String?,
        trusted: (json['trusted'] as bool?) ?? false,
      );
}

class DeviceLabelsRepository {
  DeviceLabelsRepository(this._prefs);

  final SharedPreferences _prefs;
  static const String storageKey = 'asnet.device_labels';

  Map<String, DeviceLabel> loadAll() {
    final raw = _prefs.getString(storageKey);
    if (raw == null || raw.isEmpty) return {};
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return {};
      final result = <String, DeviceLabel>{};
      decoded.forEach((key, value) {
        if (value is Map) result['$key'] = DeviceLabel.fromJson(Map<String, dynamic>.from(value));
      });
      return result;
    } catch (_) {
      return {};
    }
  }

  DeviceLabel? labelFor(Device device, [Map<String, DeviceLabel>? cache]) {
    final all = cache ?? loadAll();
    return all[device.storageKey] ?? all['ip:${device.ip}'];
  }

  Future<void> save(Device device, DeviceLabel label) async {
    final all = loadAll();
    all.remove('ip:${device.ip}');
    if (label.isEmpty) {
      all.remove(device.storageKey);
    } else {
      all[device.storageKey] = label;
    }
    await _prefs.setString(storageKey, jsonEncode(all.map((k, v) => MapEntry(k, v.toJson()))));
  }

  List<Device> apply(List<Device> devices) {
    final all = loadAll();
    if (all.isEmpty) return devices;
    return [
      for (final d in devices) _applyOne(d, labelFor(d, all)),
    ];
  }

  Device _applyOne(Device d, DeviceLabel? label) {
    if (label == null) return d;
    return d.withLabel(label.name, trusted: label.trusted);
  }

  Future<void> clear() => _prefs.remove(storageKey);
}
