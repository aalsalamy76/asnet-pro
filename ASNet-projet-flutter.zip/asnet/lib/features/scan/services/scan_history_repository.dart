// Décision : historique = liste "ip|mac" dans SharedPreferences (1000 entrées max).
// Un appareil est "connu" si son MAC (quand lisible) ou, à défaut, son IP a déjà été vu.
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/device.dart';

class KnownDevices {
  const KnownDevices({required this.ips, required this.macs});

  final Set<String> ips;
  final Set<String> macs;

  bool get isEmpty => ips.isEmpty && macs.isEmpty;

  bool contains(Device device) {
    final mac = device.mac;
    if (mac != null && !device.isRandomizedMac) return macs.contains(mac);
    return ips.contains(device.ip);
  }
}

class ScanHistoryRepository {
  ScanHistoryRepository(this._prefs);

  final SharedPreferences _prefs;

  static const String knownKey = 'asnet.known_devices';
  static const String lastScanKey = 'asnet.last_scan';
  static const int maxEntries = 1000;

  List<String> _entries() => _prefs.getStringList(knownKey) ?? const <String>[];

  KnownDevices snapshot() {
    final ips = <String>{};
    final macs = <String>{};
    for (final entry in _entries()) {
      final sep = entry.indexOf('|');
      if (sep < 0) continue;
      final ip = entry.substring(0, sep);
      final mac = entry.substring(sep + 1);
      if (ip.isNotEmpty) ips.add(ip);
      if (mac.isNotEmpty) macs.add(mac);
    }
    return KnownDevices(ips: ips, macs: macs);
  }

  Future<void> remember(Iterable<Device> devices) async {
    final entries = <String>{..._entries()};
    for (final d in devices) {
      entries.add('${d.ip}|${d.mac ?? ''}');
    }
    var list = entries.toList();
    if (list.length > maxEntries) list = list.sublist(list.length - maxEntries);
    await _prefs.setStringList(knownKey, list);
  }

  Future<void> saveReport(ScanReport report) async {
    await _prefs.setString(lastScanKey, jsonEncode(report.toJson()));
  }

  ScanReport? loadReport() {
    final raw = _prefs.getString(lastScanKey);
    if (raw == null || raw.isEmpty) return null;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map) return ScanReport.fromJson(Map<String, dynamic>.from(decoded));
    } catch (_) {}
    return null;
  }

  /// JSON indenté du dernier scan (export), null si aucun scan.
  String? exportLastScanJson() {
    final report = loadReport();
    if (report == null) return null;
    return const JsonEncoder.withIndent('  ').convert(report.toJson());
  }

  Future<void> clear() async {
    await _prefs.remove(knownKey);
    await _prefs.remove(lastScanKey);
  }
}
