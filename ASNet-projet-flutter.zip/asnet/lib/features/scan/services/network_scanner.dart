// Décision : sonde d'hôte = ping ICMP (binaire /system/bin/ping, utilisable sans root) ET connexion
// TCP sur des ports courants, en parallèle ; un "connection refused" prouve aussi que l'hôte existe.
// Décision : 20 sondes simultanées max, timeout 1 s ; plage limitée au /24 de l'appareil si le masque
// est plus large (254 hôtes max -> ~15 s).
// Décision : reverse DNS via InternetAddress.reverse() (InternetAddress.lookup ne fait que du DNS direct).
// Décision : MAC lues dans /proc/net/arp puis `ip neigh` ; Android 10+ bloque souvent ces deux sources
// pour les apps (confidentialité) -> MAC/fabricant "inconnus" dans ce cas, la détection IP reste réelle.
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import '../../../core/network/native_wifi.dart';
import '../models/device.dart';
import 'discovery_services.dart';
import 'oui_lookup.dart';

typedef ScanProgress = void Function(int done, int total);
typedef DeviceFound = void Function(Device device);

class SubnetRange {
  const SubnetRange({required this.network, required this.prefix, required this.hosts});

  final String network;
  final int prefix;
  final List<String> hosts;

  String get cidr => '$network/$prefix';
  String get label => hosts.isEmpty ? cidr : '${hosts.first} – ${hosts.last}';
}

class NetworkScanner {
  NetworkScanner({OuiLookup oui = const OuiLookup()}) : _oui = oui;

  final OuiLookup _oui;

  static const int maxConcurrency = 20;
  static const Duration tcpTimeout = Duration(milliseconds: 900);
  static const Duration processTimeout = Duration(milliseconds: 2500);
  static const Duration dnsTimeout = Duration(milliseconds: 1500);
  static const List<int> probePorts = [80, 443, 22, 53, 139, 445, 554, 8080, 8008, 62078];

  bool _pingUnavailable = false;
  String? _pingBinary;

  // ───────────────────────── Calcul de la plage ─────────────────────────

  static int? ipToInt(String ip) {
    final parts = ip.trim().split('.');
    if (parts.length != 4) return null;
    var value = 0;
    for (final part in parts) {
      final n = int.tryParse(part);
      if (n == null || n < 0 || n > 255) return null;
      value = (value << 8) | n;
    }
    return value;
  }

  static String intToIp(int v) =>
      '${(v >> 24) & 0xFF}.${(v >> 16) & 0xFF}.${(v >> 8) & 0xFF}.${v & 0xFF}';

  static int compareIp(String a, String b) => (ipToInt(a) ?? 0).compareTo(ipToInt(b) ?? 0);

  static SubnetRange computeRange(String selfIp, String? subnetMask) {
    final ip = ipToInt(selfIp);
    if (ip == null) {
      return SubnetRange(network: selfIp, prefix: 32, hosts: const []);
    }
    var prefix = 24;
    final mask = subnetMask == null ? null : ipToInt(subnetMask);
    if (mask != null && mask != 0) {
      var bits = 0;
      for (var i = 31; i >= 0; i--) {
        if (((mask >> i) & 1) == 1) {
          bits++;
        } else {
          break;
        }
      }
      prefix = bits;
    }
    // Masque plus large qu'un /24 (ex. /16) -> on se limite au /24 de l'appareil.
    if (prefix < 24 || prefix > 30) prefix = 24;
    final maskInt = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF;
    final network = ip & maskInt;
    final broadcast = network | (~maskInt & 0xFFFFFFFF);
    final hosts = <String>[for (var h = network + 1; h < broadcast; h++) intToIp(h)];
    return SubnetRange(network: intToIp(network), prefix: prefix, hosts: hosts);
  }

  // ───────────────────────────── Scan ─────────────────────────────

  Future<List<Device>> scan({
    required String selfIp,
    String? gatewayIp,
    String? subnetMask,
    String? selfName,
    String? selfVendor,
    ScanProgress? onProgress,
    DeviceFound? onFound,
    void Function()? onIdentifying,
    bool Function()? isCancelled,
  }) async {
    final range = computeRange(selfIp, subnetMask);
    final hosts = range.hosts;
    final hostSet = hosts.toSet();
    final alive = <String>{};
    var cursor = 0;
    var done = 0;
    bool cancelled() => isCancelled?.call() ?? false;

    Device base(String ip) => Device(
          ip: ip,
          lastSeen: DateTime.now(),
          isSelf: ip == selfIp,
          isGateway: ip == gatewayIp,
          hostname: ip == selfIp ? selfName : null,
          vendor: ip == selfIp ? selfVendor : null,
        );

    void markAlive(String ip) {
      if (alive.add(ip)) onFound?.call(base(ip));
    }

    // 1. Balayage parallèle (20 travailleurs qui se partagent la file d'IP).
    Future<void> worker() async {
      while (!cancelled() && cursor < hosts.length) {
        final ip = hosts[cursor++];
        var isAlive = ip == selfIp;
        if (!isAlive) {
          try {
            isAlive = await _probe(ip);
          } catch (_) {
            isAlive = false;
          }
        }
        done++;
        onProgress?.call(done, hosts.length);
        if (isAlive) markAlive(ip);
      }
    }

    await Future.wait(
      List.generate(math.min(maxConcurrency, math.max(hosts.length, 1)), (_) => worker()),
    );

    // 2. Identification passive en parallèle : table ARP + mDNS/Bonjour + SSDP/UPnP.
    onIdentifying?.call();
    final locked = await NativeWifi.acquireMulticast();
    final mdnsFuture = const MdnsDiscovery().discover();
    final upnpFuture = const SsdpDiscovery().discover();
    final arpFuture = readArpTable();
    final arp = await arpFuture;
    final mdns = await mdnsFuture;
    final upnp = await upnpFuture;
    if (locked) await NativeWifi.releaseMulticast();

    for (final ip in [...arp.keys, ...mdns.keys, ...upnp.keys]) {
      if (hostSet.contains(ip)) markAlive(ip);
    }
    if (hostSet.contains(selfIp)) markAlive(selfIp);
    if (gatewayIp != null && hostSet.contains(gatewayIp)) markAlive(gatewayIp);

    // 3. NetBIOS (noms Windows) + DNS inverse + latence, en parallèle borné.
    final ips = alive.toList()..sort(compareIp);
    final netbiosFuture = const NetbiosResolver().query(ips.where((ip) => ip != selfIp).toList());
    final hostnames = <String, String?>{};
    final latencies = <String, double?>{};
    var next = 0;

    Future<void> enrichWorker() async {
      while (next < ips.length) {
        final ip = ips[next++];
        final dnsFuture = reverseDns(ip);
        final latencyFuture = ip == selfIp ? Future<double?>.value(null) : pingLatency(ip);
        hostnames[ip] = await dnsFuture;
        latencies[ip] = await latencyFuture;
      }
    }

    await Future.wait(
      List.generate(math.min(maxConcurrency, math.max(ips.length, 1)), (_) => enrichWorker()),
    );
    final netbios = await netbiosFuture;

    // 4. Fusion de toutes les sources.
    final devices = <Device>[];
    for (final ip in ips) {
      final isSelf = ip == selfIp;
      final nb = netbios[ip];
      final md = mdns[ip];
      final up = upnp[ip];
      final mac = isSelf ? null : (OuiLookup.normalizeMac(arp[ip]) ?? OuiLookup.normalizeMac(nb?.mac));
      final randomized = OuiLookup.isRandomized(mac);
      final vendor = isSelf ? selfVendor : (up?.manufacturer ?? (randomized ? null : _oui.vendorOf(mac)));
      final services = <String>{
        ...?md?.services,
        ...?up?.types.map(SsdpDiscovery.shortType),
      }.toList()
        ..sort();
      String? mdnsName;
      if (md != null) {
        mdnsName = md.instances.isNotEmpty ? md.instances.first : md.name;
      }
      devices.add(Device(
        ip: ip,
        mac: mac,
        hostname: hostnames[ip] ?? (isSelf ? selfName : null),
        vendor: vendor,
        isSelf: isSelf,
        isGateway: ip == gatewayIp,
        isRandomizedMac: randomized,
        lastSeen: DateTime.now(),
        netbiosName: nb?.name,
        mdnsName: mdnsName,
        model: md?.model ?? up?.modelName,
        upnpName: up?.friendlyName,
        services: services,
        latencyMs: latencies[ip],
      ));
    }
    return devices;
  }

  /// Latence ICMP (ms) d'un hôte, null si pas de réponse.
  Future<double?> pingLatency(String ip) async {
    if (_pingUnavailable) return null;
    final binary = _pingBinary ??= _resolvePingBinary();
    try {
      final result = await Process.run(binary, ['-c', '1', '-W', '1', ip]).timeout(processTimeout);
      if (result.exitCode != 0) return null;
      final match = RegExp(r'time[=<]([\d.]+)').firstMatch('${result.stdout}');
      return match == null ? null : double.tryParse(match.group(1)!);
    } catch (_) {
      return null;
    }
  }

  // ───────────────────────────── Sondes ─────────────────────────────

  /// Vrai dès que ping OU TCP répond ; faux quand les deux ont échoué.
  Future<bool> _probe(String ip) {
    final completer = Completer<bool>();
    var pending = 2;
    void settle(bool isAlive) {
      if (completer.isCompleted) return;
      if (isAlive) {
        completer.complete(true);
        return;
      }
      pending--;
      if (pending <= 0) completer.complete(false);
    }

    _ping(ip).then(settle, onError: (Object _) => settle(false));
    _tcpProbe(ip).then(settle, onError: (Object _) => settle(false));
    return completer.future;
  }

  Future<bool> _ping(String ip) async {
    if (_pingUnavailable) return false;
    final binary = _pingBinary ??= _resolvePingBinary();
    try {
      final result = await Process.run(binary, ['-c', '1', '-W', '1', ip]).timeout(processTimeout);
      return result.exitCode == 0;
    } on ProcessException {
      _pingUnavailable = true;
      return false;
    } on TimeoutException {
      return false;
    } catch (_) {
      return false;
    }
  }

  static String _resolvePingBinary() {
    const candidates = ['/system/bin/ping', '/system/xbin/ping', '/bin/ping', '/usr/bin/ping', '/sbin/ping'];
    for (final path in candidates) {
      try {
        if (File(path).existsSync()) return path;
      } catch (_) {}
    }
    return 'ping';
  }

  Future<bool> _tcpProbe(String ip) {
    final completer = Completer<bool>();
    var pending = probePorts.length;
    void settle(bool isAlive) {
      if (completer.isCompleted) return;
      if (isAlive) {
        completer.complete(true);
        return;
      }
      pending--;
      if (pending <= 0) completer.complete(false);
    }

    for (final port in probePorts) {
      Socket.connect(ip, port, timeout: tcpTimeout).then(
        (socket) {
          socket.destroy();
          settle(true);
        },
        onError: (Object error) {
          settle(error is SocketException && _isConnectionRefused(error));
        },
      );
    }
    return completer.future;
  }

  static bool _isConnectionRefused(SocketException e) {
    final code = e.osError?.errorCode;
    if (code == 111 || code == 61 || code == 10061) return true; // ECONNREFUSED (Linux/BSD/Windows)
    final message = '${e.message} ${e.osError?.message ?? ''}'.toLowerCase();
    return message.contains('refused');
  }

  // ─────────────────────── ARP + DNS inverse ───────────────────────

  /// IP -> MAC à partir de /proc/net/arp, puis de `ip neigh` en repli.
  static Future<Map<String, String>> readArpTable() async {
    final table = <String, String>{};
    try {
      final lines = await File('/proc/net/arp').readAsLines();
      for (final line in lines.skip(1)) {
        final cols = line.trim().split(RegExp(r'\s+'));
        if (cols.length < 4) continue;
        final ip = cols[0];
        final flags = cols[2];
        final mac = OuiLookup.normalizeMac(cols[3]);
        if (flags != '0x0' && mac != null) table[ip] = mac;
      }
    } catch (_) {
      // Android 10+ : accès refusé par SELinux, on tente la commande suivante.
    }
    if (table.isNotEmpty) return table;

    try {
      final result = await Process.run('ip', ['neigh', 'show']).timeout(processTimeout);
      if (result.exitCode == 0) {
        final pattern = RegExp(r'^(\d{1,3}(?:\.\d{1,3}){3})\s.*lladdr\s+([0-9a-fA-F:]{17})');
        for (final line in '${result.stdout}'.split('\n')) {
          if (line.contains('FAILED') || line.contains('INCOMPLETE')) continue;
          final match = pattern.firstMatch(line.trim());
          if (match == null) continue;
          final mac = OuiLookup.normalizeMac(match.group(2));
          final ip = match.group(1);
          if (ip != null && mac != null) table[ip] = mac;
        }
      }
    } catch (_) {
      // Commande indisponible ou interdite : pas de MAC, le scan reste valide.
    }
    return table;
  }

  static Future<String?> reverseDns(String ip) async {
    final address = InternetAddress.tryParse(ip);
    if (address == null) return null;
    try {
      final resolved = await address.reverse().timeout(dnsTimeout);
      var host = resolved.host.trim();
      if (host.endsWith('.')) host = host.substring(0, host.length - 1);
      if (host.isEmpty || host == ip) return null;
      return host;
    } catch (_) {
      return null;
    }
  }
}
