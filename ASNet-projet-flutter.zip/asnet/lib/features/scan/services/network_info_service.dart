// Décision : toutes les lectures réseau passent par _safe() (try/catch + timeout 3 s) :
// un plugin qui échoue donne une valeur nulle, jamais un crash.
import 'dart:async';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/services.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/network_info.dart';

class NetworkInfoService {
  NetworkInfoService({
    NetworkInfo? networkInfo,
    Connectivity? connectivity,
    DeviceInfoPlugin? deviceInfo,
  })  : _info = networkInfo ?? NetworkInfo(),
        _connectivity = connectivity ?? Connectivity(),
        _deviceInfo = deviceInfo ?? DeviceInfoPlugin();

  final NetworkInfo _info;
  final Connectivity _connectivity;
  final DeviceInfoPlugin _deviceInfo;

  static const MethodChannel _wifiChannel = MethodChannel('com.asnet.app/wifi');
  static const Duration _timeout = Duration(seconds: 3);

  Future<NetworkDetails> load() async {
    final results = await _safe<List<ConnectivityResult>>(
      _connectivity.checkConnectivity,
      const [ConnectivityResult.none],
    );
    final kind = kindOf(results);

    String? model;
    String? manufacturer;
    String? android;
    if (Platform.isAndroid) {
      try {
        final info = await _deviceInfo.androidInfo.timeout(_timeout);
        model = info.model;
        manufacturer = info.manufacturer;
        android = 'Android ${info.version.release} (API ${info.version.sdkInt})';
      } catch (_) {}
    }

    if (kind == ConnectionKind.none) {
      return NetworkDetails(
        kind: kind,
        fetchedAt: DateTime.now(),
        deviceModel: model,
        deviceManufacturer: manufacturer,
        androidVersion: android,
      );
    }

    final locationGranted = await _safe<bool>(
      () async => (await Permission.locationWhenInUse.status).isGranted,
      false,
    );
    final locationService = await _safe<bool>(
      () async => (await Permission.locationWhenInUse.serviceStatus).isEnabled,
      true,
    );

    String? ssid;
    String? bssid;
    String? ip;
    String? gateway;
    String? mask;
    var security = WifiSecurity.unknown;

    if (kind == ConnectionKind.wifi) {
      ssid = cleanSsid(await _safe<String?>(_info.getWifiName, null));
      bssid = await _safe<String?>(_info.getWifiBSSID, null);
      if (bssid == null || bssid == '02:00:00:00:00:00') bssid = null;
      ip = await _safe<String?>(_info.getWifiIP, null);
      gateway = await _safe<String?>(_info.getWifiGatewayIP, null);
      mask = await _safe<String?>(_info.getWifiSubmask, null);
      security = await _readSecurity();
    }
    ip ??= await _firstLocalIPv4();

    return NetworkDetails(
      kind: kind,
      fetchedAt: DateTime.now(),
      ssid: ssid,
      bssid: bssid,
      ip: ip,
      gateway: _validIp(gateway),
      subnetMask: _validIp(mask),
      security: security,
      locationGranted: locationGranted,
      locationServiceEnabled: locationService,
      deviceModel: model,
      deviceManufacturer: manufacturer,
      androidVersion: android,
    );
  }

  static ConnectionKind kindOf(List<ConnectivityResult> results) {
    if (results.contains(ConnectivityResult.wifi)) return ConnectionKind.wifi;
    if (results.contains(ConnectivityResult.ethernet)) return ConnectionKind.ethernet;
    if (results.contains(ConnectivityResult.mobile)) return ConnectionKind.mobile;
    if (results.contains(ConnectivityResult.vpn)) return ConnectionKind.vpn;
    if (results.isEmpty || results.every((r) => r == ConnectivityResult.none)) {
      return ConnectionKind.none;
    }
    return ConnectionKind.other;
  }

  /// Android renvoie le SSID entre guillemets, ou "<unknown ssid>" sans localisation.
  static String? cleanSsid(String? raw) {
    if (raw == null) return null;
    var s = raw.trim();
    if (s.length >= 2 && s.startsWith('"') && s.endsWith('"')) {
      s = s.substring(1, s.length - 1);
    }
    if (s.isEmpty || s == '<unknown ssid>' || s == '0x') return null;
    return s;
  }

  static String? _validIp(String? value) {
    if (value == null) return null;
    final v = value.trim();
    if (v.isEmpty || v == '0.0.0.0') return null;
    return InternetAddress.tryParse(v) == null ? null : v;
  }

  Future<WifiSecurity> _readSecurity() async {
    try {
      final raw = await _wifiChannel.invokeMethod<String>('getSecurityType').timeout(_timeout);
      return NetworkDetails.parseSecurity(raw);
    } catch (_) {
      return WifiSecurity.unknown;
    }
  }

  Future<String?> _firstLocalIPv4() async {
    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      ).timeout(_timeout);
      for (final preferred in ['wlan', 'eth', '']) {
        for (final iface in interfaces) {
          if (!iface.name.startsWith(preferred)) continue;
          for (final address in iface.addresses) {
            if (!address.isLoopback && !address.isLinkLocal) return address.address;
          }
        }
      }
    } catch (_) {}
    return null;
  }

  static Future<T> _safe<T>(Future<T> Function() action, T fallback) async {
    try {
      return await action().timeout(_timeout);
    } catch (_) {
      return fallback;
    }
  }
}
