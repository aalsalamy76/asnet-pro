// Décision : couleur de l'orbe = santé réseau (cyan excellent, vert bon, ambre moyen, rouge faible,
// gris hors-ligne) ; pull-to-refresh relit les infos réseau.
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/providers/app_providers.dart';
import '../../core/router/app_router.dart';
import '../../core/services/permission_service.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../shared/utils/time_format.dart';
import '../../shared/widgets/bento_grid.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/network_orb.dart';
import '../../shared/widgets/ui_parts.dart';
import '../scan/models/network_info.dart';
import '../scan/scan_controller.dart';
import '../tools/pages/audit_page.dart';
import '../tools/tools_screen.dart';

Color healthColor(AppPalette p, NetworkHealth health) {
  switch (health) {
    case NetworkHealth.excellent:
      return p.network;
    case NetworkHealth.good:
      return p.success;
    case NetworkHealth.fair:
      return p.warning;
    case NetworkHealth.poor:
      return p.danger;
    case NetworkHealth.offline:
      return p.muted;
  }
}

String healthLabelKey(NetworkHealth health) {
  switch (health) {
    case NetworkHealth.excellent:
      return 'health_excellent';
    case NetworkHealth.good:
      return 'health_good';
    case NetworkHealth.fair:
      return 'health_fair';
    case NetworkHealth.poor:
      return 'health_poor';
    case NetworkHealth.offline:
      return 'health_offline';
  }
}

String connectionLabelKey(ConnectionKind kind) {
  switch (kind) {
    case ConnectionKind.wifi:
      return 'conn_wifi';
    case ConnectionKind.ethernet:
      return 'conn_ethernet';
    case ConnectionKind.mobile:
      return 'conn_mobile';
    case ConnectionKind.vpn:
      return 'conn_vpn';
    case ConnectionKind.other:
      return 'conn_other';
    case ConnectionKind.none:
      return 'conn_none';
  }
}

IconData connectionIcon(ConnectionKind kind) {
  switch (kind) {
    case ConnectionKind.wifi:
      return Icons.wifi_rounded;
    case ConnectionKind.ethernet:
      return Icons.settings_ethernet_rounded;
    case ConnectionKind.mobile:
      return Icons.signal_cellular_alt_rounded;
    case ConnectionKind.vpn:
      return Icons.vpn_lock_rounded;
    case ConnectionKind.other:
      return Icons.device_hub_rounded;
    case ConnectionKind.none:
      return Icons.wifi_off_rounded;
  }
}

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  Future<void> _refresh(WidgetRef ref) async {
    ref.invalidate(networkDetailsProvider);
    try {
      await ref.read(networkDetailsProvider.future);
    } catch (_) {}
  }

  Future<void> _fixLocation(BuildContext context, WidgetRef ref) async {
    final granted = await ref.read(permissionServiceProvider).ensure(context, AppPermission.location);
    if (granted) ref.invalidate(networkDetailsProvider);
  }

  void _startScan(BuildContext context, WidgetRef ref) {
    ref.read(scanControllerProvider.notifier).start();
    context.go(AppRoutes.scan);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final asyncNet = ref.watch(networkDetailsProvider);
    final scan = ref.watch(scanControllerProvider);
    final net = asyncNet.valueOrNull;
    final loading = asyncNet.isLoading && net == null;
    final health = net?.health ?? NetworkHealth.offline;
    final color = loading ? p.network : healthColor(p, health);
    final topInset = MediaQuery.paddingOf(context).top;
    final audit = ref.watch(lastAuditProvider);

    final tiles = <BentoTile>[
      BentoTile(
        span: 2,
        height: 330,
        child: _HeroTile(net: net, loading: loading, color: color, deviceCount: scan.devices.length),
      ),
      if (net != null && net.isWifi && (net.ssidHidden || !net.locationServiceEnabled))
        BentoTile(
          span: 2,
          height: 112,
          child: GlassCard(
            accent: p.warning,
            onTap: () => _fixLocation(context, ref),
            semanticLabel: l.t('ssid_hidden_hint'),
            child: Row(
              children: [
                Icon(Icons.location_off_rounded, color: p.warning, size: 28),
                const SizedBox(width: AppSpacing.md),
                Expanded(
                  child: Text(
                    l.t(net.locationServiceEnabled ? 'ssid_hidden_hint' : 'location_service_off'),
                    style: text.bodyMedium,
                  ),
                ),
                Icon(Icons.chevron_right_rounded, color: p.muted),
              ],
            ),
          ),
        ),
      BentoTile(
        height: 150,
        child: _InfoTile(
          icon: Icons.account_tree_rounded,
          label: l.t('ip_address'),
          value: net?.ip ?? '—',
          mono: true,
          footer: net?.gateway == null ? null : '${l.t('gateway')} ${net!.gateway}',
        ),
      ),
      BentoTile(
        height: 150,
        child: _InfoTile(
          icon: connectionIcon(net?.kind ?? ConnectionKind.none),
          label: l.t('connection'),
          value: l.t(connectionLabelKey(net?.kind ?? ConnectionKind.none)),
          footer: net?.androidVersion,
        ),
      ),
      BentoTile(
        height: 170,
        child: GlassCard(
          onTap: () => context.go(AppRoutes.scan),
          semanticLabel: l.t('devices_tile_semantic', {'count': scan.devices.length}),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.devices_other_rounded, color: p.network, size: 20),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(l.t('devices_detected'), style: text.labelLarge?.copyWith(color: p.muted)),
                  ),
                ],
              ),
              const Spacer(),
              Text(
                scan.status == ScanStatus.idle ? '—' : '${scan.devices.length}',
                style: text.displaySmall?.copyWith(fontFeatures: AppTypography.tabular),
              ),
              const SizedBox(height: AppSpacing.xs),
              if (scan.newCount > 0)
                StatusPill(label: l.t('new_count', {'count': scan.newCount}), color: p.share)
              else
                Text(
                  scan.isScanning
                      ? l.t('scanning_short')
                      : (scan.finishedAt == null ? l.t('no_scan_yet') : relativeTime(l, scan.finishedAt)),
                  style: text.bodySmall,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
            ],
          ),
        ),
      ),
      BentoTile(
        height: 170,
        child: GlassCard(
          semanticLabel: l.t('security_semantic', {
            'score': net?.securityScore?.toString() ?? '—',
            'protocol': net?.securityLabel ?? '—',
          }),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.security_rounded, color: p.network, size: 20),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Text(l.t('security'), style: text.labelLarge?.copyWith(color: p.muted)),
                  ),
                ],
              ),
              const Spacer(),
              Row(
                children: [
                  ScoreRing(
                    score: net?.isWifi == true ? net?.securityScore : null,
                    color: color,
                    size: 72,
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          net?.isWifi == true ? net!.securityLabel : '—',
                          style: text.titleMedium,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          l.t(_securityHintKey(net)),
                          style: text.bodySmall,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      BentoTile(
        height: 128,
        child: _QuickTool(
          icon: Icons.security_rounded,
          title: l.t('tool_audit'),
          subtitle: audit == null
              ? l.t('audit_never')
              : l.t('audit_score_short', {'score': audit.score}),
          color: audit == null ? p.share : scoreColor(p, audit.score),
          onTap: () => openTool(context, ToolId.audit),
        ),
      ),
      BentoTile(
        height: 128,
        child: _QuickTool(
          icon: Icons.speed_rounded,
          title: l.t('tool_speed'),
          subtitle: l.t('tool_speed_desc'),
          color: p.network,
          onTap: () => openTool(context, ToolId.speed),
        ),
      ),
      BentoTile(
        height: 128,
        child: _QuickTool(
          icon: Icons.wifi_rounded,
          title: l.t('tool_wifi'),
          subtitle: l.t('tool_wifi_desc'),
          color: p.network,
          onTap: () => openTool(context, ToolId.wifi),
        ),
      ),
      BentoTile(
        height: 128,
        child: _QuickTool(
          icon: Icons.public_rounded,
          title: l.t('tool_public_ip'),
          subtitle: l.t('tool_public_ip_desc'),
          color: p.network,
          onTap: () => openTool(context, ToolId.publicIp),
        ),
      ),
      BentoTile(
        span: 2,
        height: 116,
        child: GlassCard(
          padding: const EdgeInsets.all(AppSpacing.md),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GradientButton(
                label: scan.isScanning ? l.t('scan_in_progress') : l.t('scan_network'),
                icon: Icons.track_changes_rounded,
                busy: scan.isScanning,
                onPressed: () => scan.isScanning ? context.go(AppRoutes.scan) : _startScan(context, ref),
              ),
              const SizedBox(height: AppSpacing.xs),
              Text(
                '${l.t('last_scan')} : ${relativeTime(l, scan.finishedAt)}',
                style: text.bodySmall,
              ),
            ],
          ),
        ),
      ),
    ];

    return RefreshIndicator(
      color: p.network,
      onRefresh: () => _refresh(ref),
      edgeOffset: topInset,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: AppSpacing.screen.copyWith(top: topInset + AppSpacing.lg),
        children: [
          _Header(color: color, healthLabel: loading ? l.t('loading') : l.t(healthLabelKey(health))),
          const SizedBox(height: AppSpacing.lg),
          BentoGrid(tiles: tiles),
          if (asyncNet.hasError)
            Padding(
              padding: const EdgeInsets.only(top: AppSpacing.md),
              child: Text(l.t('network_read_error'), style: text.bodySmall?.copyWith(color: p.danger)),
            ),
        ],
      ),
    );
  }

  static String _securityHintKey(NetworkDetails? net) {
    if (net == null || !net.isWifi) return 'security_na';
    final score = net.securityScore;
    if (score == null) return net.locationGranted ? 'security_unknown' : 'security_need_location';
    if (score >= 90) return 'security_strong';
    if (score >= 70) return 'security_ok';
    if (score >= 40) return 'security_weak';
    return 'security_critical';
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.color, required this.healthLabel});

  final Color color;
  final String healthLabel;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    return Row(
      children: [
        Container(
          width: 44,
          height: 44,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: p.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: p.network.faded(0.4)),
          ),
          child: Text(
            'AS',
            style: text.titleMedium?.copyWith(color: p.network, fontWeight: FontWeight.w900),
          ),
        ),
        const SizedBox(width: AppSpacing.md),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Semantics(header: true, child: Text('A.SNet', style: text.headlineSmall)),
              Text(context.l10n.t('dashboard_subtitle'), style: text.bodySmall),
            ],
          ),
        ),
        StatusPill(label: healthLabel, color: color),
      ],
    );
  }
}

class _HeroTile extends StatelessWidget {
  const _HeroTile({
    required this.net,
    required this.loading,
    required this.color,
    required this.deviceCount,
  });

  final NetworkDetails? net;
  final bool loading;
  final Color color;
  final int deviceCount;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final details = net;

    String title;
    if (loading) {
      title = l.t('loading');
    } else if (details == null || !details.isOnline) {
      title = l.t('conn_none');
    } else if (details.isWifi) {
      title = details.ssid ?? l.t('ssid_hidden');
    } else {
      title = l.t(connectionLabelKey(details.kind));
    }

    final subtitle = details == null || !details.isOnline
        ? l.t('offline_hint')
        : details.isWifi
            ? '${l.t('conn_wifi')} · ${details.securityLabel}'
            : l.t('lan_scan_wifi_only');

    return GlassCard(
      accent: color,
      semanticLabel: '$title. $subtitle',
      child: Column(
        children: [
          Expanded(
            child: Center(
              child: FittedBox(
                child: NetworkOrb(
                  color: color,
                  deviceCount: deviceCount,
                  size: 210,
                  active: details?.isOnline ?? true,
                  semanticLabel: l.t('orb_semantic'),
                ),
              ),
            ),
          ),
          Text(
            title,
            style: text.headlineSmall,
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: AppSpacing.xs),
          Text(
            subtitle,
            style: text.bodyMedium?.copyWith(color: p.muted),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class _InfoTile extends StatelessWidget {
  const _InfoTile({
    required this.icon,
    required this.label,
    required this.value,
    this.footer,
    this.mono = false,
  });

  final IconData icon;
  final String label;
  final String value;
  final String? footer;
  final bool mono;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    return GlassCard(
      semanticLabel: '$label : $value',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: p.network, size: 20),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  label,
                  style: text.labelLarge?.copyWith(color: p.muted),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const Spacer(),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: AlignmentDirectional.centerStart,
            child: Text(
              value,
              style: mono
                  ? AppTypography.mono(size: 20, weight: FontWeight.w700, color: p.text)
                  : text.titleLarge,
            ),
          ),
          if (footer != null) ...[
            const SizedBox(height: AppSpacing.xs),
            Text(
              footer!,
              style: mono ? AppTypography.mono(size: 12, color: p.muted) : text.bodySmall,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ],
      ),
    );
  }
}

class _QuickTool extends StatelessWidget {
  const _QuickTool({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return GlassCard(
      onTap: onTap,
      accent: color,
      padding: const EdgeInsets.all(AppSpacing.md),
      semanticLabel: '$title. $subtitle',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 24),
          const Spacer(),
          Text(title, style: text.titleSmall?.copyWith(fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
          Text(subtitle, style: text.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}
