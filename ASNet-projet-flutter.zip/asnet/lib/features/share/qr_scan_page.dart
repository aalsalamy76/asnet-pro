// Décision : page plein écran poussée sur le navigateur racine -> la caméra n'est active que
// pendant le scan (le shell IndexedStack garderait sinon le flux caméra ouvert).
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_motion.dart';

class QrScanPage extends StatefulWidget {
  const QrScanPage({super.key});

  /// Ouvre le scanner et renvoie le texte du QR lu (null si annulé).
  static Future<String?> open(BuildContext context) {
    return Navigator.of(context, rootNavigator: true).push<String>(
      MaterialPageRoute<String>(builder: (_) => const QrScanPage(), fullscreenDialog: true),
    );
  }

  @override
  State<QrScanPage> createState() => _QrScanPageState();
}

class _QrScanPageState extends State<QrScanPage> {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.noDuplicates,
    facing: CameraFacing.back,
    formats: const [BarcodeFormat.qrCode],
  );
  bool _handled = false;
  bool _torchOn = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_handled) return;
    for (final barcode in capture.barcodes) {
      final value = barcode.rawValue;
      if (value != null && value.isNotEmpty) {
        _handled = true;
        AppMotion.confirm();
        Navigator.of(context).pop(value);
        return;
      }
    }
  }

  Future<void> _toggleTorch() async {
    try {
      await _controller.toggleTorch();
      if (mounted) setState(() => _torchOn = !_torchOn);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
          ),
          IgnorePointer(
            child: CustomPaint(painter: _ViewfinderPainter(color: AppColors.cyan)),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  IconButton.filledTonal(
                    tooltip: l.t('close'),
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close_rounded),
                  ),
                  const Spacer(),
                  IconButton.filledTonal(
                    tooltip: l.t('torch'),
                    onPressed: _toggleTorch,
                    icon: Icon(_torchOn ? Icons.flash_on_rounded : Icons.flash_off_rounded),
                  ),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              child: Container(
                margin: const EdgeInsets.all(24),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                decoration: BoxDecoration(
                  color: Colors.black.faded(0.6),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: p.share.faded(0.5)),
                ),
                child: Text(
                  l.t('qr_scan_hint'),
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Assombrit l'extérieur et dessine les coins du viseur.
class _ViewfinderPainter extends CustomPainter {
  _ViewfinderPainter({required this.color});

  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final side = size.shortestSide * 0.68;
    final rect = Rect.fromCenter(center: size.center(Offset.zero), width: side, height: side);
    final frame = RRect.fromRectAndRadius(rect, const Radius.circular(28));

    final shade = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(Offset.zero & size)
      ..addRRect(frame);
    canvas.drawPath(shade, Paint()..color = Colors.black.faded(0.5));

    final corner = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    const len = 34.0;
    final l = rect.left;
    final t = rect.top;
    final r = rect.right;
    final b = rect.bottom;
    canvas.drawLine(Offset(l, t + len), Offset(l, t + 10), corner);
    canvas.drawLine(Offset(l + 10, t), Offset(l + len, t), corner);
    canvas.drawLine(Offset(r - len, t), Offset(r - 10, t), corner);
    canvas.drawLine(Offset(r, t + 10), Offset(r, t + len), corner);
    canvas.drawLine(Offset(l, b - len), Offset(l, b - 10), corner);
    canvas.drawLine(Offset(l + 10, b), Offset(l + len, b), corner);
    canvas.drawLine(Offset(r - len, b), Offset(r - 10, b), corner);
    canvas.drawLine(Offset(r, b - 10), Offset(r, b - len), corner);
  }

  @override
  bool shouldRepaint(covariant _ViewfinderPainter old) => old.color != color;
}
