// Décision : mots de passe Wi-Fi mémorisés uniquement dans flutter_secure_storage (Keystore Android),
// une entrée par SSID ; le QR partagé est une image PNG fond blanc + le texte en clair au choix de l'utilisateur.
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/providers/app_providers.dart';
import '../../core/services/permission_service.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_motion.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../shared/utils/feedback.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/ui_parts.dart';
import 'qr_scan_page.dart';
import 'wifi_qr.dart';

class ShareScreen extends ConsumerStatefulWidget {
  const ShareScreen({super.key});

  @override
  ConsumerState<ShareScreen> createState() => _ShareScreenState();
}

class _ShareScreenState extends ConsumerState<ShareScreen> {
  final TextEditingController _ssid = TextEditingController();
  final TextEditingController _password = TextEditingController();
  WifiAuth _auth = WifiAuth.wpa;
  bool _hidden = false;
  bool _obscure = true;
  bool _busy = false;
  bool _prefilled = false;

  static const String _storagePrefix = 'asnet.wifi.';

  @override
  void initState() {
    super.initState();
    _ssid.addListener(_onChanged);
    _password.addListener(_onChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) => _prefillFromNetwork());
  }

  @override
  void dispose() {
    _ssid.dispose();
    _password.dispose();
    super.dispose();
  }

  void _onChanged() {
    if (mounted) setState(() {});
  }

  WifiCredentials get _credentials => WifiCredentials(
        ssid: _ssid.text.trim(),
        password: _password.text,
        auth: _auth,
        hidden: _hidden,
      );

  Future<void> _prefillFromNetwork() async {
    if (_prefilled) return;
    try {
      final details = await ref.read(networkDetailsProvider.future);
      final ssid = details.ssid;
      if (!mounted || ssid == null || _ssid.text.isNotEmpty) return;
      _prefilled = true;
      _ssid.text = ssid;
      await _loadSaved(ssid, silent: true);
    } catch (_) {}
  }

  Future<void> _loadSaved(String ssid, {bool silent = false}) async {
    try {
      final raw = await ref.read(secureStorageProvider).read(key: '$_storagePrefix$ssid');
      if (raw == null) {
        if (!silent && mounted) showAppSnack(context, context.l10n.t('nothing_saved'));
        return;
      }
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return;
      final creds = WifiCredentials.fromJson(Map<String, dynamic>.from(decoded));
      if (!mounted) return;
      setState(() {
        _password.text = creds.password;
        _auth = creds.auth;
        _hidden = creds.hidden;
      });
      if (!silent) showAppSnack(context, context.l10n.t('loaded_saved'), kind: FeedbackKind.success);
    } catch (_) {
      if (!silent && mounted) {
        showAppSnack(context, context.l10n.t('secure_storage_error'), kind: FeedbackKind.error);
      }
    }
  }

  Future<void> _save() async {
    final l = context.l10n;
    final creds = _credentials;
    if (!creds.isValid) {
      showAppSnack(context, l.t(_validationKey(creds)), kind: FeedbackKind.error);
      return;
    }
    try {
      await ref
          .read(secureStorageProvider)
          .write(key: '$_storagePrefix${creds.ssid}', value: jsonEncode(creds.toJson()));
      if (!mounted) return;
      AppMotion.confirm();
      showAppSnack(context, l.t('saved_secure'), kind: FeedbackKind.success);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('secure_storage_error'), kind: FeedbackKind.error);
    }
  }

  String _validationKey(WifiCredentials c) {
    if (c.ssid.isEmpty) return 'error_ssid_required';
    if (c.auth == WifiAuth.wpa) return 'error_wpa_length';
    return 'error_password_required';
  }

  Future<Uint8List?> _renderQrPng(String payload) async {
    const size = 1024.0;
    const padding = 72.0;
    final painter = QrPainter(
      data: payload,
      version: QrVersions.auto,
      gapless: true,
      eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: AppColors.bg),
      dataModuleStyle: const QrDataModuleStyle(
        dataModuleShape: QrDataModuleShape.square,
        color: AppColors.bg,
      ),
    );
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.drawRect(const Rect.fromLTWH(0, 0, size, size), Paint()..color = Colors.white);
    canvas.translate(padding, padding);
    painter.paint(canvas, const Size(size - padding * 2, size - padding * 2));
    final image = await recorder.endRecording().toImage(size.toInt(), size.toInt());
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    return data?.buffer.asUint8List();
  }

  Future<void> _share() async {
    final l = context.l10n;
    final creds = _credentials;
    if (!creds.isValid) {
      showAppSnack(context, l.t(_validationKey(creds)), kind: FeedbackKind.error);
      return;
    }
    setState(() => _busy = true);
    final message = creds.auth == WifiAuth.open
        ? l.t('share_text_open', {'ssid': creds.ssid})
        : l.t('share_text', {'ssid': creds.ssid, 'password': creds.password});
    try {
      final bytes = await _renderQrPng(creds.toQrPayload());
      if (bytes == null) throw StateError('png');
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/asnet_wifi_qr.png');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'image/png')],
        text: message,
        subject: 'Wi-Fi ${creds.ssid}',
      );
    } catch (_) {
      try {
        await Share.share(message, subject: 'Wi-Fi ${creds.ssid}');
      } catch (_) {
        if (mounted) showAppSnack(context, l.t('share_failed'), kind: FeedbackKind.error);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _scanQr() async {
    final granted = await ref.read(permissionServiceProvider).ensure(context, AppPermission.camera);
    if (!granted || !mounted) return;
    final raw = await QrScanPage.open(context);
    if (raw == null || !mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _ScanResultSheet(
        raw: raw,
        onUseCredentials: (creds) {
          setState(() {
            _ssid.text = creds.ssid;
            _password.text = creds.password;
            _auth = creds.auth;
            _hidden = creds.hidden;
          });
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final topInset = MediaQuery.paddingOf(context).top;
    final creds = _credentials;
    final payload = creds.toQrPayload();

    return ListView(
      padding: AppSpacing.screen.copyWith(top: topInset + AppSpacing.lg),
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      children: [
        Semantics(header: true, child: Text(l.t('share_title'), style: text.headlineMedium)),
        const SizedBox(height: AppSpacing.xs),
        Text(l.t('share_subtitle'), style: text.bodyMedium?.copyWith(color: p.muted)),
        const SizedBox(height: AppSpacing.lg),

        // ── QR ─────────────────────────────────────────
        GlassCard(
          accent: p.share,
          child: Column(
            children: [
              AnimatedSwitcher(
                duration: AppMotion.base,
                switchInCurve: AppMotion.ease,
                child: creds.ssid.isEmpty
                    ? SizedBox(
                        key: const ValueKey('empty'),
                        height: 236,
                        child: EmptyState(
                          icon: Icons.qr_code_rounded,
                          title: l.t('qr_empty_title'),
                          message: l.t('qr_empty_body'),
                        ),
                      )
                    : Container(
                        key: const ValueKey('qr'),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(24),
                          boxShadow: [
                            BoxShadow(color: p.share.faded(0.35), blurRadius: 30, offset: const Offset(0, 10)),
                          ],
                        ),
                        child: QrImageView(
                          data: payload,
                          version: QrVersions.auto,
                          size: 208,
                          padding: EdgeInsets.zero,
                          backgroundColor: Colors.white,
                          gapless: true,
                          semanticsLabel: l.t('qr_semantic', {'ssid': creds.ssid}),
                          eyeStyle: const QrEyeStyle(eyeShape: QrEyeShape.square, color: AppColors.bg),
                          dataModuleStyle: const QrDataModuleStyle(
                            dataModuleShape: QrDataModuleShape.square,
                            color: AppColors.bg,
                          ),
                        ),
                      ),
              ),
              const SizedBox(height: AppSpacing.md),
              Text(
                creds.ssid.isEmpty ? '—' : creds.ssid,
                style: text.titleLarge,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                creds.authCode == 'nopass' ? l.t('auth_open') : creds.authCode,
                style: AppTypography.mono(size: 12, color: p.muted),
              ),
              const SizedBox(height: AppSpacing.lg),
              GradientButton(
                label: l.t('share_qr'),
                icon: Icons.share_rounded,
                busy: _busy,
                onPressed: creds.ssid.isEmpty ? null : _share,
              ),
            ],
          ),
        ),

        // ── Formulaire ────────────────────────────────
        SectionTitle(l.t('wifi_details')),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _ssid,
                textInputAction: TextInputAction.next,
                autocorrect: false,
                decoration: InputDecoration(
                  labelText: l.t('ssid_label'),
                  prefixIcon: const Icon(Icons.wifi_rounded),
                  suffixIcon: IconButton(
                    tooltip: l.t('load_saved'),
                    icon: const Icon(Icons.vpn_key_rounded),
                    onPressed: () {
                      final ssid = _ssid.text.trim();
                      if (ssid.isEmpty) {
                        showAppSnack(context, l.t('error_ssid_required'), kind: FeedbackKind.error);
                      } else {
                        _loadSaved(ssid);
                      }
                    },
                  ),
                ),
              ),
              const SizedBox(height: AppSpacing.md),
              if (_auth != WifiAuth.open)
                TextField(
                  controller: _password,
                  obscureText: _obscure,
                  autocorrect: false,
                  enableSuggestions: false,
                  keyboardType: TextInputType.visiblePassword,
                  decoration: InputDecoration(
                    labelText: l.t('password_label'),
                    prefixIcon: const Icon(Icons.lock_rounded),
                    suffixIcon: IconButton(
                      tooltip: l.t(_obscure ? 'show_password' : 'hide_password'),
                      icon: Icon(_obscure ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                      onPressed: () => setState(() => _obscure = !_obscure),
                    ),
                  ),
                ),
              if (_auth != WifiAuth.open) const SizedBox(height: AppSpacing.md),
              SegmentedButton<WifiAuth>(
                showSelectedIcon: false,
                segments: [
                  const ButtonSegment(value: WifiAuth.wpa, label: Text('WPA/WPA2/WPA3')),
                  const ButtonSegment(value: WifiAuth.wep, label: Text('WEP')),
                  ButtonSegment(value: WifiAuth.open, label: Text(l.t('auth_open'))),
                ],
                selected: {_auth},
                onSelectionChanged: (selection) {
                  AppMotion.tap();
                  setState(() => _auth = selection.first);
                },
              ),
              const SizedBox(height: AppSpacing.xs),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(l.t('hidden_network')),
                value: _hidden,
                onChanged: (v) => setState(() => _hidden = v),
              ),
              const SizedBox(height: AppSpacing.xs),
              OutlinedButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.enhanced_encryption_rounded),
                label: Text(l.t('save_secure')),
              ),
            ],
          ),
        ),

        // ── Scanner ───────────────────────────────────
        SectionTitle(l.t('receive')),
        GlassCard(
          accent: p.share,
          onTap: _scanQr,
          semanticLabel: l.t('scan_qr'),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: p.share.faded(0.16),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(Icons.qr_code_scanner_rounded, color: p.share),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(l.t('scan_qr'), style: text.titleMedium),
                    Text(l.t('scan_qr_desc'), style: text.bodySmall),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: p.muted),
            ],
          ),
        ),
      ],
    );
  }
}

class _ScanResultSheet extends StatefulWidget {
  const _ScanResultSheet({required this.raw, required this.onUseCredentials});

  final String raw;
  final ValueChanged<WifiCredentials> onUseCredentials;

  @override
  State<_ScanResultSheet> createState() => _ScanResultSheetState();
}

class _ScanResultSheetState extends State<_ScanResultSheet> {
  bool _reveal = false;

  Future<void> _copy(String value) async {
    final l = context.l10n;
    try {
      await Clipboard.setData(ClipboardData(text: value));
      if (mounted) showAppSnack(context, l.t('copied'), kind: FeedbackKind.success);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('copy_failed'), kind: FeedbackKind.error);
    }
  }

  Future<void> _open(Uri uri) async {
    final l = context.l10n;
    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok && mounted) showAppSnack(context, l.t('open_failed'), kind: FeedbackKind.error);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('open_failed'), kind: FeedbackKind.error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final wifi = WifiCredentials.parse(widget.raw);
    final uri = Uri.tryParse(widget.raw.trim());
    final isLink = uri != null && (uri.scheme == 'http' || uri.scheme == 'https') && uri.host.isNotEmpty;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(wifi != null ? Icons.wifi_rounded : Icons.qr_code_rounded, color: p.share, size: 30),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Text(
                  wifi != null ? l.t('wifi_found') : l.t('qr_content'),
                  style: text.titleLarge,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.lg),
          if (wifi != null) ...[
            _kv(context, l.t('ssid_label'), wifi.ssid),
            _kv(context, l.t('security'), wifi.auth == WifiAuth.open ? l.t('auth_open') : wifi.authCode),
            if (wifi.auth != WifiAuth.open)
              Row(
                children: [
                  Expanded(
                    child: _kv(
                      context,
                      l.t('password_label'),
                      _reveal ? wifi.password : '•' * math.max(6, math.min(16, wifi.password.length)),
                    ),
                  ),
                  IconButton(
                    tooltip: l.t(_reveal ? 'hide_password' : 'show_password'),
                    onPressed: () => setState(() => _reveal = !_reveal),
                    icon: Icon(_reveal ? Icons.visibility_off_rounded : Icons.visibility_rounded),
                  ),
                ],
              ),
            const SizedBox(height: AppSpacing.md),
            Text(l.t('wifi_connect_hint'), style: text.bodySmall),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                if (wifi.auth != WifiAuth.open)
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _copy(wifi.password),
                      icon: const Icon(Icons.content_copy_rounded, size: 18),
                      label: Text(l.t('copy_password')),
                    ),
                  ),
                if (wifi.auth != WifiAuth.open) const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () {
                      widget.onUseCredentials(wifi);
                      Navigator.of(context).pop();
                    },
                    icon: const Icon(Icons.edit_rounded, size: 18),
                    label: Text(l.t('use_in_form')),
                  ),
                ),
              ],
            ),
          ] else ...[
            Container(
              padding: const EdgeInsets.all(AppSpacing.md),
              decoration: BoxDecoration(
                color: p.background,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: p.glassBorder),
              ),
              constraints: const BoxConstraints(maxHeight: 220),
              child: SingleChildScrollView(
                child: SelectableText(widget.raw, style: AppTypography.mono(size: 14, color: p.text)),
              ),
            ),
            const SizedBox(height: AppSpacing.lg),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _copy(widget.raw),
                    icon: const Icon(Icons.content_copy_rounded, size: 18),
                    label: Text(l.t('copy')),
                  ),
                ),
                const SizedBox(width: AppSpacing.sm),
                Expanded(
                  child: isLink
                      ? FilledButton.icon(
                          onPressed: () => _open(uri!),
                          icon: const Icon(Icons.open_in_new_rounded, size: 18),
                          label: Text(l.t('open_link')),
                        )
                      : FilledButton.icon(
                          onPressed: () async {
                            try {
                              await Share.share(widget.raw);
                            } catch (_) {
                              if (context.mounted) {
                                showAppSnack(context, l.t('share_failed'), kind: FeedbackKind.error);
                              }
                            }
                          },
                          icon: const Icon(Icons.share_rounded, size: 18),
                          label: Text(l.t('share')),
                        ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _kv(BuildContext context, String key, String value) {
    final p = context.palette;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(key, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: p.muted)),
          ),
          Expanded(child: SelectableText(value, style: AppTypography.mono(size: 15, color: p.text))),
        ],
      ),
    );
  }
}
