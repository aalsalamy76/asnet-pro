// Format standard (ZXing) : WIFI:T:WPA;S:<ssid>;P:<mot de passe>;H:true;;
// Les caractères \ ; , : " sont échappés par un antislash.
enum WifiAuth { wpa, wep, open }

class WifiCredentials {
  const WifiCredentials({
    required this.ssid,
    this.password = '',
    this.auth = WifiAuth.wpa,
    this.hidden = false,
  });

  final String ssid;
  final String password;
  final WifiAuth auth;
  final bool hidden;

  bool get isValid {
    if (ssid.trim().isEmpty) return false;
    if (auth == WifiAuth.open) return true;
    if (auth == WifiAuth.wpa) return password.length >= 8 && password.length <= 63;
    return password.isNotEmpty;
  }

  String get authCode {
    switch (auth) {
      case WifiAuth.wpa:
        return 'WPA';
      case WifiAuth.wep:
        return 'WEP';
      case WifiAuth.open:
        return 'nopass';
    }
  }

  static String _escape(String value) =>
      value.replaceAllMapped(RegExp(r'([\\;,:"])'), (m) => '\\${m[1]}');

  String toQrPayload() {
    final buffer = StringBuffer('WIFI:T:$authCode;S:${_escape(ssid)};');
    if (auth != WifiAuth.open) buffer.write('P:${_escape(password)};');
    if (hidden) buffer.write('H:true;');
    buffer.write(';');
    return buffer.toString();
  }

  Map<String, dynamic> toJson() => {
        'ssid': ssid,
        'password': password,
        'auth': auth.name,
        'hidden': hidden,
      };

  factory WifiCredentials.fromJson(Map<String, dynamic> json) {
    final authName = json['auth'] as String?;
    return WifiCredentials(
      ssid: (json['ssid'] as String?) ?? '',
      password: (json['password'] as String?) ?? '',
      auth: WifiAuth.values.firstWhere(
        (a) => a.name == authName,
        orElse: () => WifiAuth.wpa,
      ),
      hidden: (json['hidden'] as bool?) ?? false,
    );
  }

  /// Analyse un QR "WIFI:..." ; null si ce n'en est pas un.
  static WifiCredentials? parse(String raw) {
    final trimmed = raw.trim();
    if (!trimmed.toUpperCase().startsWith('WIFI:')) return null;
    final body = trimmed.substring(5);

    final fields = <String, String>{};
    final current = StringBuffer();
    var escaped = false;
    void flush() {
      final token = current.toString();
      current.clear();
      final sep = _firstUnescapedColon(token);
      if (sep <= 0) return;
      final key = token.substring(0, sep).toUpperCase();
      fields[key] = _unescape(token.substring(sep + 1));
    }

    for (final unit in body.split('')) {
      if (escaped) {
        current
          ..write('\\')
          ..write(unit);
        escaped = false;
      } else if (unit == '\\') {
        escaped = true;
      } else if (unit == ';') {
        flush();
      } else {
        current.write(unit);
      }
    }
    if (current.isNotEmpty) flush();

    final ssid = fields['S'];
    if (ssid == null || ssid.isEmpty) return null;
    final type = (fields['T'] ?? '').toUpperCase();
    final auth = type == 'WEP'
        ? WifiAuth.wep
        : (type.isEmpty || type == 'NOPASS')
            ? (fields['P']?.isNotEmpty ?? false ? WifiAuth.wpa : WifiAuth.open)
            : WifiAuth.wpa;
    return WifiCredentials(
      ssid: ssid,
      password: fields['P'] ?? '',
      auth: auth,
      hidden: (fields['H'] ?? '').toLowerCase() == 'true',
    );
  }

  static int _firstUnescapedColon(String token) {
    for (var i = 0; i < token.length; i++) {
      if (token[i] == '\\') {
        i++;
        continue;
      }
      if (token[i] == ':') return i;
    }
    return -1;
  }

  static String _unescape(String value) {
    final out = StringBuffer();
    var escaped = false;
    for (final unit in value.split('')) {
      if (escaped) {
        out.write(unit);
        escaped = false;
      } else if (unit == '\\') {
        escaped = true;
      } else {
        out.write(unit);
      }
    }
    return out.toString();
  }
}
