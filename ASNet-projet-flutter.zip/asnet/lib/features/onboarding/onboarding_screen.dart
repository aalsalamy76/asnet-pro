// Décision : permissions demandées sur la 3e slide uniquement (contexte expliqué avant la demande),
// et toujours facultatives : l'app reste utilisable si l'utilisateur refuse.
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/providers/app_providers.dart';
import '../../core/providers/theme_provider.dart';
import '../../core/router/app_router.dart';
import '../../core/services/permission_service.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_motion.dart';
import '../../core/theme/app_spacing.dart';
import '../../shared/utils/feedback.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/network_orb.dart';
import '../../shared/widgets/scan_radar.dart';
import '../../shared/widgets/ui_parts.dart';

class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key});

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final PageController _pages = PageController();
  int _index = 0;
  bool _locationGranted = false;
  bool _cameraGranted = false;
  bool _requesting = false;

  static const int _pageCount = 3;

  @override
  void initState() {
    super.initState();
    _refreshStatuses();
  }

  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  Future<void> _refreshStatuses() async {
    final service = ref.read(permissionServiceProvider);
    final location = await service.isGranted(AppPermission.location);
    final camera = await service.isGranted(AppPermission.camera);
    if (!mounted) return;
    setState(() {
      _locationGranted = location;
      _cameraGranted = camera;
    });
  }

  Future<void> _requestPermissions() async {
    if (_requesting) return;
    setState(() => _requesting = true);
    final service = ref.read(permissionServiceProvider);
    try {
      final location = await service.request(AppPermission.location);
      final camera = await service.request(AppPermission.camera);
      if (!mounted) return;
      setState(() {
        _locationGranted = location;
        _cameraGranted = camera;
      });
      if (!location) {
        await PermissionService.showPermissionRationale(context, AppPermission.location)
            .then((open) async {
          if (open == true) await service.openSettings();
        });
      } else if (!camera) {
        if (!mounted) return;
        await PermissionService.showPermissionRationale(context, AppPermission.camera)
            .then((open) async {
          if (open == true) await service.openSettings();
        });
      } else {
        AppMotion.confirm();
        if (mounted) showAppSnack(context, context.l10n.t('perm_all_granted'), kind: FeedbackKind.success);
      }
    } catch (_) {
      if (mounted) showAppSnack(context, context.l10n.t('perm_error'), kind: FeedbackKind.error);
    } finally {
      if (mounted) setState(() => _requesting = false);
    }
    if (mounted) ref.invalidate(networkDetailsProvider);
  }

  Future<void> _finish() async {
    try {
      await ref.read(sharedPreferencesProvider).setBool(onboardingDoneKey, true);
    } catch (_) {}
    if (!mounted) return;
    ref.invalidate(networkDetailsProvider);
    context.go(AppRoutes.dashboard);
  }

  void _next() {
    AppMotion.tap();
    if (_index < _pageCount - 1) {
      _pages.nextPage(duration: AppMotion.slow, curve: AppMotion.ease);
    } else {
      _finish();
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final isLast = _index == _pageCount - 1;

    return Scaffold(
      backgroundColor: p.background,
      body: LiquidBackground(
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 0),
                child: Row(
                  children: [
                    const _LanguageButton(),
                    const Spacer(),
                    AnimatedOpacity(
                      opacity: isLast ? 0 : 1,
                      duration: AppMotion.fast,
                      child: TextButton(
                        onPressed: isLast ? null : _finish,
                        child: Text(l.t('skip')),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: PageView(
                  controller: _pages,
                  onPageChanged: (i) => setState(() => _index = i),
                  children: [
                    _Slide(
                      visual: NetworkOrb(
                        color: p.network,
                        deviceCount: 6,
                        size: 240,
                        semanticLabel: l.t('onb1_title'),
                      ),
                      title: l.t('onb1_title'),
                      body: l.t('onb1_body'),
                    ),
                    _Slide(
                      visual: ScanRadar(
                        active: true,
                        color: p.network,
                        size: 240,
                        blips: const ['192.168.1.1', '192.168.1.12', '192.168.1.24', '192.168.1.37', '192.168.1.58'],
                        semanticLabel: l.t('onb2_title'),
                      ),
                      title: l.t('onb2_title'),
                      body: l.t('onb2_body'),
                    ),
                    _PermissionsSlide(
                      locationGranted: _locationGranted,
                      cameraGranted: _cameraGranted,
                      requesting: _requesting,
                      onRequest: _requestPermissions,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                child: Column(
                  children: [
                    Semantics(
                      label: l.t('page_indicator', {'current': _index + 1, 'total': _pageCount}),
                      excludeSemantics: true,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          for (var i = 0; i < _pageCount; i++)
                            AnimatedContainer(
                              duration: AppMotion.base,
                              curve: AppMotion.ease,
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              width: i == _index ? 28 : 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: i == _index ? p.network : p.muted.faded(0.4),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: AppSpacing.xl),
                    GradientButton(
                      label: isLast ? l.t('get_started') : l.t('next'),
                      icon: isLast ? Icons.check_rounded : Icons.arrow_forward_rounded,
                      onPressed: _next,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Slide extends StatelessWidget {
  const _Slide({required this.visual, required this.title, required this.body});

  final Widget visual;
  final String title;
  final String body;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return LayoutBuilder(
      builder: (context, constraints) => SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.maxHeight),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              visual.animate().fadeIn(duration: AppMotion.slow).scale(
                    begin: const Offset(0.9, 0.9),
                    end: const Offset(1, 1),
                    duration: AppMotion.slow,
                    curve: AppMotion.ease,
                  ),
              const SizedBox(height: AppSpacing.xxxl),
              Text(title, style: text.headlineMedium, textAlign: TextAlign.center)
                  .animate(delay: 80.ms)
                  .fadeIn(duration: AppMotion.slow)
                  .slideY(begin: 0.2, end: 0, curve: AppMotion.ease),
              const SizedBox(height: AppSpacing.md),
              Text(
                body,
                style: text.bodyLarge?.copyWith(color: context.palette.muted, height: 1.45),
                textAlign: TextAlign.center,
              ).animate(delay: 140.ms).fadeIn(duration: AppMotion.slow),
            ],
          ),
        ),
      ),
    );
  }
}

class _PermissionsSlide extends StatelessWidget {
  const _PermissionsSlide({
    required this.locationGranted,
    required this.cameraGranted,
    required this.requesting,
    required this.onRequest,
  });

  final bool locationGranted;
  final bool cameraGranted;
  final bool requesting;
  final VoidCallback onRequest;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final allGranted = locationGranted && cameraGranted;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Icon(Icons.verified_user_rounded, size: 56, color: p.network)
              .animate()
              .fadeIn(duration: AppMotion.slow)
              .scale(begin: const Offset(0.8, 0.8), end: const Offset(1, 1), curve: AppMotion.ease),
          const SizedBox(height: AppSpacing.lg),
          Text(l.t('onb3_title'), style: text.headlineMedium, textAlign: TextAlign.center),
          const SizedBox(height: AppSpacing.sm),
          Text(
            l.t('onb3_body'),
            style: text.bodyMedium?.copyWith(color: p.muted, height: 1.4),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: AppSpacing.xxl),
          _PermissionRow(
            icon: Icons.wifi_rounded,
            title: l.t('perm_network_title'),
            subtitle: l.t('perm_network_desc'),
            granted: true,
            grantedLabel: l.t('perm_auto'),
          ),
          const SizedBox(height: AppSpacing.sm),
          _PermissionRow(
            icon: Icons.location_on_rounded,
            title: l.t('perm_location_title'),
            subtitle: l.t('perm_location_desc'),
            granted: locationGranted,
            grantedLabel: l.t('perm_granted'),
          ),
          const SizedBox(height: AppSpacing.sm),
          _PermissionRow(
            icon: Icons.photo_camera_rounded,
            title: l.t('perm_camera_title'),
            subtitle: l.t('perm_camera_desc'),
            granted: cameraGranted,
            grantedLabel: l.t('perm_granted'),
          ),
          const SizedBox(height: AppSpacing.xl),
          if (!allGranted)
            OutlinedButton.icon(
              onPressed: requesting ? null : onRequest,
              icon: requesting
                  ? const SizedBox.square(
                      dimension: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.lock_open_rounded),
              label: Text(l.t('perm_allow')),
            ),
          const SizedBox(height: AppSpacing.sm),
          Text(
            l.t('perm_optional_note'),
            style: text.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _PermissionRow extends StatelessWidget {
  const _PermissionRow({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.granted,
    required this.grantedLabel,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool granted;
  final String grantedLabel;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final l = context.l10n;
    return GlassCard(
      padding: const EdgeInsets.all(AppSpacing.md),
      semanticLabel: '$title. ${granted ? grantedLabel : l.t('perm_pending')}',
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: p.network.faded(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: p.network),
          ),
          const SizedBox(width: AppSpacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: text.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(subtitle, style: text.bodySmall),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          AnimatedSwitcher(
            duration: AppMotion.base,
            child: granted
                ? Icon(Icons.check_circle_rounded, key: const ValueKey('ok'), color: p.success)
                : Icon(Icons.radio_button_unchecked_rounded, key: const ValueKey('ko'), color: p.muted),
          ),
        ],
      ),
    );
  }
}

/// Sélecteur de langue accessible dès le premier écran.
class _LanguageButton extends ConsumerWidget {
  const _LanguageButton();

  static const Map<String, String> _names = {
    'fr': 'Français',
    'en': 'English',
    'ar': 'العربية',
    'es': 'Español',
  };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final current = l.languageCode;
    return PopupMenuButton<String>(
      tooltip: l.t('language'),
      initialValue: current,
      onSelected: (code) => ref.read(localeProvider.notifier).setLanguage(code),
      itemBuilder: (context) => [
        for (final entry in _names.entries)
          PopupMenuItem<String>(value: entry.key, child: Text(entry.value)),
      ],
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.translate_rounded, size: 20, color: context.palette.muted),
            const SizedBox(width: 6),
            Text(_names[current] ?? 'Français', style: Theme.of(context).textTheme.labelLarge),
          ],
        ),
      ),
    );
  }
}
