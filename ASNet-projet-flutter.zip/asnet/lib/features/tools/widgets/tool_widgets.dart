// Briques communes aux pages d'outils : squelette de page, saisie d'hôte, lignes clé/valeur,
// mini-graphique de latence.
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/providers/app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/utils/feedback.dart';
import '../../../shared/widgets/glass_card.dart';

/// Page plein écran d'un outil (bouton retour, fond liquide, contenu défilant).
class ToolPage extends StatelessWidget {
  const ToolPage({super.key, required this.title, required this.icon, required this.children, this.actions});

  final String title;
  final IconData icon;
  final List<Widget> children;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Scaffold(
      backgroundColor: p.background,
      appBar: AppBar(
        backgroundColor: p.background,
        title: Row(
          children: [
            Icon(icon, color: p.network, size: 22),
            const SizedBox(width: AppSpacing.sm),
            Flexible(child: Text(title, overflow: TextOverflow.ellipsis)),
          ],
        ),
        actions: actions,
      ),
      body: LiquidBackground(
        child: SafeArea(
          top: false,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            children: children,
          ),
        ),
      ),
    );
  }
}

/// Champ "hôte / IP / domaine" + bouton Lancer/Arrêter.
class HostInput extends StatelessWidget {
  const HostInput({
    super.key,
    required this.controller,
    required this.label,
    required this.running,
    required this.onRun,
    this.onStop,
    this.hint,
    this.runLabel,
    this.extra,
    this.keyboardType = TextInputType.url,
  });

  final TextEditingController controller;
  final String label;
  final String? hint;
  final bool running;
  final VoidCallback onRun;
  final VoidCallback? onStop;
  final String? runLabel;
  final Widget? extra;
  final TextInputType keyboardType;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    return GlassCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextField(
            controller: controller,
            enabled: !running,
            autocorrect: false,
            enableSuggestions: false,
            keyboardType: keyboardType,
            textInputAction: TextInputAction.go,
            onSubmitted: (_) {
              if (!running) onRun();
            },
            style: AppTypography.mono(size: 16, color: context.palette.text),
            decoration: InputDecoration(
              labelText: label,
              hintText: hint,
              prefixIcon: const Icon(Icons.language_rounded),
            ),
          ),
          if (extra != null) ...[
            const SizedBox(height: AppSpacing.md),
            extra!,
          ],
          const SizedBox(height: AppSpacing.md),
          running
              ? OutlinedButton.icon(
                  onPressed: onStop,
                  icon: const Icon(Icons.stop_rounded),
                  label: Text(l.t('stop')),
                )
              : FilledButton.icon(
                  onPressed: onRun,
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: Text(runLabel ?? l.t('run')),
                ),
        ],
      ),
    );
  }
}

/// Ligne "libellé : valeur" (valeur sélectionnable, copiable par appui long).
class KeyValueRow extends StatelessWidget {
  const KeyValueRow(this.label, this.value, {super.key, this.mono = true, this.valueColor});

  final String label;
  final String value;
  final bool mono;
  final Color? valueColor;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    return InkWell(
      onLongPress: () async {
        try {
          await Clipboard.setData(ClipboardData(text: value));
          if (context.mounted) showAppSnack(context, context.l10n.t('copied'), kind: FeedbackKind.success);
        } catch (_) {}
      },
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 7),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 128,
              child: Text(label, style: text.bodyMedium?.copyWith(color: p.muted)),
            ),
            Expanded(
              child: Text(
                value,
                style: mono
                    ? AppTypography.mono(size: 14, color: valueColor ?? p.text)
                    : text.bodyMedium?.copyWith(color: valueColor ?? p.text),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Bloc de résultats titré.
class ResultCard extends StatelessWidget {
  const ResultCard({super.key, required this.title, required this.child, this.trailing, this.accent});

  final String title;
  final Widget child;
  final Widget? trailing;
  final Color? accent;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.only(top: AppSpacing.md),
      child: GlassCard(
        blur: false,
        accent: accent,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(child: Text(title, style: text.titleMedium)),
                if (trailing != null) trailing!,
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            child,
          ],
        ),
      ),
    );
  }
}

/// Grand chiffre + unité + libellé (statistiques).
class StatBox extends StatelessWidget {
  const StatBox({super.key, required this.label, required this.value, this.unit, this.color});

  final String label;
  final String value;
  final String? unit;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.labelSmall?.copyWith(color: p.muted)),
        const SizedBox(height: 2),
        Row(
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            Flexible(
              child: Text(
                value,
                style: AppTypography.mono(size: 22, weight: FontWeight.w800, color: color ?? p.text),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            if (unit != null) ...[
              const SizedBox(width: 3),
              Text(unit!, style: AppTypography.mono(size: 12, color: p.muted)),
            ],
          ],
        ),
      ],
    );
  }
}

/// Mini graphique (latences) ; les valeurs null sont des pertes (barres rouges).
class Sparkline extends StatelessWidget {
  const Sparkline({super.key, required this.values, this.height = 90});

  final List<double?> values;
  final double height;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return SizedBox(
      height: height,
      child: CustomPaint(
        size: Size.infinite,
        painter: _SparklinePainter(values: values, line: p.network, lost: p.danger, grid: p.glassBorder),
      ),
    );
  }
}

class _SparklinePainter extends CustomPainter {
  _SparklinePainter({required this.values, required this.line, required this.lost, required this.grid});

  final List<double?> values;
  final Color line;
  final Color lost;
  final Color grid;

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()
      ..color = grid
      ..strokeWidth = 1;
    for (var i = 0; i <= 3; i++) {
      final y = size.height * i / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    if (values.isEmpty) return;
    final shown = values.length > 60 ? values.sublist(values.length - 60) : values;
    final present = shown.whereType<double>().toList();
    final maxV = present.isEmpty ? 1.0 : math.max(present.reduce(math.max) * 1.2, 1.0);
    final step = shown.length > 1 ? size.width / (shown.length - 1) : size.width;
    final path = Path();
    var started = false;
    for (var i = 0; i < shown.length; i++) {
      final v = shown[i];
      final x = i * step;
      if (v == null) {
        canvas.drawLine(Offset(x, 0), Offset(x, size.height), Paint()
          ..color = lost.faded(0.5)
          ..strokeWidth = 2);
        started = false;
        continue;
      }
      final y = size.height - (v / maxV) * size.height;
      if (!started) {
        path.moveTo(x, y);
        started = true;
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = line
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2
        ..strokeJoin = StrokeJoin.round,
    );
  }

  @override
  bool shouldRepaint(covariant _SparklinePainter old) => true;
}

/// Formatage numérique court.
String fmtNum(double? v, {int digits = 1}) => v == null ? '—' : v.toStringAsFixed(digits);

/// Raccourcis de cibles : passerelle, DNS publics, domaine de test.
class HostPresets extends ConsumerWidget {
  const HostPresets({super.key, required this.onSelected, this.includeDomains = true});

  final ValueChanged<String> onSelected;
  final bool includeDomains;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = context.l10n;
    final gateway = ref.watch(networkDetailsProvider).valueOrNull?.gateway;
    final presets = <MapEntry<String, String>>[
      if (gateway != null) MapEntry(l.t('gateway'), gateway),
      const MapEntry('Cloudflare', '1.1.1.1'),
      const MapEntry('Google DNS', '8.8.8.8'),
      if (includeDomains) const MapEntry('google.com', 'google.com'),
    ];
    return Wrap(
      spacing: AppSpacing.xs,
      runSpacing: AppSpacing.xs,
      children: [
        for (final p in presets)
          ActionChip(
            label: Text(p.key),
            onPressed: () => onSelected(p.value),
          ),
      ],
    );
  }
}
