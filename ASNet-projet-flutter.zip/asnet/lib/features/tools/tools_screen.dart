// Décision : chaque outil s'ouvre en plein écran sur le navigateur racine (sans barre d'onglets),
// via openTool() — utilisable aussi depuis la fiche appareil avec un hôte pré-rempli.
import 'package:flutter/material.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_spacing.dart';
import '../../shared/widgets/bento_grid.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/ui_parts.dart';
import 'pages/audit_page.dart';
import 'pages/dns_page.dart';
import 'pages/internet_pages.dart';
import 'pages/lan_pages.dart';
import 'pages/ping_pages.dart';
import 'pages/port_scan_page.dart';
import 'pages/speed_test_page.dart';
import 'pages/wifi_analyzer_page.dart';

enum ToolId { audit, speed, wifi, ping, traceroute, ports, dns, publicIp, whois, tls, http, wol, subnet }

class ToolInfo {
  const ToolInfo(this.id, this.icon, this.titleKey, this.descKey, this.group);

  final ToolId id;
  final IconData icon;
  final String titleKey;
  final String descKey;
  final String group;
}

const List<ToolInfo> allTools = [
  ToolInfo(ToolId.audit, Icons.security_rounded, 'tool_audit', 'tool_audit_desc', 'group_security'),
  ToolInfo(ToolId.wifi, Icons.wifi_rounded, 'tool_wifi', 'tool_wifi_desc', 'group_security'),
  ToolInfo(ToolId.speed, Icons.speed_rounded, 'tool_speed', 'tool_speed_desc', 'group_internet'),
  ToolInfo(ToolId.publicIp, Icons.public_rounded, 'tool_public_ip', 'tool_public_ip_desc', 'group_internet'),
  ToolInfo(ToolId.ping, Icons.wifi_tethering_rounded, 'tool_ping', 'tool_ping_desc', 'group_diagnostic'),
  ToolInfo(ToolId.traceroute, Icons.timeline_rounded, 'tool_traceroute', 'tool_traceroute_desc', 'group_diagnostic'),
  ToolInfo(ToolId.ports, Icons.settings_input_component_rounded, 'tool_ports', 'tool_ports_desc', 'group_diagnostic'),
  ToolInfo(ToolId.dns, Icons.dns_rounded, 'tool_dns', 'tool_dns_desc', 'group_diagnostic'),
  ToolInfo(ToolId.http, Icons.http_rounded, 'tool_http', 'tool_http_desc', 'group_web'),
  ToolInfo(ToolId.tls, Icons.verified_user_rounded, 'tool_tls', 'tool_tls_desc', 'group_web'),
  ToolInfo(ToolId.whois, Icons.assignment_ind_rounded, 'tool_whois', 'tool_whois_desc', 'group_web'),
  ToolInfo(ToolId.wol, Icons.power_settings_new_rounded, 'tool_wol', 'tool_wol_desc', 'group_lan'),
  ToolInfo(ToolId.subnet, Icons.functions_rounded, 'tool_subnet', 'tool_subnet_desc', 'group_lan'),
];

Widget _pageFor(ToolId id, String? host) {
  switch (id) {
    case ToolId.audit:
      return const AuditPage();
    case ToolId.speed:
      return const SpeedTestPage();
    case ToolId.wifi:
      return const WifiAnalyzerPage();
    case ToolId.ping:
      return PingPage(host: host);
    case ToolId.traceroute:
      return TraceroutePage(host: host);
    case ToolId.ports:
      return PortScanPage(host: host);
    case ToolId.dns:
      return DnsPage(host: host);
    case ToolId.publicIp:
      return const PublicIpPage();
    case ToolId.whois:
      return WhoisPage(host: host);
    case ToolId.tls:
      return TlsPage(host: host);
    case ToolId.http:
      return HttpHeadersPage(host: host);
    case ToolId.wol:
      return WakeOnLanPage(mac: host);
    case ToolId.subnet:
      return const SubnetCalculatorPage();
  }
}

/// Ouvre un outil en plein écran ([host] pré-remplit la cible ; pour Wake-on-LAN c'est l'adresse MAC).
Future<void> openTool(BuildContext context, ToolId id, {String? host}) {
  return Navigator.of(context, rootNavigator: true).push<void>(
    MaterialPageRoute<void>(builder: (_) => _pageFor(id, host)),
  );
}

class ToolsScreen extends StatelessWidget {
  const ToolsScreen({super.key});

  static const List<String> _groups = ['group_security', 'group_internet', 'group_diagnostic', 'group_web', 'group_lan'];

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final topInset = MediaQuery.paddingOf(context).top;
    return ListView(
      padding: AppSpacing.screen.copyWith(top: topInset + AppSpacing.lg),
      children: [
        Semantics(header: true, child: Text(l.t('tools_title'), style: text.headlineMedium)),
        const SizedBox(height: AppSpacing.xs),
        Text(l.t('tools_subtitle'), style: text.bodyMedium?.copyWith(color: p.muted)),
        for (final group in _groups) ...[
          SectionTitle(l.t(group)),
          BentoGrid(
            tiles: [
              for (final tool in allTools.where((t) => t.group == group))
                BentoTile(height: 138, child: _ToolTile(tool: tool)),
            ],
          ),
        ],
      ],
    );
  }
}

class _ToolTile extends StatelessWidget {
  const _ToolTile({required this.tool});

  final ToolInfo tool;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final accent = tool.group == 'group_security' ? p.share : p.network;
    return GlassCard(
      accent: accent,
      padding: const EdgeInsets.all(AppSpacing.md),
      onTap: () => openTool(context, tool.id),
      semanticLabel: '${l.t(tool.titleKey)}. ${l.t(tool.descKey)}',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: accent.faded(0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(tool.icon, color: accent, size: 22),
          ),
          const Spacer(),
          Text(l.t(tool.titleKey), style: text.titleSmall?.copyWith(fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 2),
          Text(l.t(tool.descKey), style: text.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
        ],
      ),
    );
  }
}
