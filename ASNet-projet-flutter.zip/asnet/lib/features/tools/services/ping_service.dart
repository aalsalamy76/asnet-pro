// Décision : ping et traceroute s'appuient sur le binaire système /system/bin/ping (utilisable sans
// root). Repli automatique sur un "ping TCP" (temps de connexion au port 443/80) s'il est absent.
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

String _pingBinary() {
  const candidates = ['/system/bin/ping', '/system/xbin/ping', '/bin/ping', '/usr/bin/ping', '/sbin/ping'];
  for (final path in candidates) {
    try {
      if (File(path).existsSync()) return path;
    } catch (_) {}
  }
  return 'ping';
}

/// Résout un nom d'hôte en IPv4 (renvoie l'entrée telle quelle si c'est déjà une IP).
Future<String> resolveHost(String host) async {
  final trimmed = host.trim();
  if (InternetAddress.tryParse(trimmed) != null) return trimmed;
  final results = await InternetAddress.lookup(trimmed, type: InternetAddressType.IPv4)
      .timeout(const Duration(seconds: 5));
  if (results.isEmpty) throw const SocketException('DNS');
  return results.first.address;
}

/// Nettoie une saisie utilisateur : "https://exemple.fr/page" -> "exemple.fr".
String cleanHostInput(String input) {
  var s = input.trim();
  final scheme = s.indexOf('://');
  if (scheme >= 0) s = s.substring(scheme + 3);
  final slash = s.indexOf('/');
  if (slash >= 0) s = s.substring(0, slash);
  if (s.contains(':') && InternetAddress.tryParse(s) == null) s = s.substring(0, s.indexOf(':'));
  return s;
}

class PingReply {
  const PingReply({required this.seq, this.timeMs, this.ttl, this.lost = false, this.message});

  final int seq;
  final double? timeMs;
  final int? ttl;
  final bool lost;
  final String? message;
}

class PingStats {
  PingStats();

  int sent = 0;
  int received = 0;
  final List<double> times = [];

  double get lossPercent => sent == 0 ? 0 : (sent - received) * 100 / sent;
  double? get min => times.isEmpty ? null : times.reduce(math.min);
  double? get max => times.isEmpty ? null : times.reduce(math.max);
  double? get avg => times.isEmpty ? null : times.reduce((a, b) => a + b) / times.length;

  double? get jitter {
    if (times.length < 2) return null;
    var sum = 0.0;
    for (var i = 1; i < times.length; i++) {
      sum += (times[i] - times[i - 1]).abs();
    }
    return sum / (times.length - 1);
  }

  void add(PingReply reply) {
    sent++;
    final t = reply.timeMs;
    if (!reply.lost && t != null) {
      received++;
      times.add(t);
    }
  }
}

/// Session de ping continue ; [stop] tue le processus.
class PingSession {
  Process? _process;
  Timer? _timer;
  StreamController<PingReply>? _controller;
  bool _tcpMode = false;

  bool get usesTcpFallback => _tcpMode;

  Stream<PingReply> start(String host, {int count = 0, Duration interval = const Duration(seconds: 1)}) {
    final controller = StreamController<PingReply>();
    _controller = controller;
    _run(host, count, interval, controller);
    return controller.stream;
  }

  Future<void> _run(String host, int count, Duration interval, StreamController<PingReply> c) async {
    String ip;
    try {
      ip = await resolveHost(host);
    } catch (_) {
      if (!c.isClosed) {
        c.addError('dns');
        await c.close();
      }
      return;
    }
    final total = count <= 0 ? 100000 : count;
    try {
      final process = await Process.start(_pingBinary(), ['-c', '$total', '-i', '1', '-W', '2', ip]);
      _process = process;
      var lastSeq = 0;
      process.stdout.transform(utf8.decoder).transform(const LineSplitter()).listen((line) {
        final reply = RegExp(r'icmp_seq=(\d+).*?ttl=(\d+).*?time[=<]([\d.]+)').firstMatch(line);
        if (reply != null) {
          final seq = int.parse(reply.group(1)!);
          for (var missing = lastSeq + 1; missing < seq; missing++) {
            if (!c.isClosed) c.add(PingReply(seq: missing, lost: true));
          }
          lastSeq = seq;
          if (!c.isClosed) {
            c.add(PingReply(
              seq: seq,
              ttl: int.tryParse(reply.group(2)!),
              timeMs: double.tryParse(reply.group(3)!),
            ));
          }
          return;
        }
        final error = RegExp(r'icmp_seq=(\d+)\s+(.*)').firstMatch(line);
        if (error != null && line.toLowerCase().startsWith('from')) {
          final seq = int.parse(error.group(1)!);
          lastSeq = math.max(lastSeq, seq);
          if (!c.isClosed) c.add(PingReply(seq: seq, lost: true, message: error.group(2)));
        }
      });
      await process.exitCode;
    } on ProcessException {
      _tcpMode = true;
      await _runTcp(ip, total, interval, c);
    } catch (_) {}
    if (!c.isClosed) await c.close();
  }

  Future<void> _runTcp(String ip, int total, Duration interval, StreamController<PingReply> c) async {
    for (var seq = 1; seq <= total && !c.isClosed; seq++) {
      final watch = Stopwatch()..start();
      var ok = false;
      for (final port in const [443, 80]) {
        try {
          final socket = await Socket.connect(ip, port, timeout: const Duration(seconds: 2));
          socket.destroy();
          ok = true;
          break;
        } on SocketException catch (e) {
          final code = e.osError?.errorCode;
          if (code == 111 || code == 61) {
            ok = true;
            break;
          }
        } catch (_) {}
      }
      watch.stop();
      if (!c.isClosed) {
        c.add(ok
            ? PingReply(seq: seq, timeMs: watch.elapsedMicroseconds / 1000)
            : PingReply(seq: seq, lost: true));
      }
      final wait = interval - watch.elapsed;
      if (wait > Duration.zero) await Future<void>.delayed(wait);
    }
  }

  void stop() {
    _process?.kill();
    _process = null;
    _timer?.cancel();
    final c = _controller;
    if (c != null && !c.isClosed) c.close();
  }
}

// ───────────────────────────── Traceroute ─────────────────────────────

class TraceHop {
  const TraceHop({required this.ttl, this.ip, this.hostname, this.timeMs, this.reached = false});

  final int ttl;
  final String? ip;
  final String? hostname;
  final double? timeMs;
  final bool reached;
}

/// Traceroute ICMP par TTL croissant (ping -t). Émet chaque saut dès qu'il est connu.
Stream<TraceHop> traceroute(String host, {int maxHops = 30, bool Function()? isCancelled}) async* {
  final target = await resolveHost(host);
  final binary = _pingBinary();
  for (var ttl = 1; ttl <= maxHops; ttl++) {
    if (isCancelled?.call() ?? false) return;
    final watch = Stopwatch()..start();
    ProcessResult result;
    try {
      result = await Process.run(binary, ['-c', '1', '-W', '2', '-t', '$ttl', target])
          .timeout(const Duration(seconds: 4));
    } catch (_) {
      yield TraceHop(ttl: ttl);
      continue;
    }
    watch.stop();
    final out = '${result.stdout}\n${result.stderr}';
    final reachedMatch = RegExp(r'bytes from ([\d.]+).*?time[=<]([\d.]+)').firstMatch(out);
    if (reachedMatch != null) {
      final ip = reachedMatch.group(1)!;
      yield TraceHop(
        ttl: ttl,
        ip: ip,
        hostname: await _reverse(ip),
        timeMs: double.tryParse(reachedMatch.group(2)!),
        reached: true,
      );
      return;
    }
    final hopMatch = RegExp(r'[Ff]rom ([\d.]+)').firstMatch(out);
    if (hopMatch != null) {
      final ip = hopMatch.group(1)!;
      yield TraceHop(
        ttl: ttl,
        ip: ip,
        hostname: await _reverse(ip),
        timeMs: watch.elapsedMicroseconds / 1000,
        reached: ip == target,
      );
      if (ip == target) return;
    } else {
      yield TraceHop(ttl: ttl);
    }
  }
}

Future<String?> _reverse(String ip) async {
  try {
    final address = InternetAddress.tryParse(ip);
    if (address == null) return null;
    final r = await address.reverse().timeout(const Duration(milliseconds: 1200));
    return r.host == ip ? null : r.host;
  } catch (_) {
    return null;
  }
}
