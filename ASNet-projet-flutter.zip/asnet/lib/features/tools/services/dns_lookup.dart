import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import '../../../core/network/dns_codec.dart';

class DnsLookupResult {
  const DnsLookupResult({
    required this.server,
    required this.query,
    required this.type,
    required this.rcode,
    required this.records,
    required this.elapsedMs,
  });

  final String server;
  final String query;
  final String type;
  final String rcode;
  final List<DnsRecord> records;
  final int elapsedMs;
}

class DnsLookup {
  const DnsLookup();

  static const Map<String, String> resolvers = {
    'Google': '8.8.8.8',
    'Cloudflare': '1.1.1.1',
    'Quad9': '9.9.9.9',
    'OpenDNS': '208.67.222.222',
  };

  /// Requête DNS UDP brute vers [server] (port 53).
  Future<DnsLookupResult> query(String name, String type, {required String server}) async {
    var qname = name.trim();
    if (qname.endsWith('.')) qname = qname.substring(0, qname.length - 1);
    final typeCode = DnsCodec.types[type] ?? DnsCodec.typeA;
    if (typeCode == DnsCodec.typePTR && InternetAddress.tryParse(qname)?.type == InternetAddressType.IPv4) {
      qname = DnsCodec.reverseName(qname);
    }
    final id = math.Random().nextInt(0xFFFF);
    final packet = DnsCodec.buildQuery(id, [DnsQuestion(qname, typeCode)]);
    final address = InternetAddress(server);
    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    final completer = Completer<DnsMessage>();
    final watch = Stopwatch()..start();
    final sub = socket.listen((event) {
      if (event != RawSocketEvent.read) return;
      final datagram = socket.receive();
      if (datagram == null) return;
      final message = DnsCodec.parse(datagram.data);
      if (message != null && message.id == id && !completer.isCompleted) completer.complete(message);
    });
    Timer? retry;
    try {
      socket.send(packet, address, 53);
      // Une relance après 1,5 s (UDP peut perdre le paquet).
      retry = Timer(const Duration(milliseconds: 1500), () {
        if (!completer.isCompleted) {
          try {
            socket.send(packet, address, 53);
          } catch (_) {}
        }
      });
      final message = await completer.future.timeout(const Duration(seconds: 4));
      watch.stop();
      return DnsLookupResult(
        server: server,
        query: qname,
        type: type,
        rcode: message.rcodeName,
        records: [...message.answers, ...message.authorities],
        elapsedMs: watch.elapsedMilliseconds,
      );
    } finally {
      retry?.cancel();
      await sub.cancel();
      socket.close();
    }
  }
}
