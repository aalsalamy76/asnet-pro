// Décision : test de débit sur l'infrastructure publique de Cloudflare (speed.cloudflare.com),
// sans clé ni compte : latence/gigue (10 requêtes vides), descendant (4 flux, 8 s), montant (3 flux, 8 s).
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

enum SpeedPhase { latency, download, upload, done }

class SpeedProgress {
  const SpeedProgress({
    required this.phase,
    this.pingMs,
    this.jitterMs,
    this.downloadMbps,
    this.uploadMbps,
    this.currentMbps,
    this.phaseProgress = 0,
  });

  final SpeedPhase phase;
  final double? pingMs;
  final double? jitterMs;
  final double? downloadMbps;
  final double? uploadMbps;

  /// Débit instantané de la phase en cours.
  final double? currentMbps;

  /// Avancement de la phase en cours (0..1).
  final double phaseProgress;
}

class SpeedTest {
  SpeedTest();

  static const String _base = 'https://speed.cloudflare.com';
  static const Duration phaseDuration = Duration(seconds: 8);

  bool _cancelled = false;
  HttpClient? _client;

  void cancel() {
    _cancelled = true;
    _client?.close(force: true);
  }

  HttpClient _newClient() {
    final c = HttpClient()
      ..connectionTimeout = const Duration(seconds: 6)
      ..userAgent = 'A.SNet/0.2 (Android)'
      ..maxConnectionsPerHost = 8;
    _client = c;
    return c;
  }

  Stream<SpeedProgress> run() async* {
    _cancelled = false;

    // 1. Latence + gigue.
    final latencies = <double>[];
    var client = _newClient();
    for (var i = 0; i < 10 && !_cancelled; i++) {
      final watch = Stopwatch()..start();
      try {
        final req = await client.getUrl(Uri.parse('$_base/__down?bytes=0'));
        final res = await req.close().timeout(const Duration(seconds: 5));
        await res.drain<void>();
        watch.stop();
        latencies.add(watch.elapsedMicroseconds / 1000);
      } catch (_) {}
      yield SpeedProgress(phase: SpeedPhase.latency, phaseProgress: (i + 1) / 10);
    }
    client.close(force: true);
    if (latencies.isEmpty) throw const SocketException('speedtest');
    final sorted = [...latencies]..sort();
    final ping = sorted[sorted.length ~/ 2];
    var jitter = 0.0;
    for (var i = 1; i < latencies.length; i++) {
      jitter += (latencies[i] - latencies[i - 1]).abs();
    }
    jitter = latencies.length > 1 ? jitter / (latencies.length - 1) : 0;
    yield SpeedProgress(phase: SpeedPhase.download, pingMs: ping, jitterMs: jitter);
    if (_cancelled) return;

    // 2. Débit descendant.
    client = _newClient();
    var downBytes = 0;
    var stopDown = false;
    final downWatch = Stopwatch()..start();
    Future<void> downloader() async {
      while (!stopDown && !_cancelled) {
        try {
          final req = await client.getUrl(Uri.parse('$_base/__down?bytes=25000000'));
          final res = await req.close();
          await for (final chunk in res) {
            downBytes += chunk.length;
            if (stopDown || _cancelled) break;
          }
        } catch (_) {
          if (stopDown || _cancelled) return;
          await Future<void>.delayed(const Duration(milliseconds: 200));
        }
      }
    }

    final downloaders = List.generate(4, (_) => downloader());
    var lastBytes = 0;
    var lastTime = 0;
    var download = 0.0;
    while (downWatch.elapsed < phaseDuration && !_cancelled) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      final nowMs = downWatch.elapsedMilliseconds;
      final current = _mbps(downBytes - lastBytes, nowMs - lastTime);
      lastBytes = downBytes;
      lastTime = nowMs;
      download = _mbps(downBytes, nowMs);
      yield SpeedProgress(
        phase: SpeedPhase.download,
        pingMs: ping,
        jitterMs: jitter,
        currentMbps: current,
        downloadMbps: download,
        phaseProgress: math.min(1.0, nowMs / phaseDuration.inMilliseconds),
      );
    }
    stopDown = true;
    client.close(force: true);
    await Future.wait(downloaders).timeout(const Duration(seconds: 3), onTimeout: () => <void>[]);
    if (_cancelled) return;
    yield SpeedProgress(phase: SpeedPhase.upload, pingMs: ping, jitterMs: jitter, downloadMbps: download);

    // 3. Débit montant.
    client = _newClient();
    var upBytes = 0;
    var stopUp = false;
    final upWatch = Stopwatch()..start();
    final payload = Uint8List(64 * 1024);
    Stream<List<int>> body(int total) async* {
      var sent = 0;
      while (sent < total && !stopUp && !_cancelled) {
        yield payload;
        sent += payload.length;
        upBytes += payload.length;
      }
    }

    Future<void> uploader() async {
      while (!stopUp && !_cancelled) {
        try {
          const size = 8 * 1024 * 1024;
          final req = await client.postUrl(Uri.parse('$_base/__up'));
          req.headers.contentType = ContentType.binary;
          req.contentLength = size;
          await req.addStream(body(size));
          final res = await req.close();
          await res.drain<void>();
        } catch (_) {
          if (stopUp || _cancelled) return;
          await Future<void>.delayed(const Duration(milliseconds: 200));
        }
      }
    }

    final uploaders = List.generate(3, (_) => uploader());
    lastBytes = 0;
    lastTime = 0;
    var upload = 0.0;
    while (upWatch.elapsed < phaseDuration && !_cancelled) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      final nowMs = upWatch.elapsedMilliseconds;
      final current = _mbps(upBytes - lastBytes, nowMs - lastTime);
      lastBytes = upBytes;
      lastTime = nowMs;
      upload = _mbps(upBytes, nowMs);
      yield SpeedProgress(
        phase: SpeedPhase.upload,
        pingMs: ping,
        jitterMs: jitter,
        downloadMbps: download,
        currentMbps: current,
        uploadMbps: upload,
        phaseProgress: math.min(1.0, nowMs / phaseDuration.inMilliseconds),
      );
    }
    stopUp = true;
    client.close(force: true);
    await Future.wait(uploaders).timeout(const Duration(seconds: 3), onTimeout: () => <void>[]);
    yield SpeedProgress(
      phase: SpeedPhase.done,
      pingMs: ping,
      jitterMs: jitter,
      downloadMbps: download,
      uploadMbps: upload,
      phaseProgress: 1,
    );
  }

  static double _mbps(int bytes, int ms) => ms <= 0 ? 0 : bytes * 8 / (ms / 1000) / 1000000;
}
