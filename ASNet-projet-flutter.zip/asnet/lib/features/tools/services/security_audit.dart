// Décision : audit 100 % local, en lecture seule (aucune tentative de connexion avec mot de passe) :
// chiffrement Wi-Fi, ports dangereux sur la box et les appareils, UPnP exposé, détournement DNS,
// appareils inconnus. Note = 100 - pénalités (critique 30, élevé 15, moyen 8, faible 3).
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import '../../../core/network/native_wifi.dart';
import '../../../core/network/ports_catalog.dart';
import '../../scan/models/device.dart';
import '../../scan/models/network_info.dart';
import '../../scan/services/discovery_services.dart';
import 'port_scanner.dart';

enum Severity { critical, high, medium, low, pass }

class AuditFinding {
  const AuditFinding({
    required this.severity,
    required this.key,
    this.args = const {},
    this.host,
  });

  final Severity severity;

  /// Préfixe de traduction : "<key>_title" et "<key>_body".
  final String key;
  final Map<String, Object?> args;
  final String? host;
}

class AuditReport {
  const AuditReport({required this.score, required this.findings, required this.at, required this.devicesChecked});

  final int score;
  final List<AuditFinding> findings;
  final DateTime at;
  final int devicesChecked;

  int count(Severity s) => findings.where((f) => f.severity == s).length;
  List<AuditFinding> get issues => findings.where((f) => f.severity != Severity.pass).toList();
  List<AuditFinding> get passed => findings.where((f) => f.severity == Severity.pass).toList();
}

class SecurityAuditor {
  const SecurityAuditor();

  static int penalty(Severity s) {
    switch (s) {
      case Severity.critical:
        return 30;
      case Severity.high:
        return 15;
      case Severity.medium:
        return 8;
      case Severity.low:
        return 3;
      case Severity.pass:
        return 0;
    }
  }

  Future<AuditReport> run({
    required NetworkDetails network,
    required List<Device> devices,
    void Function(double progress, String stepKey)? onProgress,
  }) async {
    final findings = <AuditFinding>[];
    const scanner = PortScanner();

    // 1. Chiffrement Wi-Fi.
    onProgress?.call(0.05, 'audit_step_wifi');
    switch (network.security) {
      case WifiSecurity.open:
        findings.add(const AuditFinding(severity: Severity.critical, key: 'f_wifi_open'));
        break;
      case WifiSecurity.wep:
        findings.add(const AuditFinding(severity: Severity.critical, key: 'f_wifi_wep'));
        break;
      case WifiSecurity.wpa:
        findings.add(const AuditFinding(severity: Severity.high, key: 'f_wifi_wpa'));
        break;
      case WifiSecurity.wpa2:
      case WifiSecurity.wpa2Enterprise:
        findings.add(const AuditFinding(severity: Severity.low, key: 'f_wifi_wpa2'));
        break;
      case WifiSecurity.wpa3:
      case WifiSecurity.wpa3Enterprise:
        findings.add(const AuditFinding(severity: Severity.pass, key: 'f_wifi_wpa3'));
        break;
      case WifiSecurity.owe:
      case WifiSecurity.wapi:
      case WifiSecurity.unknown:
        break;
    }

    // 2. Signal Wi-Fi (qualité de la liaison).
    final link = await NativeWifi.linkInfo();
    if (link != null && link.rssi < -75) {
      findings.add(AuditFinding(severity: Severity.low, key: 'f_weak_signal', args: {'rssi': link.rssi}));
    }

    // 3. Passerelle : ports d'administration exposés.
    final gateway = network.gateway;
    if (gateway != null) {
      onProgress?.call(0.15, 'audit_step_router');
      final open = await scanner.quickOpenPorts(gateway, PortsCatalog.gatewayAudit);
      if (open.contains(23)) {
        findings.add(AuditFinding(severity: Severity.critical, key: 'f_router_telnet', host: gateway));
      }
      if (open.contains(21)) {
        findings.add(AuditFinding(severity: Severity.high, key: 'f_router_ftp', host: gateway));
      }
      if (open.contains(445)) {
        findings.add(AuditFinding(severity: Severity.medium, key: 'f_router_smb', host: gateway));
      }
      if (open.contains(7547)) {
        findings.add(AuditFinding(severity: Severity.medium, key: 'f_router_tr069', host: gateway));
      }
      if (open.contains(8291)) {
        findings.add(AuditFinding(severity: Severity.medium, key: 'f_router_winbox', host: gateway));
      }
      if (open.contains(80) && !open.contains(443) && !open.contains(8443)) {
        findings.add(AuditFinding(severity: Severity.medium, key: 'f_router_http', host: gateway));
      }
      if (!open.contains(23) && !open.contains(21)) {
        findings.add(AuditFinding(severity: Severity.pass, key: 'f_router_ports_ok', host: gateway));
      }

      // 4. UPnP IGD (ouverture automatique de ports).
      onProgress?.call(0.30, 'audit_step_upnp');
      final upnp = await const SsdpDiscovery().discover(timeout: const Duration(seconds: 2));
      final gatewayUpnp = upnp[gateway];
      if (gatewayUpnp != null && gatewayUpnp.isInternetGateway) {
        findings.add(AuditFinding(severity: Severity.medium, key: 'f_upnp', host: gateway));
      } else {
        findings.add(const AuditFinding(severity: Severity.pass, key: 'f_upnp_ok'));
      }
    }

    // 5. Appareils : services dangereux ouverts.
    final targets = devices.where((d) => !d.isSelf && d.ip != gateway).take(64).toList();
    var checked = 0;
    var riskyFound = false;
    for (var i = 0; i < targets.length; i += 8) {
      final batch = targets.sublist(i, math.min(i + 8, targets.length));
      await Future.wait(batch.map((device) async {
        final open = await scanner.quickOpenPorts(device.ip, PortsCatalog.riskyDevice, timeout: const Duration(milliseconds: 600));
        for (final port in open) {
          riskyFound = true;
          findings.add(AuditFinding(
            severity: _portSeverity(port),
            key: 'f_port',
            host: device.ip,
            args: {'port': port, 'service': PortsCatalog.nameOf(port), 'device': device.displayName},
          ));
        }
      }));
      checked += batch.length;
      onProgress?.call(0.35 + 0.45 * (checked / math.max(targets.length, 1)), 'audit_step_devices');
    }
    if (!riskyFound) {
      findings.add(AuditFinding(severity: Severity.pass, key: 'f_ports_ok', args: {'count': targets.length}));
    }

    // 6. Détournement DNS : un domaine inexistant ne doit PAS résoudre.
    onProgress?.call(0.85, 'audit_step_dns');
    final probe = 'asnet-${DateTime.now().millisecondsSinceEpoch}-${math.Random().nextInt(99999)}.example';
    var hijacked = false;
    try {
      final r = await InternetAddress.lookup(probe).timeout(const Duration(seconds: 4));
      hijacked = r.isNotEmpty;
    } catch (_) {
      hijacked = false;
    }
    findings.add(hijacked
        ? const AuditFinding(severity: Severity.medium, key: 'f_dns_hijack')
        : const AuditFinding(severity: Severity.pass, key: 'f_dns_ok'));

    // 7. Appareils inconnus.
    final unknown = devices.where((d) => d.isNew && !d.trusted).length;
    if (unknown > 0) {
      findings.add(AuditFinding(severity: Severity.low, key: 'f_new_devices', args: {'count': unknown}));
    }

    onProgress?.call(1, 'audit_step_done');
    var score = 100;
    for (final f in findings) {
      score -= penalty(f.severity);
    }
    findings.sort((a, b) => a.severity.index.compareTo(b.severity.index));
    return AuditReport(
      score: score.clamp(0, 100).toInt(),
      findings: findings,
      at: DateTime.now(),
      devicesChecked: targets.length,
    );
  }

  static Severity _portSeverity(int port) {
    switch (port) {
      case 23:
      case 5555:
      case 2375:
        return Severity.critical;
      case 6379:
      case 9200:
      case 11211:
      case 27017:
        return Severity.high;
      case 21:
      case 445:
      case 3389:
      case 5900:
      case 1883:
        return Severity.medium;
      default:
        return Severity.low;
    }
  }
}
