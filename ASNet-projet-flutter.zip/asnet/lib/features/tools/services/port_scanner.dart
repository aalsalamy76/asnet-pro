// Décision : scan TCP "connect" (aucun privilège requis), 128 connexions simultanées, timeout 600 ms ;
// lecture de bannière (SSH/FTP/SMTP…) et en-tête "Server" HTTP sur les ports ouverts.
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import '../../../core/network/ports_catalog.dart';
import 'ping_service.dart';

class OpenPort {
  const OpenPort({required this.port, required this.latencyMs, this.banner});

  final int port;
  final double latencyMs;
  final String? banner;

  String get service => PortsCatalog.nameOf(port);
}

class PortScanner {
  const PortScanner();

  Future<List<OpenPort>> scan(
    String host,
    List<int> ports, {
    int concurrency = 128,
    Duration timeout = const Duration(milliseconds: 600),
    bool grabBanners = true,
    void Function(int done, int total)? onProgress,
    void Function(OpenPort port)? onOpen,
    bool Function()? isCancelled,
  }) async {
    final ip = await resolveHost(cleanHostInput(host));
    final open = <OpenPort>[];
    var cursor = 0;
    var done = 0;

    Future<void> worker() async {
      while (cursor < ports.length && !(isCancelled?.call() ?? false)) {
        final port = ports[cursor++];
        final watch = Stopwatch()..start();
        Socket? socket;
        try {
          socket = await Socket.connect(ip, port, timeout: timeout);
          watch.stop();
          String? banner;
          if (grabBanners) banner = await _banner(socket, port, ip);
          final result = OpenPort(port: port, latencyMs: watch.elapsedMicroseconds / 1000, banner: banner);
          open.add(result);
          onOpen?.call(result);
        } catch (_) {
          // fermé / filtré
        } finally {
          socket?.destroy();
        }
        done++;
        onProgress?.call(done, ports.length);
      }
    }

    await Future.wait(List.generate(math.min(concurrency, math.max(ports.length, 1)), (_) => worker()));
    open.sort((a, b) => a.port.compareTo(b.port));
    return open;
  }

  /// Ports ouverts parmi [ports], sans bannière (rapide, pour l'audit et la fiche appareil).
  Future<List<int>> quickOpenPorts(String ip, List<int> ports, {Duration timeout = const Duration(milliseconds: 700)}) async {
    final result = <int>[];
    await Future.wait(ports.map((port) async {
      try {
        final s = await Socket.connect(ip, port, timeout: timeout);
        s.destroy();
        result.add(port);
      } catch (_) {}
    }));
    result.sort();
    return result;
  }

  static Future<String?> _banner(Socket socket, int port, String ip) async {
    try {
      if (PortsCatalog.isHttp(port)) {
        socket.write('HEAD / HTTP/1.0\r\nHost: $ip\r\nUser-Agent: A.SNet\r\n\r\n');
        await socket.flush();
      }
      final data = await socket.first.timeout(const Duration(milliseconds: 900));
      final text = utf8.decode(data, allowMalformed: true);
      if (PortsCatalog.isHttp(port)) {
        final server = RegExp(r'^server:\s*(.+)$', multiLine: true, caseSensitive: false).firstMatch(text);
        final status = text.split('\n').first.trim();
        return server != null ? '${server.group(1)!.trim()} · $status' : status;
      }
      final firstLine = text.split('\n').first.trim();
      return firstLine.isEmpty ? null : (firstLine.length > 120 ? firstLine.substring(0, 120) : firstLine);
    } catch (_) {
      return null;
    }
  }
}
