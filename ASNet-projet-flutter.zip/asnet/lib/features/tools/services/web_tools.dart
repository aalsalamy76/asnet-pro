// Outils "Internet" : IP publique & FAI, Whois (port 43), certificat TLS, en-têtes/redirections HTTP.
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'ping_service.dart';

// ───────────────────────────── IP publique ─────────────────────────────

class PublicIpInfo {
  const PublicIpInfo({
    required this.ip,
    this.hostname,
    this.city,
    this.region,
    this.country,
    this.org,
    this.timezone,
    this.location,
    this.cloudflareColo,
  });

  final String ip;
  final String? hostname;
  final String? city;
  final String? region;
  final String? country;

  /// "AS3215 Orange S.A." (numéro AS + fournisseur).
  final String? org;
  final String? timezone;
  final String? location;
  final String? cloudflareColo;
}

class WebTools {
  const WebTools();

  static HttpClient _client() => HttpClient()
    ..connectionTimeout = const Duration(seconds: 6)
    ..userAgent = 'A.SNet/0.2 (Android)';

  static Future<String> _getText(HttpClient client, String url) async {
    final req = await client.getUrl(Uri.parse(url));
    final res = await req.close().timeout(const Duration(seconds: 8));
    return res.transform(utf8.decoder).join().timeout(const Duration(seconds: 8));
  }

  Future<PublicIpInfo> publicIp() async {
    final client = _client();
    try {
      Map<String, String> trace = {};
      try {
        final text = await _getText(client, 'https://www.cloudflare.com/cdn-cgi/trace');
        for (final line in const LineSplitter().convert(text)) {
          final i = line.indexOf('=');
          if (i > 0) trace[line.substring(0, i)] = line.substring(i + 1);
        }
      } catch (_) {}

      Map<String, dynamic> info = {};
      try {
        final text = await _getText(client, 'https://ipinfo.io/json');
        final decoded = jsonDecode(text);
        if (decoded is Map) info = Map<String, dynamic>.from(decoded);
      } catch (_) {}

      final ip = (info['ip'] as String?) ?? trace['ip'];
      if (ip == null) throw const SocketException('public-ip');
      return PublicIpInfo(
        ip: ip,
        hostname: info['hostname'] as String?,
        city: info['city'] as String?,
        region: info['region'] as String?,
        country: (info['country'] as String?) ?? trace['loc'],
        org: info['org'] as String?,
        timezone: info['timezone'] as String?,
        location: info['loc'] as String?,
        cloudflareColo: trace['colo'],
      );
    } finally {
      client.close(force: true);
    }
  }

  // ───────────────────────────── Whois ─────────────────────────────

  Future<String> whois(String input) async {
    final query = cleanHostInput(input);
    final first = await _whoisQuery('whois.iana.org', query);
    final refer = RegExp(r'^(?:refer|whois):\s*(\S+)', multiLine: true, caseSensitive: false).firstMatch(first);
    final server = refer?.group(1);
    if (server != null && server.toLowerCase() != 'whois.iana.org') {
      try {
        final second = await _whoisQuery(server, query);
        if (second.trim().isNotEmpty) return '# $server\n\n$second';
      } catch (_) {}
    }
    return '# whois.iana.org\n\n$first';
  }

  static Future<String> _whoisQuery(String server, String query) async {
    final socket = await Socket.connect(server, 43, timeout: const Duration(seconds: 8));
    try {
      socket.write('$query\r\n');
      await socket.flush();
      final bytes = await socket
          .fold<List<int>>(<int>[], (previous, element) => previous..addAll(element))
          .timeout(const Duration(seconds: 12));
      return utf8.decode(bytes, allowMalformed: true);
    } finally {
      socket.destroy();
    }
  }

  // ───────────────────────────── Certificat TLS ─────────────────────────────

  Future<TlsReport> tls(String input, {int port = 443}) async {
    final host = cleanHostInput(input);
    var trusted = true;
    final watch = Stopwatch()..start();
    final socket = await SecureSocket.connect(
      host,
      port,
      timeout: const Duration(seconds: 8),
      supportedProtocols: const ['h2', 'http/1.1'],
      onBadCertificate: (certificate) {
        trusted = false;
        return true;
      },
    );
    watch.stop();
    try {
      final cert = socket.peerCertificate;
      return TlsReport(
        host: host,
        port: port,
        trusted: trusted,
        subject: cert?.subject ?? '—',
        issuer: cert?.issuer ?? '—',
        validFrom: cert?.startValidity,
        validTo: cert?.endValidity,
        sha1: cert == null ? null : cert.sha1.map((b) => b.toRadixString(16).padLeft(2, '0')).join(':').toUpperCase(),
        alpn: socket.selectedProtocol,
        handshakeMs: watch.elapsedMilliseconds,
        remoteIp: socket.remoteAddress.address,
      );
    } finally {
      socket.destroy();
    }
  }

  // ───────────────────────────── En-têtes HTTP ─────────────────────────────

  Future<List<HttpHop>> httpChain(String input, {int maxRedirects = 8}) async {
    var text = input.trim();
    if (!text.contains('://')) text = 'https://$text';
    var uri = Uri.parse(text);
    final hops = <HttpHop>[];
    final client = _client();
    try {
      for (var i = 0; i <= maxRedirects; i++) {
        final watch = Stopwatch()..start();
        final req = await client.openUrl('GET', uri);
        req.followRedirects = false;
        final res = await req.close().timeout(const Duration(seconds: 10));
        watch.stop();
        final headers = <String, String>{};
        res.headers.forEach((name, values) => headers[name] = values.join(', '));
        await res.drain<void>().timeout(const Duration(seconds: 5), onTimeout: () {});
        hops.add(HttpHop(
          url: uri.toString(),
          statusCode: res.statusCode,
          reason: res.reasonPhrase,
          headers: headers,
          elapsedMs: watch.elapsedMilliseconds,
        ));
        final location = res.headers.value(HttpHeaders.locationHeader);
        if (res.isRedirect && location != null) {
          uri = uri.resolve(location);
        } else {
          break;
        }
      }
    } finally {
      client.close(force: true);
    }
    return hops;
  }
}

class TlsReport {
  const TlsReport({
    required this.host,
    required this.port,
    required this.trusted,
    required this.subject,
    required this.issuer,
    required this.handshakeMs,
    required this.remoteIp,
    this.validFrom,
    this.validTo,
    this.sha1,
    this.alpn,
  });

  final String host;
  final int port;
  final bool trusted;
  final String subject;
  final String issuer;
  final DateTime? validFrom;
  final DateTime? validTo;
  final String? sha1;
  final String? alpn;
  final int handshakeMs;
  final String remoteIp;

  int? get daysLeft => validTo?.difference(DateTime.now()).inDays;
}

class HttpHop {
  const HttpHop({
    required this.url,
    required this.statusCode,
    required this.reason,
    required this.headers,
    required this.elapsedMs,
  });

  final String url;
  final int statusCode;
  final String reason;
  final Map<String, String> headers;
  final int elapsedMs;
}
