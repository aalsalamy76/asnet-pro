// Outils LAN : Wake-on-LAN (paquet magique UDP) et calculateur IPv4 / sous-réseau.
import 'dart:io';
import 'dart:typed_data';

import '../../scan/services/oui_lookup.dart';

// ───────────────────────────── Wake-on-LAN ─────────────────────────────

class WakeOnLan {
  const WakeOnLan();

  /// Envoie le paquet magique (6 x FF + 16 x MAC) en broadcast sur les ports 9 et 7.
  /// Renvoie false si l'adresse MAC est invalide.
  Future<bool> wake(String mac, {String? subnetBroadcast}) async {
    final normalized = OuiLookup.normalizeMac(mac);
    if (normalized == null) return false;
    final macBytes = normalized.split(':').map((h) => int.parse(h, radix: 16)).toList();
    final packet = Uint8List(102);
    for (var i = 0; i < 6; i++) {
      packet[i] = 0xFF;
    }
    for (var r = 0; r < 16; r++) {
      for (var i = 0; i < 6; i++) {
        packet[6 + r * 6 + i] = macBytes[i];
      }
    }
    final socket = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    try {
      socket.broadcastEnabled = true;
      final targets = <InternetAddress>[
        InternetAddress('255.255.255.255'),
        if (subnetBroadcast != null && InternetAddress.tryParse(subnetBroadcast) != null)
          InternetAddress(subnetBroadcast),
      ];
      for (var attempt = 0; attempt < 3; attempt++) {
        for (final target in targets) {
          socket.send(packet, target, 9);
          socket.send(packet, target, 7);
        }
        await Future<void>.delayed(const Duration(milliseconds: 120));
      }
      return true;
    } finally {
      socket.close();
    }
  }
}

// ───────────────────────────── Calculateur IPv4 ─────────────────────────────

class SubnetInfo {
  const SubnetInfo({
    required this.ip,
    required this.prefix,
    required this.mask,
    required this.wildcard,
    required this.network,
    required this.broadcast,
    required this.firstHost,
    required this.lastHost,
    required this.hostCount,
    required this.ipClass,
    required this.isPrivate,
    required this.binaryMask,
  });

  final String ip;
  final int prefix;
  final String mask;
  final String wildcard;
  final String network;
  final String broadcast;
  final String firstHost;
  final String lastHost;
  final int hostCount;
  final String ipClass;
  final bool isPrivate;
  final String binaryMask;
}

class SubnetCalculator {
  const SubnetCalculator();

  static int? _toInt(String ip) {
    final parts = ip.trim().split('.');
    if (parts.length != 4) return null;
    var v = 0;
    for (final p in parts) {
      final n = int.tryParse(p);
      if (n == null || n < 0 || n > 255) return null;
      v = (v << 8) | n;
    }
    return v;
  }

  static String _toIp(int v) => '${(v >> 24) & 0xFF}.${(v >> 16) & 0xFF}.${(v >> 8) & 0xFF}.${v & 0xFF}';

  /// Accepte "192.168.1.10/24", "192.168.1.10 255.255.255.0" ou "192.168.1.10" (+ [maskOrPrefix]).
  SubnetInfo? calculate(String input, [String? maskOrPrefix]) {
    var text = input.trim();
    String? second = maskOrPrefix?.trim();
    if (text.contains('/')) {
      final parts = text.split('/');
      text = parts[0].trim();
      second = parts.length > 1 ? parts[1].trim() : second;
    } else if (text.contains(' ')) {
      final parts = text.split(RegExp(r'\s+'));
      text = parts[0];
      second = parts.length > 1 ? parts[1] : second;
    }
    final ip = _toInt(text);
    if (ip == null) return null;

    int prefix;
    if (second == null || second.isEmpty) {
      prefix = 24;
    } else if (second.contains('.')) {
      final m = _toInt(second);
      if (m == null) return null;
      var bits = 0;
      var seenZero = false;
      for (var i = 31; i >= 0; i--) {
        final bit = (m >> i) & 1;
        if (bit == 1) {
          if (seenZero) return null; // masque non contigu
          bits++;
        } else {
          seenZero = true;
        }
      }
      prefix = bits;
    } else {
      final p = int.tryParse(second.replaceAll('/', ''));
      if (p == null || p < 0 || p > 32) return null;
      prefix = p;
    }

    final mask = prefix == 0 ? 0 : (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF;
    final wildcard = (~mask) & 0xFFFFFFFF;
    final network = ip & mask;
    final broadcast = network | wildcard;
    int first;
    int last;
    int hosts;
    if (prefix >= 31) {
      first = network;
      last = broadcast;
      hosts = prefix == 32 ? 1 : 2;
    } else {
      first = network + 1;
      last = broadcast - 1;
      hosts = (wildcard + 1) - 2;
    }
    final firstOctet = (ip >> 24) & 0xFF;
    final ipClass = firstOctet < 128
        ? 'A'
        : firstOctet < 192
            ? 'B'
            : firstOctet < 224
                ? 'C'
                : firstOctet < 240
                    ? 'D (multicast)'
                    : 'E';
    final isPrivate = (ip >> 24) == 10 ||
        ((ip >> 20) & 0xFFF) == 0xAC1 ||
        ((ip >> 16) & 0xFFFF) == 0xC0A8 ||
        ((ip >> 22) & 0x3FF) == 0x191; // 100.64.0.0/10 (CGNAT)
    final binary = [
      for (var i = 3; i >= 0; i--) ((mask >> (i * 8)) & 0xFF).toRadixString(2).padLeft(8, '0'),
    ].join('.');
    return SubnetInfo(
      ip: _toIp(ip),
      prefix: prefix,
      mask: _toIp(mask),
      wildcard: _toIp(wildcard),
      network: _toIp(network),
      broadcast: _toIp(broadcast),
      firstHost: _toIp(first),
      lastHost: _toIp(last),
      hostCount: hosts,
      ipClass: ipClass,
      isPrivate: isPrivate,
      binaryMask: binary,
    );
  }
}
