import 'dart:async';

import 'package:flutter/material.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/utils/feedback.dart';
import '../services/ping_service.dart';
import '../widgets/tool_widgets.dart';

// ───────────────────────────── Ping ─────────────────────────────

class PingPage extends StatefulWidget {
  const PingPage({super.key, this.host});

  final String? host;

  @override
  State<PingPage> createState() => _PingPageState();
}

class _PingPageState extends State<PingPage> {
  late final TextEditingController _host = TextEditingController(text: widget.host ?? '1.1.1.1');
  PingSession? _session;
  StreamSubscription<PingReply>? _sub;
  final List<PingReply> _replies = [];
  PingStats _stats = PingStats();
  bool _running = false;

  @override
  void initState() {
    super.initState();
    if (widget.host != null) WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  @override
  void dispose() {
    _session?.stop();
    _sub?.cancel();
    _host.dispose();
    super.dispose();
  }

  void _start() {
    final host = cleanHostInput(_host.text);
    if (host.isEmpty) {
      showAppSnack(context, context.l10n.t('error_host_required'), kind: FeedbackKind.error);
      return;
    }
    _session?.stop();
    _sub?.cancel();
    final session = PingSession();
    _session = session;
    setState(() {
      _replies.clear();
      _stats = PingStats();
      _running = true;
    });
    _sub = session.start(host).listen(
      (reply) {
        if (!mounted) return;
        setState(() {
          _replies.add(reply);
          _stats.add(reply);
        });
      },
      onError: (Object _) {
        if (!mounted) return;
        showAppSnack(context, context.l10n.t('error_dns'), kind: FeedbackKind.error);
        setState(() => _running = false);
      },
      onDone: () {
        if (mounted) setState(() => _running = false);
      },
    );
  }

  void _stop() {
    _session?.stop();
    _sub?.cancel();
    setState(() => _running = false);
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final recent = _replies.reversed.take(40).toList();
    return ToolPage(
      title: l.t('tool_ping'),
      icon: Icons.wifi_tethering_rounded,
      children: [
        HostInput(
          controller: _host,
          label: l.t('host_label'),
          hint: '1.1.1.1 / google.com',
          running: _running,
          onRun: _start,
          onStop: _stop,
          extra: HostPresets(onSelected: (v) => setState(() => _host.text = v)),
        ),
        if (_replies.isNotEmpty) ...[
          ResultCard(
            title: l.t('statistics'),
            trailing: _session?.usesTcpFallback == true
                ? Text('TCP', style: AppTypography.mono(size: 12, color: p.warning))
                : null,
            child: Column(
              children: [
                Wrap(
                  spacing: AppSpacing.xl,
                  runSpacing: AppSpacing.md,
                  children: [
                    StatBox(label: l.t('stat_min'), value: fmtNum(_stats.min), unit: 'ms'),
                    StatBox(label: l.t('stat_avg'), value: fmtNum(_stats.avg), unit: 'ms', color: p.network),
                    StatBox(label: l.t('stat_max'), value: fmtNum(_stats.max), unit: 'ms'),
                    StatBox(label: l.t('stat_jitter'), value: fmtNum(_stats.jitter), unit: 'ms'),
                    StatBox(
                      label: l.t('stat_loss'),
                      value: fmtNum(_stats.lossPercent, digits: 0),
                      unit: '%',
                      color: _stats.lossPercent > 0 ? p.danger : p.success,
                    ),
                    StatBox(label: l.t('stat_sent'), value: '${_stats.received}/${_stats.sent}'),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),
                Sparkline(values: [for (final r in _replies) r.lost ? null : r.timeMs]),
              ],
            ),
          ),
          ResultCard(
            title: l.t('replies'),
            child: Column(
              children: [
                for (final r in recent)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 64,
                          child: Text('#${r.seq}', style: AppTypography.mono(size: 13, color: p.muted)),
                        ),
                        Expanded(
                          child: Text(
                            r.lost ? (r.message ?? l.t('lost')) : 'ttl=${r.ttl ?? '—'}',
                            style: AppTypography.mono(size: 13, color: r.lost ? p.danger : p.text),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Text(
                          r.lost ? '—' : '${fmtNum(r.timeMs, digits: 1)} ms',
                          style: AppTypography.mono(size: 13, weight: FontWeight.w700, color: p.network),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

// ───────────────────────────── Traceroute ─────────────────────────────

class TraceroutePage extends StatefulWidget {
  const TraceroutePage({super.key, this.host});

  final String? host;

  @override
  State<TraceroutePage> createState() => _TraceroutePageState();
}

class _TraceroutePageState extends State<TraceroutePage> {
  late final TextEditingController _host = TextEditingController(text: widget.host ?? 'google.com');
  final List<TraceHop> _hops = [];
  StreamSubscription<TraceHop>? _sub;
  bool _running = false;
  bool _cancel = false;

  @override
  void initState() {
    super.initState();
    if (widget.host != null) WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  @override
  void dispose() {
    _cancel = true;
    _sub?.cancel();
    _host.dispose();
    super.dispose();
  }

  void _start() {
    final host = cleanHostInput(_host.text);
    if (host.isEmpty) {
      showAppSnack(context, context.l10n.t('error_host_required'), kind: FeedbackKind.error);
      return;
    }
    _sub?.cancel();
    _cancel = false;
    setState(() {
      _hops.clear();
      _running = true;
    });
    _sub = traceroute(host, isCancelled: () => _cancel).listen(
      (hop) {
        if (mounted) setState(() => _hops.add(hop));
      },
      onError: (Object _) {
        if (!mounted) return;
        showAppSnack(context, context.l10n.t('error_dns'), kind: FeedbackKind.error);
        setState(() => _running = false);
      },
      onDone: () {
        if (mounted) setState(() => _running = false);
      },
    );
  }

  void _stop() {
    _cancel = true;
    _sub?.cancel();
    setState(() => _running = false);
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    return ToolPage(
      title: l.t('tool_traceroute'),
      icon: Icons.timeline_rounded,
      children: [
        HostInput(
          controller: _host,
          label: l.t('host_label'),
          hint: 'google.com',
          running: _running,
          onRun: _start,
          onStop: _stop,
          extra: HostPresets(onSelected: (v) => setState(() => _host.text = v)),
        ),
        if (_running && _hops.isEmpty)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          ),
        if (_hops.isNotEmpty)
          ResultCard(
            title: l.t('hops', {'count': _hops.length}),
            trailing: _running
                ? const SizedBox.square(dimension: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : null,
            child: Column(
              children: [
                for (final hop in _hops)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 30,
                          height: 30,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: (hop.reached ? p.success : p.network).faded(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: Text('${hop.ttl}', style: AppTypography.mono(size: 12, weight: FontWeight.w700, color: p.text)),
                        ),
                        const SizedBox(width: AppSpacing.md),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(hop.ip ?? '* * *', style: AppTypography.mono(size: 14, color: hop.ip == null ? p.muted : p.text)),
                              if (hop.hostname != null)
                                Text(hop.hostname!, style: text.bodySmall, overflow: TextOverflow.ellipsis),
                            ],
                          ),
                        ),
                        Text(
                          hop.timeMs == null ? '' : '${fmtNum(hop.timeMs)} ms',
                          style: AppTypography.mono(size: 13, color: p.network),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        Padding(
          padding: const EdgeInsets.only(top: AppSpacing.md),
          child: Text(l.t('traceroute_note'), style: text.bodySmall),
        ),
      ],
    );
  }
}
