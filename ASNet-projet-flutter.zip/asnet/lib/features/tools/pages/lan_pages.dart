import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/providers/app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_motion.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/utils/feedback.dart';
import '../../../shared/widgets/glass_card.dart';
import '../../scan/scan_controller.dart';
import '../../scan/services/network_scanner.dart';
import '../services/lan_tools.dart';
import '../widgets/tool_widgets.dart';

// ───────────────────────────── Wake-on-LAN ─────────────────────────────

class WakeOnLanPage extends ConsumerStatefulWidget {
  const WakeOnLanPage({super.key, this.mac});

  final String? mac;

  @override
  ConsumerState<WakeOnLanPage> createState() => _WakeOnLanPageState();
}

class _WakeOnLanPageState extends ConsumerState<WakeOnLanPage> {
  late final TextEditingController _mac = TextEditingController(text: widget.mac ?? '');
  bool _sending = false;

  @override
  void dispose() {
    _mac.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final l = context.l10n;
    setState(() => _sending = true);
    try {
      final net = ref.read(networkDetailsProvider).valueOrNull;
      String? broadcast;
      final ip = net?.ip;
      if (ip != null) {
        final info = const SubnetCalculator().calculate(ip, net?.subnetMask);
        broadcast = info?.broadcast;
      }
      final ok = await const WakeOnLan().wake(_mac.text, subnetBroadcast: broadcast);
      if (!mounted) return;
      if (ok) {
        AppMotion.confirm();
        showAppSnack(context, l.t('wol_sent'), kind: FeedbackKind.success);
      } else {
        showAppSnack(context, l.t('error_mac_invalid'), kind: FeedbackKind.error);
      }
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('wol_error'), kind: FeedbackKind.error);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final devices = ref.watch(scanControllerProvider).devices.where((d) => d.mac != null && !d.isSelf).toList();
    return ToolPage(
      title: l.t('tool_wol'),
      icon: Icons.power_settings_new_rounded,
      children: [
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextField(
                controller: _mac,
                autocorrect: false,
                textCapitalization: TextCapitalization.characters,
                style: AppTypography.mono(size: 16, color: p.text),
                decoration: InputDecoration(
                  labelText: l.t('mac_address'),
                  hintText: 'AA:BB:CC:DD:EE:FF',
                  prefixIcon: const Icon(Icons.memory_rounded),
                ),
              ),
              const SizedBox(height: AppSpacing.md),
              FilledButton.icon(
                onPressed: _sending ? null : _send,
                icon: const Icon(Icons.power_settings_new_rounded),
                label: Text(l.t('wol_send')),
              ),
            ],
          ),
        ),
        ResultCard(
          title: l.t('wol_devices'),
          child: devices.isEmpty
              ? Text(l.t('wol_no_devices'), style: text.bodyMedium?.copyWith(color: p.muted))
              : Column(
                  children: [
                    for (final d in devices)
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(d.displayName, overflow: TextOverflow.ellipsis),
                        subtitle: Text('${d.ip} · ${d.mac}', style: AppTypography.mono(size: 11, color: p.muted)),
                        trailing: const Icon(Icons.input_rounded),
                        onTap: () => setState(() => _mac.text = d.mac ?? ''),
                      ),
                  ],
                ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: AppSpacing.md),
          child: Text(l.t('wol_note'), style: text.bodySmall),
        ),
      ],
    );
  }
}

// ───────────────────────────── Calculateur IP ─────────────────────────────

class SubnetCalculatorPage extends ConsumerStatefulWidget {
  const SubnetCalculatorPage({super.key});

  @override
  ConsumerState<SubnetCalculatorPage> createState() => _SubnetCalculatorPageState();
}

class _SubnetCalculatorPageState extends ConsumerState<SubnetCalculatorPage> {
  final TextEditingController _input = TextEditingController();

  @override
  void initState() {
    super.initState();
    final net = ref.read(networkDetailsProvider).valueOrNull;
    final ip = net?.ip;
    if (ip != null) {
      final range = NetworkScanner.computeRange(ip, net?.subnetMask);
      final mask = net?.subnetMask;
      _input.text = mask == null ? '$ip/${range.prefix}' : '$ip $mask';
    } else {
      _input.text = '192.168.1.10/24';
    }
    _input.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final info = const SubnetCalculator().calculate(_input.text);
    return ToolPage(
      title: l.t('tool_subnet'),
      icon: Icons.functions_rounded,
      children: [
        GlassCard(
          child: TextField(
            controller: _input,
            autocorrect: false,
            keyboardType: TextInputType.text,
            style: AppTypography.mono(size: 16, color: p.text),
            decoration: InputDecoration(
              labelText: l.t('subnet_input'),
              hintText: '192.168.1.10/24',
              prefixIcon: const Icon(Icons.account_tree_rounded),
            ),
          ),
        ),
        if (info == null)
          ResultCard(
            title: l.t('error'),
            accent: p.danger,
            child: Text(l.t('subnet_invalid')),
          )
        else
          ResultCard(
            title: '${info.network}/${info.prefix}',
            child: Column(
              children: [
                KeyValueRow(l.t('netmask'), info.mask),
                KeyValueRow('Wildcard', info.wildcard),
                KeyValueRow(l.t('network_address'), info.network),
                KeyValueRow('Broadcast', info.broadcast),
                KeyValueRow(l.t('first_host'), info.firstHost),
                KeyValueRow(l.t('last_host'), info.lastHost),
                KeyValueRow(l.t('host_count'), '${info.hostCount}'),
                KeyValueRow(l.t('ip_class'), info.ipClass),
                KeyValueRow(l.t('ip_scope'), info.isPrivate ? l.t('private') : l.t('public')),
                KeyValueRow(l.t('binary_mask'), info.binaryMask),
              ],
            ),
          ),
      ],
    );
  }
}
