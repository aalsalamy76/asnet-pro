import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/providers/app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_motion.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../shared/utils/feedback.dart';
import '../../../shared/utils/time_format.dart';
import '../../../shared/widgets/glass_card.dart';
import '../../../shared/widgets/ui_parts.dart';
import '../../scan/scan_controller.dart';
import '../services/security_audit.dart';
import '../widgets/tool_widgets.dart';

class LastAuditSummary {
  const LastAuditSummary({required this.score, required this.at, required this.issues});

  final int score;
  final DateTime at;
  final int issues;
}

final lastAuditProvider = NotifierProvider<LastAuditController, LastAuditSummary?>(LastAuditController.new);

class LastAuditController extends Notifier<LastAuditSummary?> {
  static const String storageKey = 'asnet.last_audit';

  @override
  LastAuditSummary? build() {
    final raw = ref.read(sharedPreferencesProvider).getString(storageKey);
    if (raw == null) return null;
    try {
      final m = jsonDecode(raw);
      if (m is! Map) return null;
      return LastAuditSummary(
        score: (m['score'] as num?)?.toInt() ?? 0,
        at: DateTime.tryParse('${m['at']}') ?? DateTime.now(),
        issues: (m['issues'] as num?)?.toInt() ?? 0,
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> save(AuditReport report) async {
    final summary = LastAuditSummary(score: report.score, at: report.at, issues: report.issues.length);
    state = summary;
    try {
      await ref.read(sharedPreferencesProvider).setString(
            storageKey,
            jsonEncode({'score': summary.score, 'at': summary.at.toIso8601String(), 'issues': summary.issues}),
          );
    } catch (_) {}
  }
}

Color severityColor(AppPalette p, Severity s) {
  switch (s) {
    case Severity.critical:
      return p.danger;
    case Severity.high:
      return const Color(0xFFF97316);
    case Severity.medium:
      return p.warning;
    case Severity.low:
      return p.network;
    case Severity.pass:
      return p.success;
  }
}

Color scoreColor(AppPalette p, int score) {
  if (score >= 85) return p.success;
  if (score >= 65) return p.network;
  if (score >= 40) return p.warning;
  return p.danger;
}

class AuditPage extends ConsumerStatefulWidget {
  const AuditPage({super.key});

  @override
  ConsumerState<AuditPage> createState() => _AuditPageState();
}

class _AuditPageState extends ConsumerState<AuditPage> {
  AuditReport? _report;
  bool _running = false;
  double _progress = 0;
  String _stepKey = 'audit_step_wifi';

  Future<void> _run() async {
    final l = context.l10n;
    setState(() {
      _running = true;
      _progress = 0;
      _report = null;
    });
    try {
      final network = await ref.read(networkInfoServiceProvider).load();
      if (!network.isOnline) {
        if (mounted) showAppSnack(context, l.t('error_offline'), kind: FeedbackKind.error);
        return;
      }
      final devices = ref.read(scanControllerProvider).devices;
      final report = await const SecurityAuditor().run(
        network: network,
        devices: devices,
        onProgress: (value, key) {
          if (mounted) {
            setState(() {
              _progress = value;
              _stepKey = key;
            });
          }
        },
      );
      await ref.read(lastAuditProvider.notifier).save(report);
      if (!mounted) return;
      AppMotion.confirm();
      setState(() => _report = report);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('audit_error'), kind: FeedbackKind.error);
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final report = _report;
    final last = ref.watch(lastAuditProvider);
    final scanned = ref.watch(scanControllerProvider).devices.length;

    return ToolPage(
      title: l.t('tool_audit'),
      icon: Icons.security_rounded,
      children: [
        GlassCard(
          accent: report == null ? p.network : scoreColor(p, report.score),
          child: Column(
            children: [
              if (report != null) ...[
                ScoreRing(
                  score: report.score,
                  color: scoreColor(p, report.score),
                  size: 140,
                  semanticLabel: l.t('audit_score_semantic', {'score': report.score}),
                ),
                const SizedBox(height: AppSpacing.md),
                Text(l.t(_verdictKey(report.score)), style: text.titleLarge, textAlign: TextAlign.center),
                const SizedBox(height: AppSpacing.sm),
                Wrap(
                  spacing: AppSpacing.xs,
                  runSpacing: AppSpacing.xs,
                  alignment: WrapAlignment.center,
                  children: [
                    for (final s in Severity.values)
                      if (report.count(s) > 0)
                        StatusPill(label: '${report.count(s)} ${l.t('sev_${s.name}')}', color: severityColor(p, s)),
                  ],
                ),
              ] else ...[
                Icon(Icons.security_rounded, size: 56, color: p.network),
                const SizedBox(height: AppSpacing.md),
                Text(l.t('audit_intro'), style: text.bodyMedium?.copyWith(color: p.muted), textAlign: TextAlign.center),
                if (last != null) ...[
                  const SizedBox(height: AppSpacing.sm),
                  Text(
                    l.t('audit_last', {'score': last.score, 'when': relativeTime(l, last.at)}),
                    style: text.bodySmall,
                  ),
                ],
                if (scanned == 0) ...[
                  const SizedBox(height: AppSpacing.sm),
                  Text(l.t('audit_scan_first'), style: text.bodySmall?.copyWith(color: p.warning), textAlign: TextAlign.center),
                ],
              ],
              const SizedBox(height: AppSpacing.lg),
              if (_running) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(value: _progress, minHeight: 6),
                ),
                const SizedBox(height: AppSpacing.sm),
                Text(l.t(_stepKey), style: text.bodySmall),
              ] else
                GradientButton(
                  label: report == null ? l.t('audit_run') : l.t('audit_again'),
                  icon: Icons.security_rounded,
                  onPressed: _run,
                ),
            ],
          ),
        ),
        if (report != null) ...[
          if (report.issues.isNotEmpty) SectionTitle(l.t('audit_issues', {'count': report.issues.length})),
          for (final f in report.issues) _FindingCard(finding: f),
          if (report.passed.isNotEmpty) SectionTitle(l.t('audit_passed', {'count': report.passed.length})),
          for (final f in report.passed) _FindingCard(finding: f),
          Padding(
            padding: const EdgeInsets.only(top: AppSpacing.md),
            child: Text(l.t('audit_note', {'count': report.devicesChecked}), style: text.bodySmall),
          ),
        ],
      ],
    );
  }

  static String _verdictKey(int score) {
    if (score >= 85) return 'audit_verdict_good';
    if (score >= 65) return 'audit_verdict_ok';
    if (score >= 40) return 'audit_verdict_warn';
    return 'audit_verdict_bad';
  }
}

class _FindingCard extends StatelessWidget {
  const _FindingCard({required this.finding});

  final AuditFinding finding;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final color = severityColor(p, finding.severity);
    final args = <String, Object?>{...finding.args, 'host': finding.host ?? ''};
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.sm),
      child: GlassCard(
        blur: false,
        accent: color,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(
              finding.severity == Severity.pass ? Icons.check_circle_rounded : Icons.error_outline_rounded,
              color: color,
            ),
            const SizedBox(width: AppSpacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Text(l.t('${finding.key}_title', args), style: text.titleSmall?.copyWith(fontWeight: FontWeight.w700))),
                      if (finding.severity != Severity.pass)
                        StatusPill(label: l.t('sev_${finding.severity.name}'), color: color),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(l.t('${finding.key}_body', args), style: text.bodySmall),
                  if (finding.host != null && finding.host!.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    KeyValueRow(l.t('target'), finding.host!),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
