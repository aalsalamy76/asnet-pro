import 'package:flutter/material.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/utils/feedback.dart';
import '../../../shared/widgets/glass_card.dart';
import '../../../shared/widgets/ui_parts.dart';
import '../services/web_tools.dart';
import '../widgets/tool_widgets.dart';

String _date(DateTime? d) {
  if (d == null) return '—';
  String two(int v) => v.toString().padLeft(2, '0');
  return '${d.year}-${two(d.month)}-${two(d.day)}';
}

// ───────────────────────────── IP publique ─────────────────────────────

class PublicIpPage extends StatefulWidget {
  const PublicIpPage({super.key});

  @override
  State<PublicIpPage> createState() => _PublicIpPageState();
}

class _PublicIpPageState extends State<PublicIpPage> {
  PublicIpInfo? _info;
  bool _loading = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _failed = false;
    });
    try {
      final info = await const WebTools().publicIp();
      if (mounted) setState(() => _info = info);
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final info = _info;
    return ToolPage(
      title: l.t('tool_public_ip'),
      icon: Icons.public_rounded,
      actions: [
        IconButton(
          tooltip: l.t('refresh'),
          onPressed: _loading ? null : _load,
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
      children: [
        if (_loading && info == null)
          const Padding(padding: EdgeInsets.all(32), child: Center(child: CircularProgressIndicator())),
        if (_failed)
          ResultCard(title: l.t('error'), accent: p.danger, child: Text(l.t('internet_error'), style: text.bodyMedium)),
        if (info != null) ...[
          GlassCard(
            accent: p.network,
            child: Column(
              children: [
                Text(l.t('your_public_ip'), style: text.labelLarge?.copyWith(color: p.muted)),
                const SizedBox(height: AppSpacing.xs),
                SelectableText(
                  info.ip,
                  textAlign: TextAlign.center,
                  style: AppTypography.mono(size: info.ip.length > 16 ? 18 : 30, weight: FontWeight.w800, color: p.text),
                ),
                if (info.org != null) ...[
                  const SizedBox(height: AppSpacing.xs),
                  Text(info.org!, style: text.titleMedium, textAlign: TextAlign.center),
                ],
              ],
            ),
          ),
          ResultCard(
            title: l.t('details'),
            child: Column(
              children: [
                KeyValueRow(l.t('isp'), info.org ?? '—', mono: false),
                KeyValueRow(l.t('reverse_dns'), info.hostname ?? '—'),
                KeyValueRow(l.t('city'), [info.city, info.region].whereType<String>().join(', '), mono: false),
                KeyValueRow(l.t('country'), info.country ?? '—', mono: false),
                KeyValueRow(l.t('timezone'), info.timezone ?? '—', mono: false),
                KeyValueRow('GPS', info.location ?? '—'),
                KeyValueRow('Cloudflare PoP', info.cloudflareColo ?? '—'),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: AppSpacing.md),
            child: Text(l.t('public_ip_note'), style: text.bodySmall),
          ),
        ],
      ],
    );
  }
}

// ───────────────────────────── Whois ─────────────────────────────

class WhoisPage extends StatefulWidget {
  const WhoisPage({super.key, this.host});

  final String? host;

  @override
  State<WhoisPage> createState() => _WhoisPageState();
}

class _WhoisPageState extends State<WhoisPage> {
  late final TextEditingController _query = TextEditingController(text: widget.host ?? 'google.com');
  String? _result;
  bool _running = false;

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final l = context.l10n;
    if (_query.text.trim().isEmpty) {
      showAppSnack(context, l.t('error_host_required'), kind: FeedbackKind.error);
      return;
    }
    setState(() {
      _running = true;
      _result = null;
    });
    try {
      final r = await const WebTools().whois(_query.text);
      if (mounted) setState(() => _result = r);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('whois_error'), kind: FeedbackKind.error);
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    return ToolPage(
      title: l.t('tool_whois'),
      icon: Icons.assignment_ind_rounded,
      children: [
        HostInput(
          controller: _query,
          label: l.t('domain_or_ip'),
          hint: 'exemple.fr / 8.8.8.8',
          running: _running,
          onRun: _run,
          onStop: () {},
        ),
        if (_running) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
        if (_result != null)
          ResultCard(
            title: l.t('results'),
            child: SelectableText(
              _result!.trim(),
              style: AppTypography.mono(size: 12, color: p.text),
            ),
          ),
      ],
    );
  }
}

// ───────────────────────────── Certificat TLS ─────────────────────────────

class TlsPage extends StatefulWidget {
  const TlsPage({super.key, this.host});

  final String? host;

  @override
  State<TlsPage> createState() => _TlsPageState();
}

class _TlsPageState extends State<TlsPage> {
  late final TextEditingController _host = TextEditingController(text: widget.host ?? 'google.com');
  final TextEditingController _port = TextEditingController(text: '443');
  TlsReport? _report;
  bool _running = false;

  @override
  void dispose() {
    _host.dispose();
    _port.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final l = context.l10n;
    final port = int.tryParse(_port.text.trim()) ?? 443;
    if (_host.text.trim().isEmpty) {
      showAppSnack(context, l.t('error_host_required'), kind: FeedbackKind.error);
      return;
    }
    setState(() {
      _running = true;
      _report = null;
    });
    try {
      final r = await const WebTools().tls(_host.text, port: port);
      if (mounted) setState(() => _report = r);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('tls_error'), kind: FeedbackKind.error);
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final r = _report;
    final days = r?.daysLeft;
    final validityColor = days == null
        ? p.muted
        : days < 0
            ? p.danger
            : days < 21
                ? p.warning
                : p.success;
    return ToolPage(
      title: l.t('tool_tls'),
      icon: Icons.verified_user_rounded,
      children: [
        HostInput(
          controller: _host,
          label: l.t('host_label'),
          hint: 'exemple.fr',
          running: _running,
          onRun: _run,
          onStop: () {},
          extra: TextField(
            controller: _port,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: l.t('port')),
          ),
        ),
        if (_running) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
        if (r != null) ...[
          ResultCard(
            title: '${r.host}:${r.port}',
            accent: r.trusted ? p.success : p.danger,
            trailing: StatusPill(
              label: r.trusted ? l.t('tls_trusted') : l.t('tls_untrusted'),
              color: r.trusted ? p.success : p.danger,
            ),
            child: Column(
              children: [
                KeyValueRow(l.t('tls_subject'), r.subject),
                KeyValueRow(l.t('tls_issuer'), r.issuer),
                KeyValueRow(l.t('tls_valid_from'), _date(r.validFrom)),
                KeyValueRow(
                  l.t('tls_valid_to'),
                  days == null ? _date(r.validTo) : '${_date(r.validTo)}  (${l.t('days_left', {'n': days})})',
                  valueColor: validityColor,
                ),
                KeyValueRow('ALPN', r.alpn ?? '—'),
                KeyValueRow(l.t('handshake'), '${r.handshakeMs} ms'),
                KeyValueRow('IP', r.remoteIp),
                KeyValueRow('SHA-1', r.sha1 ?? '—'),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

// ───────────────────────────── En-têtes HTTP ─────────────────────────────

class HttpHeadersPage extends StatefulWidget {
  const HttpHeadersPage({super.key, this.host});

  final String? host;

  @override
  State<HttpHeadersPage> createState() => _HttpHeadersPageState();
}

class _HttpHeadersPageState extends State<HttpHeadersPage> {
  late final TextEditingController _url = TextEditingController(text: widget.host ?? 'http://google.com');
  List<HttpHop> _hops = const [];
  bool _running = false;

  static const _securityHeaders = [
    'strict-transport-security',
    'content-security-policy',
    'x-frame-options',
    'x-content-type-options',
    'referrer-policy',
    'permissions-policy',
  ];

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final l = context.l10n;
    if (_url.text.trim().isEmpty) {
      showAppSnack(context, l.t('error_host_required'), kind: FeedbackKind.error);
      return;
    }
    setState(() {
      _running = true;
      _hops = const [];
    });
    try {
      final hops = await const WebTools().httpChain(_url.text);
      if (mounted) setState(() => _hops = hops);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('http_error'), kind: FeedbackKind.error);
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  Color _statusColor(AppPalette p, int code) {
    if (code >= 500) return p.danger;
    if (code >= 400) return p.warning;
    if (code >= 300) return p.share;
    return p.success;
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final last = _hops.isEmpty ? null : _hops.last;
    return ToolPage(
      title: l.t('tool_http'),
      icon: Icons.http_rounded,
      children: [
        HostInput(
          controller: _url,
          label: 'URL',
          hint: 'https://exemple.fr',
          running: _running,
          onRun: _run,
          onStop: () {},
        ),
        if (_running) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
        if (_hops.isNotEmpty)
          ResultCard(
            title: l.t('redirect_chain', {'count': _hops.length - 1}),
            child: Column(
              children: [
                for (final hop in _hops)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _statusColor(p, hop.statusCode).faded(0.15),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            '${hop.statusCode}',
                            style: AppTypography.mono(size: 13, weight: FontWeight.w800, color: _statusColor(p, hop.statusCode)),
                          ),
                        ),
                        const SizedBox(width: AppSpacing.sm),
                        Expanded(
                          child: Text(hop.url, style: AppTypography.mono(size: 12, color: p.text), overflow: TextOverflow.ellipsis, maxLines: 2),
                        ),
                        Text('${hop.elapsedMs} ms', style: AppTypography.mono(size: 11, color: p.muted)),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        if (last != null) ...[
          ResultCard(
            title: l.t('security_headers'),
            child: Column(
              children: [
                for (final h in _securityHeaders)
                  Row(
                    children: [
                      Icon(
                        last.headers.containsKey(h) ? Icons.check_circle_rounded : Icons.cancel_rounded,
                        size: 18,
                        color: last.headers.containsKey(h) ? p.success : p.muted,
                      ),
                      const SizedBox(width: AppSpacing.sm),
                      Expanded(child: Text(h, style: AppTypography.mono(size: 12, color: p.text))),
                    ],
                  ),
              ],
            ),
          ),
          ResultCard(
            title: l.t('headers_count', {'count': last.headers.length}),
            child: Column(
              children: [
                for (final entry in last.headers.entries) KeyValueRow(entry.key, entry.value),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: AppSpacing.md),
            child: Text(l.t('http_note'), style: text.bodySmall),
          ),
        ],
      ],
    );
  }
}
