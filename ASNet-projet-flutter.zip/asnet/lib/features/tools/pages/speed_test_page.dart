import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/utils/feedback.dart';
import '../../../shared/widgets/glass_card.dart';
import '../../../shared/widgets/ui_parts.dart';
import '../services/speed_test.dart';
import '../widgets/tool_widgets.dart';

class SpeedTestPage extends StatefulWidget {
  const SpeedTestPage({super.key});

  @override
  State<SpeedTestPage> createState() => _SpeedTestPageState();
}

class _SpeedTestPageState extends State<SpeedTestPage> {
  SpeedTest? _test;
  StreamSubscription<SpeedProgress>? _sub;
  SpeedProgress? _progress;
  bool _running = false;

  @override
  void dispose() {
    _test?.cancel();
    _sub?.cancel();
    super.dispose();
  }

  void _start() {
    final test = SpeedTest();
    _test = test;
    setState(() {
      _running = true;
      _progress = const SpeedProgress(phase: SpeedPhase.latency);
    });
    _sub = test.run().listen(
      (p) {
        if (mounted) setState(() => _progress = p);
      },
      onError: (Object _) {
        if (!mounted) return;
        showAppSnack(context, context.l10n.t('speed_error'), kind: FeedbackKind.error);
        setState(() => _running = false);
      },
      onDone: () {
        if (mounted) setState(() => _running = false);
      },
    );
  }

  void _stop() {
    _test?.cancel();
    _sub?.cancel();
    setState(() => _running = false);
  }

  String _phaseLabel(AppLocalizations l, SpeedPhase phase) {
    switch (phase) {
      case SpeedPhase.latency:
        return l.t('speed_latency');
      case SpeedPhase.download:
        return l.t('speed_download');
      case SpeedPhase.upload:
        return l.t('speed_upload');
      case SpeedPhase.done:
        return l.t('speed_done');
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final progress = _progress;
    final phase = progress?.phase;
    final gaugeValue = progress?.currentMbps ??
        (phase == SpeedPhase.done ? progress?.downloadMbps : null) ??
        0.0;
    final gaugeColor = phase == SpeedPhase.upload ? p.share : p.network;

    return ToolPage(
      title: l.t('tool_speed'),
      icon: Icons.speed_rounded,
      children: [
        GlassCard(
          accent: gaugeColor,
          child: Column(
            children: [
              SizedBox(
                height: 230,
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: gaugeValue),
                  duration: const Duration(milliseconds: 240),
                  builder: (context, v, _) => CustomPaint(
                    size: Size.infinite,
                    painter: _GaugePainter(value: v, color: gaugeColor, track: p.glassBorder, text: p.muted),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 40),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              v.toStringAsFixed(v >= 100 ? 0 : 1),
                              style: AppTypography.mono(size: 44, weight: FontWeight.w800, color: p.text),
                            ),
                            Text('Mbit/s', style: AppTypography.mono(size: 13, color: p.muted)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              if (phase != null) ...[
                Text(_phaseLabel(l, phase), style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: AppSpacing.sm),
                if (_running)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: progress?.phaseProgress ?? 0.0,
                      minHeight: 6,
                      color: gaugeColor,
                    ),
                  ),
              ],
              const SizedBox(height: AppSpacing.lg),
              if (_running)
                OutlinedButton.icon(
                  onPressed: _stop,
                  icon: const Icon(Icons.stop_rounded),
                  label: Text(l.t('stop')),
                )
              else
                GradientButton(
                  label: progress == null ? l.t('speed_start') : l.t('speed_again'),
                  icon: Icons.speed_rounded,
                  onPressed: _start,
                ),
            ],
          ),
        ),
        ResultCard(
          title: l.t('results'),
          child: Wrap(
            spacing: AppSpacing.xl,
            runSpacing: AppSpacing.md,
            children: [
              StatBox(label: l.t('speed_download'), value: fmtNum(progress?.downloadMbps), unit: 'Mbit/s', color: p.network),
              StatBox(label: l.t('speed_upload'), value: fmtNum(progress?.uploadMbps), unit: 'Mbit/s', color: p.share),
              StatBox(label: l.t('ping'), value: fmtNum(progress?.pingMs, digits: 0), unit: 'ms'),
              StatBox(label: l.t('stat_jitter'), value: fmtNum(progress?.jitterMs), unit: 'ms'),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: AppSpacing.md),
          child: Text(l.t('speed_note'), style: Theme.of(context).textTheme.bodySmall),
        ),
      ],
    );
  }
}

/// Jauge semi-circulaire à échelle logarithmique (1 -> 1000 Mbit/s).
class _GaugePainter extends CustomPainter {
  _GaugePainter({required this.value, required this.color, required this.track, required this.text});

  final double value;
  final Color color;
  final Color track;
  final Color text;

  static double fraction(double mbps) {
    if (mbps <= 0) return 0;
    final f = math.log(mbps + 1) / math.log(1001);
    return f > 1 ? 1 : f;
  }

  @override
  void paint(Canvas canvas, Size size) {
    final radius = math.min(size.width / 2, size.height) * 0.82;
    final center = Offset(size.width / 2, size.height * 0.62);
    final rect = Rect.fromCircle(center: center, radius: radius);
    const start = math.pi * 0.8;
    const sweep = math.pi * 1.4;
    final stroke = radius * 0.12;

    canvas.drawArc(
      rect,
      start,
      sweep,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = stroke
        ..strokeCap = StrokeCap.round
        ..color = track,
    );
    final f = fraction(value);
    if (f > 0) {
      canvas.drawArc(
        rect,
        start,
        sweep * f,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = stroke
          ..strokeCap = StrokeCap.round
          ..shader = SweepGradient(
            startAngle: start,
            endAngle: start + sweep,
            colors: [color.faded(0.4), color],
          ).createShader(rect),
      );
    }
    // Graduations 1, 10, 100, 1000.
    for (final mark in const [1.0, 10.0, 100.0, 1000.0]) {
      final angle = start + sweep * fraction(mark);
      final inner = Offset(center.dx + math.cos(angle) * (radius - stroke), center.dy + math.sin(angle) * (radius - stroke));
      final painter = TextPainter(
        text: TextSpan(text: mark.toStringAsFixed(0), style: TextStyle(color: text, fontSize: 10)),
        textDirection: TextDirection.ltr,
      )..layout();
      painter.paint(canvas, inner - Offset(painter.width / 2, painter.height / 2));
    }
  }

  @override
  bool shouldRepaint(covariant _GaugePainter old) => old.value != value || old.color != color;
}
