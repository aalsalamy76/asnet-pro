import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/network/ports_catalog.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/utils/feedback.dart';
import '../services/ping_service.dart';
import '../services/port_scanner.dart';
import '../widgets/tool_widgets.dart';

enum PortPreset { common, wellKnown, full, custom }

class PortScanPage extends StatefulWidget {
  const PortScanPage({super.key, this.host});

  final String? host;

  @override
  State<PortScanPage> createState() => _PortScanPageState();
}

class _PortScanPageState extends State<PortScanPage> {
  late final TextEditingController _host = TextEditingController(text: widget.host ?? '');
  final TextEditingController _custom = TextEditingController(text: '22,80,443,8000-8100');
  PortPreset _preset = PortPreset.common;
  final List<OpenPort> _open = [];
  bool _running = false;
  bool _cancel = false;
  int _done = 0;
  int _total = 0;
  bool _finished = false;

  @override
  void dispose() {
    _cancel = true;
    _host.dispose();
    _custom.dispose();
    super.dispose();
  }

  List<int>? _ports() {
    switch (_preset) {
      case PortPreset.common:
        return PortsCatalog.common;
      case PortPreset.wellKnown:
        return [for (var p = 1; p <= 1024; p++) p];
      case PortPreset.full:
        return [for (var p = 1; p <= 65535; p++) p];
      case PortPreset.custom:
        return PortsCatalog.parse(_custom.text);
    }
  }

  Future<void> _start() async {
    final l = context.l10n;
    final host = cleanHostInput(_host.text);
    if (host.isEmpty) {
      showAppSnack(context, l.t('error_host_required'), kind: FeedbackKind.error);
      return;
    }
    final ports = _ports();
    if (ports == null) {
      showAppSnack(context, l.t('error_ports_invalid'), kind: FeedbackKind.error);
      return;
    }
    setState(() {
      _open.clear();
      _running = true;
      _cancel = false;
      _done = 0;
      _total = ports.length;
      _finished = false;
    });
    var lastUi = DateTime.now();
    try {
      await const PortScanner().scan(
        host,
        ports,
        concurrency: _preset == PortPreset.full ? 192 : 128,
        isCancelled: () => _cancel,
        onOpen: (port) {
          if (mounted) setState(() => _open.add(port));
        },
        onProgress: (done, total) {
          final now = DateTime.now();
          if (done == total || now.difference(lastUi).inMilliseconds > 120) {
            lastUi = now;
            if (mounted) setState(() => _done = done);
          }
        },
      );
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('error_dns'), kind: FeedbackKind.error);
    }
    if (!mounted) return;
    setState(() {
      _running = false;
      _finished = true;
      _open.sort((a, b) => a.port.compareTo(b.port));
    });
  }

  Future<void> _openWeb(OpenPort port) async {
    final host = cleanHostInput(_host.text);
    final scheme = PortsCatalog.isHttps(port.port) ? 'https' : 'http';
    try {
      await launchUrl(Uri.parse('$scheme://$host:${port.port}'), mode: LaunchMode.externalApplication);
    } catch (_) {
      if (mounted) showAppSnack(context, context.l10n.t('open_failed'), kind: FeedbackKind.error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final progress = _total == 0 ? 0.0 : _done / _total;
    return ToolPage(
      title: l.t('tool_ports'),
      icon: Icons.settings_input_component_rounded,
      children: [
        HostInput(
          controller: _host,
          label: l.t('host_label'),
          hint: '192.168.1.1',
          running: _running,
          onRun: _start,
          onStop: () => setState(() => _cancel = true),
          extra: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              HostPresets(onSelected: (v) => setState(() => _host.text = v), includeDomains: false),
              const SizedBox(height: AppSpacing.md),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: [
                  for (final preset in PortPreset.values)
                    ChoiceChip(
                      label: Text(l.t('ports_${preset.name}')),
                      selected: _preset == preset,
                      onSelected: _running ? null : (_) => setState(() => _preset = preset),
                    ),
                ],
              ),
              if (_preset == PortPreset.custom) ...[
                const SizedBox(height: AppSpacing.md),
                TextField(
                  controller: _custom,
                  enabled: !_running,
                  keyboardType: TextInputType.text,
                  style: AppTypography.mono(size: 14, color: p.text),
                  decoration: InputDecoration(labelText: l.t('ports_custom_label'), hintText: '22,80,8000-8100'),
                ),
              ],
              if (_preset == PortPreset.full) ...[
                const SizedBox(height: AppSpacing.sm),
                Text(l.t('ports_full_warning'), style: text.bodySmall?.copyWith(color: p.warning)),
              ],
            ],
          ),
        ),
        if (_running || _finished)
          ResultCard(
            title: l.t('open_ports', {'count': _open.length}),
            trailing: Text(
              '$_done/$_total',
              style: AppTypography.mono(size: 12, color: p.muted),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_running) ...[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(value: progress, minHeight: 6),
                  ),
                  const SizedBox(height: AppSpacing.md),
                ],
                if (_open.isEmpty && _finished)
                  Text(l.t('no_open_ports'), style: text.bodyMedium?.copyWith(color: p.muted)),
                for (final port in _open)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Container(
                      width: 64,
                      alignment: Alignment.center,
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      decoration: BoxDecoration(
                        color: (PortsCatalog.riskyDevice.contains(port.port) ? p.warning : p.success).faded(0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '${port.port}',
                        style: AppTypography.mono(size: 14, weight: FontWeight.w800, color: p.text),
                      ),
                    ),
                    title: Text(port.service),
                    subtitle: Text(
                      port.banner ?? '${fmtNum(port.latencyMs)} ms',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.mono(size: 11, color: p.muted),
                    ),
                    trailing: PortsCatalog.isHttp(port.port) || PortsCatalog.isHttps(port.port)
                        ? IconButton(
                            tooltip: l.t('open_web'),
                            icon: const Icon(Icons.open_in_browser_rounded),
                            onPressed: () => _openWeb(port),
                          )
                        : null,
                  ),
              ],
            ),
          ),
      ],
    );
  }
}
