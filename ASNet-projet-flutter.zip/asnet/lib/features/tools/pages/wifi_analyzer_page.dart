// Décision : rafraîchissement manuel (bouton) — Android limite les scans Wi-Fi à 4 toutes les
// 2 minutes ; un rafraîchissement automatique renverrait surtout des résultats en cache.
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/network/native_wifi.dart';
import '../../../core/providers/app_providers.dart';
import '../../../core/services/permission_service.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/widgets/glass_card.dart';
import '../widgets/tool_widgets.dart';

class WifiAnalyzerPage extends ConsumerStatefulWidget {
  const WifiAnalyzerPage({super.key});

  @override
  ConsumerState<WifiAnalyzerPage> createState() => _WifiAnalyzerPageState();
}

class _WifiAnalyzerPageState extends ConsumerState<WifiAnalyzerPage> {
  List<WifiAccessPoint> _aps = const [];
  WifiLinkInfo? _link;
  bool _loading = false;
  String _band = '2.4 GHz';
  bool _permissionDenied = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _refresh());
  }

  Future<void> _refresh() async {
    if (_loading) return;
    final granted = await ref.read(permissionServiceProvider).ensure(context, AppPermission.location);
    if (!mounted) return;
    setState(() {
      _permissionDenied = !granted;
      _loading = true;
    });
    final link = await NativeWifi.linkInfo();
    final aps = granted ? await NativeWifi.scan() : const <WifiAccessPoint>[];
    if (!mounted) return;
    setState(() {
      _link = link;
      _aps = aps;
      _loading = false;
      if (link != null && link.band != '—' && aps.any((a) => a.band == link.band)) _band = link.band;
    });
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final link = _link;
    final currentBssid = ref.watch(networkDetailsProvider).valueOrNull?.bssid?.toUpperCase();
    final bands = {for (final a in _aps) a.band}..removeWhere((b) => b == '—');
    final shown = _aps.where((a) => a.band == _band).toList();

    return ToolPage(
      title: l.t('tool_wifi'),
      icon: Icons.wifi_rounded,
      actions: [
        IconButton(
          tooltip: l.t('refresh'),
          onPressed: _loading ? null : _refresh,
          icon: _loading
              ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.refresh_rounded),
        ),
      ],
      children: [
        if (link != null)
          GlassCard(
            accent: p.network,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(l.t('current_link'), style: text.titleMedium),
                const SizedBox(height: AppSpacing.md),
                Wrap(
                  spacing: AppSpacing.xl,
                  runSpacing: AppSpacing.md,
                  children: [
                    StatBox(
                      label: l.t('signal'),
                      value: '${link.rssi}',
                      unit: 'dBm',
                      color: _signalColor(p, link.rssi),
                    ),
                    StatBox(label: l.t('quality'), value: '${link.quality}', unit: '%'),
                    StatBox(label: l.t('link_speed'), value: '${link.linkSpeed}', unit: 'Mbit/s'),
                    StatBox(label: l.t('channel'), value: '${link.channel}', unit: link.band),
                  ],
                ),
                const SizedBox(height: AppSpacing.md),
                KeyValueRow(l.t('wifi_standard'), link.standardLabel),
                KeyValueRow(l.t('frequency'), '${link.frequency} MHz'),
                if (link.txLinkSpeed != null && link.rxLinkSpeed != null)
                  KeyValueRow(l.t('tx_rx'), '${link.txLinkSpeed} / ${link.rxLinkSpeed} Mbit/s'),
              ],
            ),
          ),
        if (_permissionDenied)
          ResultCard(
            title: l.t('perm_location_title'),
            accent: p.warning,
            child: Text(l.t('wifi_scan_needs_location'), style: text.bodyMedium),
          ),
        if (bands.isNotEmpty) ...[
          const SizedBox(height: AppSpacing.md),
          Wrap(
            spacing: AppSpacing.xs,
            children: [
              for (final b in (bands.toList()..sort()))
                ChoiceChip(
                  label: Text('$b (${_aps.where((a) => a.band == b).length})'),
                  selected: _band == b,
                  onSelected: (_) => setState(() => _band = b),
                ),
            ],
          ),
          ResultCard(
            title: l.t('channel_map'),
            child: SizedBox(
              height: 180,
              child: CustomPaint(
                size: Size.infinite,
                painter: _ChannelPainter(
                  aps: shown,
                  band: _band,
                  colors: [p.network, p.share, p.success, p.warning, p.danger, const Color(0xFF38BDF8), const Color(0xFFF472B6)],
                  grid: p.glassBorder,
                  label: p.muted,
                  highlight: currentBssid,
                ),
              ),
            ),
          ),
          ResultCard(
            title: l.t('networks_count', {'count': shown.length}),
            child: Column(
              children: [
                for (final ap in shown) _ApTile(ap: ap, current: ap.bssid == currentBssid),
              ],
            ),
          ),
        ] else if (!_loading && !_permissionDenied)
          ResultCard(
            title: l.t('no_networks'),
            child: Text(l.t('wifi_scan_hint'), style: text.bodyMedium?.copyWith(color: p.muted)),
          ),
        Padding(
          padding: const EdgeInsets.only(top: AppSpacing.md),
          child: Text(l.t('wifi_throttle_note'), style: text.bodySmall),
        ),
      ],
    );
  }
}

Color _signalColor(AppPalette p, int dbm) {
  if (dbm >= -60) return p.success;
  if (dbm >= -70) return p.network;
  if (dbm >= -80) return p.warning;
  return p.danger;
}

class _ApTile extends StatelessWidget {
  const _ApTile({required this.ap, required this.current});

  final WifiAccessPoint ap;
  final bool current;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final color = _signalColor(p, ap.level);
    final secure = ap.security != 'OPEN';
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(
            width: 52,
            child: Column(
              children: [
                Icon(Icons.wifi_rounded, color: color),
                Text('${ap.level}', style: AppTypography.mono(size: 11, color: color)),
              ],
            ),
          ),
          const SizedBox(width: AppSpacing.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        ap.isHidden ? l.t('hidden_ssid') : ap.ssid,
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                              fontWeight: FontWeight.w700,
                              fontStyle: ap.isHidden ? FontStyle.italic : FontStyle.normal,
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (current) ...[
                      const SizedBox(width: 6),
                      Icon(Icons.check_circle_rounded, size: 16, color: p.success),
                    ],
                  ],
                ),
                Text(
                  '${ap.bssid} · ch ${ap.channel} · ${ap.widthMhz} MHz',
                  style: AppTypography.mono(size: 11, color: p.muted),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Icon(secure ? Icons.lock_rounded : Icons.lock_open_rounded, size: 16, color: secure ? p.muted : p.danger),
          const SizedBox(width: 4),
          Text(ap.security, style: AppTypography.mono(size: 11, color: secure ? p.muted : p.danger)),
        ],
      ),
    );
  }
}

/// Graphique d'occupation des canaux : une "cloche" par point d'accès, hauteur = signal.
class _ChannelPainter extends CustomPainter {
  _ChannelPainter({
    required this.aps,
    required this.band,
    required this.colors,
    required this.grid,
    required this.label,
    this.highlight,
  });

  final List<WifiAccessPoint> aps;
  final String band;
  final List<Color> colors;
  final Color grid;
  final Color label;
  final String? highlight;

  @override
  void paint(Canvas canvas, Size size) {
    const bottomPad = 18.0;
    final h = size.height - bottomPad;
    int minCh;
    int maxCh;
    double widthUnit; // canaux couverts par 20 MHz
    if (band == '2.4 GHz') {
      minCh = 1;
      maxCh = 14;
      widthUnit = 4;
    } else if (band == '6 GHz') {
      minCh = 1;
      maxCh = 233;
      widthUnit = 4;
    } else {
      minCh = 32;
      maxCh = 177;
      widthUnit = 4;
    }
    if (aps.isNotEmpty) {
      final channels = aps.map((a) => a.channel).where((c) => c > 0).toList();
      if (channels.isNotEmpty && band != '2.4 GHz') {
        minCh = math.max(minCh, channels.reduce(math.min) - 8);
        maxCh = math.min(maxCh, channels.reduce(math.max) + 8);
      }
    }
    final span = (maxCh - minCh).toDouble();
    double xOf(double ch) => (ch - minCh) / span * size.width;
    double yOf(int dbm) {
      final q = ((dbm + 100) / 70).clamp(0.0, 1.0).toDouble();
      return h - q * h;
    }

    final gridPaint = Paint()
      ..color = grid
      ..strokeWidth = 1;
    for (final dbm in const [-30, -50, -70, -90]) {
      final y = yOf(dbm);
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    final step = band == '2.4 GHz' ? 1 : (span > 60 ? 16 : 8);
    for (var ch = minCh; ch <= maxCh; ch += step) {
      final tp = TextPainter(
        text: TextSpan(text: '$ch', style: TextStyle(color: label, fontSize: 9)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(xOf(ch.toDouble()) - tp.width / 2, h + 4));
    }

    for (var i = 0; i < aps.length; i++) {
      final ap = aps[i];
      if (ap.channel <= 0) continue;
      final color = ap.bssid == highlight ? colors[2] : colors[i % colors.length];
      final halfWidth = widthUnit / 2 * (ap.widthMhz / 20);
      final left = xOf(ap.channel - halfWidth);
      final right = xOf(ap.channel + halfWidth);
      final top = yOf(ap.level);
      final path = Path()
        ..moveTo(left, h)
        ..cubicTo(left + (right - left) * 0.15, top, right - (right - left) * 0.15, top, right, h)
        ..close();
      canvas.drawPath(path, Paint()..color = color.faded(0.18));
      canvas.drawPath(
        path,
        Paint()
          ..color = color
          ..style = PaintingStyle.stroke
          ..strokeWidth = ap.bssid == highlight ? 2.4 : 1.4,
      );
      final name = ap.isHidden ? '•' : ap.ssid;
      final tp = TextPainter(
        text: TextSpan(text: name.length > 14 ? '${name.substring(0, 14)}…' : name, style: TextStyle(color: color, fontSize: 9)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(xOf(ap.channel.toDouble()) - tp.width / 2, math.max(0.0, top - 12)));
    }
  }

  @override
  bool shouldRepaint(covariant _ChannelPainter old) => true;
}
