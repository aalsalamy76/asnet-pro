import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/network/dns_codec.dart';
import '../../../core/providers/app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_spacing.dart';
import '../../../core/theme/app_typography.dart';
import '../../../shared/utils/feedback.dart';
import '../services/dns_lookup.dart';
import '../services/ping_service.dart';
import '../widgets/tool_widgets.dart';

class DnsPage extends ConsumerStatefulWidget {
  const DnsPage({super.key, this.host});

  final String? host;

  @override
  ConsumerState<DnsPage> createState() => _DnsPageState();
}

class _DnsPageState extends ConsumerState<DnsPage> {
  late final TextEditingController _name = TextEditingController(text: widget.host ?? 'google.com');
  String _type = 'A';
  String _server = '1.1.1.1';
  bool _running = false;
  DnsLookupResult? _result;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    final l = context.l10n;
    final name = cleanHostInput(_name.text);
    if (name.isEmpty) {
      showAppSnack(context, l.t('error_host_required'), kind: FeedbackKind.error);
      return;
    }
    setState(() {
      _running = true;
      _error = null;
      _result = null;
    });
    try {
      final result = await const DnsLookup().query(name, _type, server: _server);
      if (mounted) setState(() => _result = result);
    } catch (_) {
      if (mounted) setState(() => _error = l.t('dns_timeout'));
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final gateway = ref.watch(networkDetailsProvider).valueOrNull?.gateway;
    final servers = <String, String>{
      if (gateway != null) l.t('gateway'): gateway,
      ...DnsLookup.resolvers,
    };
    final result = _result;

    return ToolPage(
      title: l.t('tool_dns'),
      icon: Icons.dns_rounded,
      children: [
        HostInput(
          controller: _name,
          label: l.t('domain_label'),
          hint: 'exemple.fr / 8.8.8.8 (PTR)',
          running: _running,
          onRun: _run,
          onStop: () {},
          extra: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(l.t('record_type'), style: text.labelMedium?.copyWith(color: p.muted)),
              const SizedBox(height: AppSpacing.xs),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: [
                  for (final t in DnsCodec.types.keys)
                    ChoiceChip(
                      label: Text(t),
                      selected: _type == t,
                      onSelected: (_) => setState(() => _type = t),
                    ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              Text(l.t('resolver'), style: text.labelMedium?.copyWith(color: p.muted)),
              const SizedBox(height: AppSpacing.xs),
              Wrap(
                spacing: AppSpacing.xs,
                runSpacing: AppSpacing.xs,
                children: [
                  for (final entry in servers.entries)
                    ChoiceChip(
                      label: Text('${entry.key} · ${entry.value}'),
                      selected: _server == entry.value,
                      onSelected: (_) => setState(() => _server = entry.value),
                    ),
                ],
              ),
            ],
          ),
        ),
        if (_error != null)
          ResultCard(
            title: l.t('error'),
            accent: p.danger,
            child: Text(_error!, style: text.bodyMedium),
          ),
        if (result != null)
          ResultCard(
            title: '${result.type} · ${result.query}',
            trailing: Text(
              '${result.rcode} · ${result.elapsedMs} ms',
              style: AppTypography.mono(size: 12, color: result.rcode == 'NOERROR' ? p.success : p.warning),
            ),
            child: result.records.isEmpty
                ? Text(l.t('dns_no_records'), style: text.bodyMedium?.copyWith(color: p.muted))
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      for (final r in result.records)
                        Container(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          padding: const EdgeInsets.all(AppSpacing.sm),
                          decoration: BoxDecoration(
                            color: p.background.faded(0.5),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: p.glassBorder),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(r.typeName, style: AppTypography.mono(size: 12, weight: FontWeight.w800, color: p.network)),
                                  const SizedBox(width: AppSpacing.sm),
                                  Expanded(
                                    child: Text(r.name, style: AppTypography.mono(size: 11, color: p.muted), overflow: TextOverflow.ellipsis),
                                  ),
                                  Text('TTL ${r.ttl}', style: AppTypography.mono(size: 11, color: p.muted)),
                                ],
                              ),
                              const SizedBox(height: 4),
                              SelectableText(
                                r.priority != null && r.type == DnsCodec.typeMX ? '${r.priority}  ${r.data}' : r.data,
                                style: AppTypography.mono(size: 14, color: p.text),
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
          ),
      ],
    );
  }
}
