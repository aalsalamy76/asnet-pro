// Décision : l'export JSON passe par la feuille de partage Android (Drive, mail, Fichiers…)
// plutôt que par une écriture directe dans /Download (aucune permission stockage nécessaire).
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../core/app_info.dart';
import '../../core/l10n/app_localizations.dart';
import '../../core/providers/app_providers.dart';
import '../../core/providers/theme_provider.dart';
import '../../core/router/app_router.dart';
import '../../core/services/permission_service.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_motion.dart';
import '../../core/theme/app_spacing.dart';
import '../../core/theme/app_typography.dart';
import '../../shared/utils/feedback.dart';
import '../../shared/utils/time_format.dart';
import '../../shared/widgets/glass_card.dart';
import '../../shared/widgets/ui_parts.dart';
import '../scan/scan_controller.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> with WidgetsBindingObserver {
  bool _locationGranted = false;
  bool _cameraGranted = false;
  bool _exporting = false;

  static const Map<String, String> _languages = {
    'fr': 'Français',
    'en': 'English',
    'ar': 'العربية',
    'es': 'Español',
  };

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadPermissions();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Retour des paramètres Android : on relit l'état des permissions.
    if (state == AppLifecycleState.resumed) {
      _loadPermissions();
      ref.invalidate(networkDetailsProvider);
    }
  }

  Future<void> _loadPermissions() async {
    final service = ref.read(permissionServiceProvider);
    final location = await service.isGranted(AppPermission.location);
    final camera = await service.isGranted(AppPermission.camera);
    if (!mounted) return;
    setState(() {
      _locationGranted = location;
      _cameraGranted = camera;
    });
  }

  Future<void> _togglePermission(AppPermission permission, bool granted) async {
    final service = ref.read(permissionServiceProvider);
    if (granted) {
      await service.openSettings();
      return;
    }
    await service.ensure(context, permission);
    await _loadPermissions();
    if (mounted) ref.invalidate(networkDetailsProvider);
  }

  Future<void> _exportJson() async {
    final l = context.l10n;
    final json = ref.read(scanHistoryRepositoryProvider).exportLastScanJson();
    if (json == null) {
      showAppSnack(context, l.t('export_none'), kind: FeedbackKind.error);
      return;
    }
    setState(() => _exporting = true);
    try {
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/asnet_scan_${fileStamp(DateTime.now())}.json');
      await file.writeAsString(json, flush: true);
      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'application/json')],
        subject: 'A.SNet — ${l.t('export_subject')}',
      );
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('export_failed'), kind: FeedbackKind.error);
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  Future<void> _clearHistory() async {
    final l = context.l10n;
    final p = context.palette;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: p.surface,
        surfaceTintColor: Colors.transparent,
        icon: Icon(Icons.delete_sweep_rounded, color: p.danger, size: 32),
        title: Text(l.t('clear_history')),
        content: Text(l.t('clear_history_confirm'), style: TextStyle(color: p.muted)),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: Text(l.t('cancel'))),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: p.danger, foregroundColor: Colors.white),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(l.t('delete')),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    try {
      await ref.read(scanHistoryRepositoryProvider).clear();
      ref.read(scanControllerProvider.notifier).reset();
      if (mounted) showAppSnack(context, l.t('history_cleared'), kind: FeedbackKind.success);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('error_generic'), kind: FeedbackKind.error);
    }
  }

  Future<void> _openLinkedIn() async {
    final l = context.l10n;
    try {
      final ok = await launchUrl(Uri.parse(AppInfo.linkedIn), mode: LaunchMode.externalApplication);
      if (!ok && mounted) showAppSnack(context, l.t('open_failed'), kind: FeedbackKind.error);
    } catch (_) {
      if (mounted) showAppSnack(context, l.t('open_failed'), kind: FeedbackKind.error);
    }
  }

  Future<void> _replayOnboarding() async {
    try {
      await ref.read(sharedPreferencesProvider).setBool(onboardingDoneKey, false);
    } catch (_) {}
    if (mounted) context.go(AppRoutes.onboarding);
  }

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    final text = Theme.of(context).textTheme;
    final themeMode = ref.watch(themeModeProvider);
    final locale = ref.watch(localeProvider);
    final scan = ref.watch(scanControllerProvider);
    final topInset = MediaQuery.paddingOf(context).top;

    return ListView(
      padding: AppSpacing.screen.copyWith(top: topInset + AppSpacing.lg),
      children: [
        Semantics(header: true, child: Text(l.t('settings_title'), style: text.headlineMedium)),

        // ── Apparence ───────────────────────────────
        SectionTitle(l.t('appearance')),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(l.t('theme'), style: text.titleSmall),
              const SizedBox(height: AppSpacing.sm),
              SegmentedButton<ThemeMode>(
                showSelectedIcon: false,
                segments: [
                  ButtonSegment(
                    value: ThemeMode.dark,
                    icon: const Icon(Icons.brightness_2_rounded),
                    label: Text(l.t('theme_dark')),
                  ),
                  ButtonSegment(
                    value: ThemeMode.light,
                    icon: const Icon(Icons.wb_sunny_rounded),
                    label: Text(l.t('theme_light')),
                  ),
                  ButtonSegment(
                    value: ThemeMode.system,
                    icon: const Icon(Icons.brightness_auto_rounded),
                    label: Text(l.t('theme_auto')),
                  ),
                ],
                selected: {themeMode},
                onSelectionChanged: (selection) {
                  AppMotion.tap();
                  ref.read(themeModeProvider.notifier).setMode(selection.first);
                },
              ),
            ],
          ),
        ),

        // ── Langue ──────────────────────────────────
        SectionTitle(l.t('language')),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
          child: Column(
            children: [
              _ChoiceTile(
                label: l.t('language_system'),
                selected: locale == null,
                onTap: () => ref.read(localeProvider.notifier).setLanguage(null),
              ),
              for (final entry in _languages.entries)
                _ChoiceTile(
                  label: entry.value,
                  selected: locale?.languageCode == entry.key,
                  onTap: () => ref.read(localeProvider.notifier).setLanguage(entry.key),
                ),
            ],
          ),
        ),

        // ── Données ─────────────────────────────────
        SectionTitle(l.t('data')),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
          child: Column(
            children: [
              ListTile(
                leading: Icon(Icons.code_rounded, color: p.network),
                title: Text(l.t('export_json')),
                subtitle: Text(
                  scan.finishedAt == null
                      ? l.t('no_scan_yet')
                      : l.t('export_json_desc', {
                          'count': scan.devices.length,
                          'when': relativeTime(l, scan.finishedAt),
                        }),
                ),
                trailing: _exporting
                    ? const SizedBox.square(dimension: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.share_rounded),
                onTap: _exporting ? null : _exportJson,
              ),
              ListTile(
                leading: Icon(Icons.delete_sweep_rounded, color: p.danger),
                title: Text(l.t('clear_history')),
                subtitle: Text(l.t('clear_history_desc')),
                onTap: _clearHistory,
              ),
            ],
          ),
        ),

        // ── Permissions ─────────────────────────────
        SectionTitle(l.t('permissions')),
        GlassCard(
          padding: const EdgeInsets.symmetric(vertical: AppSpacing.xs),
          child: Column(
            children: [
              _PermissionTile(
                icon: Icons.location_on_rounded,
                title: l.t('perm_location_title'),
                granted: _locationGranted,
                onTap: () => _togglePermission(AppPermission.location, _locationGranted),
              ),
              _PermissionTile(
                icon: Icons.photo_camera_rounded,
                title: l.t('perm_camera_title'),
                granted: _cameraGranted,
                onTap: () => _togglePermission(AppPermission.camera, _cameraGranted),
              ),
            ],
          ),
        ),

        // ── À propos ────────────────────────────────
        SectionTitle(l.t('about')),
        GlassCard(
          accent: p.network,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 56,
                    height: 56,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: AppColors.bg,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppColors.cyan.faded(0.5)),
                    ),
                    child: Text(
                      'AS',
                      style: text.titleLarge?.copyWith(color: AppColors.cyan, fontWeight: FontWeight.w900),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.md),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(AppInfo.name, style: text.titleLarge),
                        Text(
                          '${l.t('version')} ${AppInfo.version} (${AppInfo.build})',
                          style: AppTypography.mono(size: 13, color: p.muted),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.md),
              Text(l.t('about_body'), style: text.bodyMedium?.copyWith(color: p.muted, height: 1.4)),
              const SizedBox(height: AppSpacing.lg),
              Text(l.t('developer'), style: text.labelMedium?.copyWith(color: p.muted)),
              const SizedBox(height: 2),
              Text(AppInfo.developer, style: text.titleMedium),
              const SizedBox(height: AppSpacing.md),
              OutlinedButton.icon(
                onPressed: _openLinkedIn,
                icon: const Icon(Icons.person_rounded),
                label: Text(l.t('linkedin_profile')),
              ),
              const SizedBox(height: AppSpacing.sm),
              Row(
                children: [
                  Expanded(
                    child: TextButton(
                      onPressed: () => showLicensePage(
                        context: context,
                        applicationName: AppInfo.name,
                        applicationVersion: AppInfo.version,
                        applicationLegalese: '© ${DateTime.now().year} ${AppInfo.developer}',
                      ),
                      child: Text(l.t('licenses')),
                    ),
                  ),
                  Expanded(
                    child: TextButton(
                      onPressed: _replayOnboarding,
                      child: Text(l.t('replay_onboarding')),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ChoiceTile extends StatelessWidget {
  const _ChoiceTile({required this.label, required this.selected, required this.onTap});

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Semantics(
      selected: selected,
      button: true,
      child: ListTile(
        title: Text(label),
        trailing: AnimatedSwitcher(
          duration: AppMotion.fast,
          child: selected
              ? Icon(Icons.check_circle_rounded, key: const ValueKey('on'), color: p.network)
              : const SizedBox(key: ValueKey('off'), width: 24, height: 24),
        ),
        onTap: () {
          AppMotion.tap();
          onTap();
        },
      ),
    );
  }
}

class _PermissionTile extends StatelessWidget {
  const _PermissionTile({
    required this.icon,
    required this.title,
    required this.granted,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final bool granted;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final l = context.l10n;
    final p = context.palette;
    return ListTile(
      leading: Icon(icon, color: granted ? p.success : p.muted),
      title: Text(title),
      subtitle: Text(granted ? l.t('perm_granted') : l.t('perm_denied')),
      trailing: StatusPill(
        label: granted ? l.t('perm_on') : l.t('perm_off'),
        color: granted ? p.success : p.warning,
      ),
      onTap: onTap,
    );
  }
}
