# A.SNet — scanner réseau & partage Wi-Fi (Android)

Application Flutter **100 % locale** : tableau de bord réseau, **scan réel** du réseau local,
partage Wi-Fi par QR code, interface **français · العربية · English · Español** (arabe en RTL).

Développeur : **Abdullah AL-SALAMY** — <https://www.linkedin.com/in/abdullah-a-2982451a6>

## Version 0.2 « Pro » — plus loin que Fing

**Identification avancée des appareils** (après le balayage ping/TCP) :
- **mDNS / Bonjour** : noms et services (AirPlay, Chromecast, imprimantes IPP, HomeKit, Sonos, SMB…)
- **SSDP / UPnP** : nom, fabricant et modèle des box, TV, NAS ; détection de l'UPnP de la box
- **NetBIOS** : nom Windows + adresse MAC (même sur Android 10+, qui masque la table ARP)
- Latence de chaque appareil, type déduit (routeur, téléphone, PC, TV, enceinte, caméra, NAS, imprimante, IoT…)
- **Fiche appareil** : nom personnalisé, notes, « de confiance », ports ouverts, Wake-on-LAN, ouverture de l'interface web

**Onglet Outils (13 outils)** :

| Outil | Ce qu'il fait |
|---|---|
| Audit de sécurité | Note /100 : chiffrement Wi-Fi, Telnet/FTP/SMB/TR-069 sur la box, UPnP, ports dangereux (Telnet, ADB, RDP, VNC, SMB, Redis, MongoDB, Docker…), détournement DNS, appareils inconnus |
| Analyseur Wi-Fi | Réseaux voisins, graphique d'occupation des canaux 2,4/5/6 GHz, RSSI, débit du lien, norme Wi-Fi 4/5/6/7 |
| Test de débit | Latence, gigue, descendant (4 flux), montant (3 flux) — serveurs Cloudflare |
| IP publique | IP, fournisseur/AS, ville, fuseau |
| Ping | Continu, min/moy/max, gigue, pertes, graphique |
| Traceroute | Sauts ICMP avec DNS inverse |
| Scanner de ports | Courants / 1-1024 / 65 535 / liste perso, bannières SSH/FTP/HTTP |
| DNS | A, AAAA, CNAME, MX, TXT, NS, SOA, PTR, SRV vers Google, Cloudflare, Quad9, OpenDNS ou la box |
| En-têtes HTTP | Chaîne de redirections, en-têtes de sécurité (HSTS, CSP…) |
| Certificat SSL | Sujet, émetteur, validité, ALPN, empreinte SHA-1 |
| Whois | Domaines et IP (IANA puis registre) |
| Wake-on-LAN | Paquet magique en broadcast |
| Calculateur IP | Masque, wildcard, plage, broadcast, classe, privé/public |

Tout fonctionne sans root et sans serveur A.SNet. Seuls le test de débit, l'IP publique et le Whois contactent Internet.

---

## 1. Obtenir l'APK sans rien installer (GitHub Actions)

1. Créez un dépôt GitHub (privé ou public) et envoyez-y **tout le contenu de ce dossier**
   (y compris le dossier caché `.github/`).
   - Méthode web : *Add file → Upload files* puis glissez le contenu du dossier
     (GitHub Desktop ou `git push` gèrent mieux les dossiers cachés).
2. Ouvrez l'onglet **Actions** : le workflow **Build APK** démarre tout seul (≈ 8 à 12 min).
3. Une fois vert, ouvrez l'onglet **Releases** : les APK y sont téléchargeables.
   - `app-arm64-v8a-release.apk` → la plupart des téléphones (recommandé)
   - `app-armeabi-v7a-release.apk` → anciens téléphones 32 bits
   - `app-release.apk` → universel
4. Sur le téléphone : ouvrez l'APK, autorisez « Installer des applis inconnues » pour le
   navigateur/gestionnaire de fichiers, installez.

## 2. Compiler sur votre PC

### Prérequis
- **Flutter SDK 3.24 ou plus** (`flutter --version`)
- **Android SDK** (Android Studio, ou command-line tools) avec licences acceptées : `flutter doctor --android-licenses`
- **Java 17** (celui fourni par Android Studio convient : `flutter config --jdk-dir <chemin>` si besoin)
- `flutter doctor` sans erreur sur la ligne Android

### Les 3 commandes
```bash
flutter pub get
flutter build apk --release --split-per-abi
adb install build/app/outputs/flutter-apk/app-arm64-v8a-release.apk
```
> Avec `--split-per-abi`, Flutter produit un APK par architecture. Le fichier
> `app-release.apk` (universel) n'existe que si vous lancez `flutter build apk --release`
> **sans** `--split-per-abi` ; dans ce cas : `adb install build/app/outputs/flutter-apk/app-release.apk`.

APK debug : `flutter build apk --debug` → `build/app/outputs/flutter-apk/app-debug.apk`.

### Emplacement des APK
```
build/app/outputs/flutter-apk/
├── app-arm64-v8a-release.apk     (~ 15-20 Mo)
├── app-armeabi-v7a-release.apk
├── app-x86_64-release.apk
└── app-release.apk               (universel, si build sans --split-per-abi)
```

## 3. Signer la release (Play Store / mises à jour propres)

Sans configuration, l'APK release est signé avec la **clé debug** : il s'installe tout de suite,
mais ne peut pas être publié sur le Play Store. Pour une vraie signature :

**a) Créer la clé (une seule fois, à conserver précieusement) :**
```bash
keytool -genkey -v -keystore ~/asnet-release.jks -keyalg RSA -keysize 2048 \
        -validity 10000 -alias asnet
```

**b) Créer `android/key.properties`** (déjà ignoré par git) :
```properties
storePassword=VOTRE_MOT_DE_PASSE_KEYSTORE
keyPassword=VOTRE_MOT_DE_PASSE_CLE
keyAlias=asnet
storeFile=/chemin/absolu/vers/asnet-release.jks
```

**c) `android/app/build.gradle` est déjà prêt** — ce bloc lit `key.properties` automatiquement :
```groovy
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystorePropertiesFile.withInputStream { keystoreProperties.load(it) }
}

android {
    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties["keyAlias"]
                keyPassword = keystoreProperties["keyPassword"]
                storeFile = file(keystoreProperties["storeFile"])
                storePassword = keystoreProperties["storePassword"]
            }
        }
    }
    buildTypes {
        release {
            signingConfig = keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug
        }
    }
}
```
Puis `flutter build apk --release --split-per-abi` (ou `flutter build appbundle` pour le Play Store).

## 4. Les 5 écrans

```
┌──────────────────────┐  ┌──────────────────────┐  ┌──────────────────────┐
│ 1. ONBOARDING        │  │ 2. ACCUEIL (bento)   │  │ 3. SCAN              │
│ [Langue ▾]   Passer  │  │ AS  A.SNet   ● Bon   │  │ Scan réseau          │
│                      │  │ ┌──────────────────┐ │  │ Sous-réseau x.x.x/24 │
│      ◉ orbe /        │  │ │   ◉ NetworkOrb   │ │  │ ┌──────────────────┐ │
│      radar animé     │  │ │   Box-Maison     │ │  │ │  ◎ radar  42 %   │ │
│                      │  │ │   Wi-Fi · WPA2   │ │  │ │  ▓▓▓▓░░ 108/254  │ │
│  Titre de la slide   │  │ └──────────────────┘ │  │ │  [ Annuler ]     │ │
│  Texte explicatif    │  │ ┌───────┐ ┌────────┐ │  │ └──────────────────┘ │
│                      │  │ │IP     │ │Wi-Fi   │ │  │ APPAREILS (7) Tous|Nx│
│ 3/3 : Localisation ✓ │  │ └───────┘ └────────┘ │  │ ⌂ Livebox 192.168.1.1│
│        Caméra      ○ │  │ ┌───────┐ ┌────────┐ │  │ ▢ iPhone  .12  NOUVEAU│
│      ● ○ ○           │  │ │ 7 app.│ │ ◔ 75   │ │  │ ▢ PC-Salon .24       │
│ [  Suivant  →  ]     │  │ └───────┘ └────────┘ │  │ (tirer = relancer)   │
│                      │  │ [ ◎ Scanner le réseau]│ │                      │
└──────────────────────┘  └──────────────────────┘  └──────────────────────┘
┌──────────────────────┐  ┌──────────────────────┐
│ 4. PARTAGE           │  │ 5. RÉGLAGES          │
│ ┌──────────────────┐ │  │ Thème [Sombre|Clair| │
│ │   ▣ QR Wi-Fi     │ │  │        Auto]         │
│ │   Box-Maison     │ │  │ Langue  Système ✓    │
│ │ [Partager le QR] │ │  │   FR / EN / AR / ES  │
│ └──────────────────┘ │  │ Export JSON du scan  │
│ SSID  [__________]   │  │ Effacer l'historique │
│ Mot de passe [•••• ] │  │ Autorisations ON/OFF │
│ WPA | WEP | Ouvert   │  │ À propos · v0.1.0    │
│ [Enregistrer chiffré]│  │ Abdullah AL-SALAMY   │
│ ⌗ Scanner un QR code │  │ [Profil LinkedIn]    │
└──────────────────────┘  └──────────────────────┘
   Barre de navigation en verre : Accueil · Scan · Partage · Réglages
```

## 5. Comment fonctionne le scan (réel, sans root)

1. Lecture IP / masque / passerelle du Wi-Fi (`network_info_plus`).
2. Balayage du sous-réseau (plafonné à 254 hôtes) avec **20 sondes en parallèle** :
   `ping -c 1 -W 1` (binaire système Android) **et** connexions TCP (80, 443, 22, 53, 139, 445,
   554, 8080, 8008, 62078) ; un « connexion refusée » prouve aussi qu'un hôte existe.
3. Lecture de la table ARP (`/proc/net/arp`, puis `ip neigh`) → adresses MAC quand Android le permet.
4. Nom d'hôte par DNS inverse, fabricant par base OUI embarquée (~600 préfixes : Apple, Samsung,
   Xiaomi, Huawei, Google, Amazon, TP-Link, Netgear, ASUS, Freebox, Livebox/Sagemcom, Intel…).
5. Comparaison à l'historique (SharedPreferences) → badge **NOUVEAU**. Le 1er scan sert de référence.

Durée typique : 10 à 20 s pour un /24.

## 6. Limitations connues (imposées par Android)

- **Adresses MAC des autres appareils** : lisibles via ARP jusqu'à Android 9. Depuis
  **Android 10**, le système bloque `/proc/net/arp` et `ip neigh` pour les applications :
  l'app détecte quand même les appareils (IP + nom d'hôte), mais MAC et fabricant
  s'affichent « Non lisible ». Les téléphones récents utilisent en plus des **MAC aléatoires**.
- **MAC du téléphone lui-même** = `02:00:00:00:00:00` depuis Android 6/10 (par conception).
- **SSID / type de sécurité** : nécessitent l'autorisation **ACCESS_FINE_LOCATION** *et* la
  localisation du téléphone activée ; sinon le Wi-Fi apparaît « nom masqué ».
- **Scan de QR (`mobile_scanner`)** : fonctionne uniquement sur un **appareil réel** (pas d'émulateur).
- Certains routeurs/réseaux invités isolent les clients (*AP isolation*) : seuls le routeur
  et le téléphone apparaissent alors.
- Polices Inter / JetBrains Mono téléchargées au 1er lancement (puis en cache) ; hors-ligne,
  la police système est utilisée.

## 7. Structure du code

```
lib/
├── main.dart · app.dart
├── core/
│   ├── app_info.dart
│   ├── l10n/            (app_localizations.dart, app_strings.dart — fr/en/ar/es)
│   ├── providers/       (app_providers.dart, theme_provider.dart — thème + langue)
│   ├── network/         (native_wifi, dns_codec, ports_catalog)
│   ├── router/          (app_router.dart — go_router, 6 routes + barre de navigation)
│   ├── services/        (permission_service.dart)
│   └── theme/           (app_colors, app_typography, app_spacing, app_motion, app_theme)
├── shared/
│   ├── utils/           (feedback.dart, time_format.dart)
│   └── widgets/         (glass_card, bento_grid, network_orb, scan_radar, ui_parts)
└── features/
    ├── onboarding/ · dashboard/ · settings/
    ├── scan/            (models, services : network_scanner, discovery_services (mDNS/SSDP/NetBIOS),
    │                     oui_lookup, network_info_service, scan_history_repository, device_labels_repository
    │                     · scan_controller · scan_screen · device_detail_screen)
    ├── tools/           (tools_screen, pages/ (13 outils), services/ (ping, ports, DNS, débit,
    │                     web, LAN, audit), widgets/)
    └── share/           (share_screen, qr_scan_page, wifi_qr)
android/app/src/main/kotlin/com/asnet/app/MainActivity.kt  (canal natif : sécurité Wi-Fi, scan Wi-Fi, lien radio, verrou multicast)
.github/workflows/build-apk.yml                             (compilation automatique de l'APK)
```

Versions Android : `minSdk 23` (Android 6) → `targetSdk 34` (Android 14), `compileSdk 35`.
Package : `com.asnet.app`. AGP 8.7.3 · Kotlin 2.1.0 · Gradle 8.10.2.

## 8. Roadmap V0.3

- **Surveillance en tâche de fond** : notification à l'arrivée d'un appareil inconnu (WorkManager).
- **Partage LAN TCP** : envoi de fichiers entre deux téléphones A.SNet sur le même Wi-Fi.
- **Bluetooth** : détection des appareils BLE à proximité.
- **IA** : résumé de sécurité en langage naturel, identification plus fine des appareils.
- Historique des scans, graphiques de présence, export CSV/PDF.
